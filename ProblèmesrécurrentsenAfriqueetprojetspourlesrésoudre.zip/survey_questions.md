# Questions pour le Sondage en Ligne sur l'Intégration des Africains en Europe

Ce document contient les questions adaptées du guide d'entretiens qualitatifs, formulées pour un sondage en ligne. L'objectif est de recueillir des données quantitatives et qualitatives sur les défis d'intégration, l'intérêt pour une plateforme numérique et la disposition à payer pour certains services.

--- 

## Section 1: Informations Démographiques et Parcours

1.  **Quel est votre pays d'origine ?** (Question à choix multiple / Texte libre si non listé)
    *   Ex: Congo, Côte d'Ivoire, Sénégal, Cameroun, etc.

2.  **Dans quel pays d'Europe résidez-vous actuellement ?** (Question à choix multiple / Texte libre si non listé)
    *   Ex: France, Belgique, Allemagne, Royaume-Uni, etc.

3.  **Depuis combien de temps résidez-vous en Europe ?** (Question à choix multiple)
    *   Moins de 6 mois
    *   6 mois à 1 an
    *   1 à 2 ans
    *   2 à 5 ans
    *   Plus de 5 ans

4.  **Quel est votre statut actuel en Europe ?** (Question à choix multiple)
    *   Étudiant
    *   Professionnel (salarié)
    *   Entrepreneur / Travailleur indépendant
    *   Demandeur d'emploi
    *   Demandeur d'asile / Réfugié
    *   Autre (précisez)

--- 

## Section 2: Défis et Besoins d'Intégration

5.  **Quelles ont été les principales difficultés que vous avez rencontrées lors de votre arrivée en Europe ? (Sélectionnez toutes les options pertinentes)**
    *   Démarches administratives (visa, titre de séjour, sécurité sociale, etc.)
    *   Recherche de logement
    *   Recherche d'emploi / Reconnaissance des diplômes
    *   Barrière linguistique
    *   Différences culturelles / Adaptation sociale
    *   Isolement social / Manque de réseau
    *   Accès aux services de santé
    *   Accès à l'éducation (pour vous ou vos enfants)
    *   Discrimination
    *   Autre (précisez)

6.  **Sur une échelle de 1 à 5 (1 = pas du tout difficile, 5 = extrêmement difficile), à quel point évalueriez-vous la difficulté des démarches administratives ?** (Échelle de Likert)

7.  **Sur une échelle de 1 à 5, à quel point évalueriez-vous la difficulté de trouver des informations fiables et centralisées ?** (Échelle de Likert)

8.  **Quand vous avez eu besoin d'aide ou d'information, vers quelles sources vous êtes-vous tourné(e) en priorité ? (Sélectionnez toutes les options pertinentes)**
    *   Amis / Famille
    *   Associations d'aide aux migrants
    *   Sites web officiels (gouvernement, ambassades)
    *   Réseaux sociaux (Facebook, WhatsApp, LinkedIn)
    *   Avocats / Conseillers spécialisés
    *   Membres de la diaspora déjà établis
    *   Autre (précisez)

--- 

## Section 3: Intérêt pour une Plateforme Numérique

9.  **Seriez-vous intéressé(e) par une plateforme numérique offrant les services suivants ? (Sélectionnez toutes les options pertinentes)**
    *   Guides détaillés sur les démarches administratives (logement, emploi, santé, etc.)
    *   Annuaire de ressources géolocalisées (associations, services publics, etc.)
    *   Mise en relation avec des mentors expérimentés de la diaspora africaine
    *   Un forum ou une communauté d'entraide avec d'autres nouveaux arrivants
    *   Des webinaires ou formations en ligne sur des sujets clés (reconnaissance de diplômes, recherche d'emploi)
    *   Accès à des experts spécialisés (avocats, conseillers RH)
    *   Autre (précisez)

10. **Sur une échelle de 1 à 5 (1 = pas du tout utile, 5 = extrêmement utile), à quel point jugeriez-vous utile la mise en relation avec un mentor expérimenté ?** (Échelle de Likert)

11. **Si une telle plateforme existait, quelles fonctionnalités seraient les plus importantes pour vous ? (Classez par ordre d'importance de 1 à 5, 1 étant le plus important)**
    *   Guides pratiques
    *   Annuaire de ressources
    *   Mise en relation avec mentors
    *   Forum/Communauté
    *   Webinaires/Formations

--- 

## Section 4: Disposition à Payer

12. **La plateforme pourrait proposer un accès gratuit à des informations de base et à la communauté, et des services premium payants. Seriez-vous prêt(e) à payer pour accéder à des services premium tels que : (Sélectionnez toutes les options pertinentes)**
    *   Consultations individuelles avec des mentors
    *   Accès à des experts spécialisés (avocats, conseillers)
    *   Guides et modèles de documents avancés
    *   Webinaires exclusifs
    *   Accompagnement personnalisé pour l'emploi
    *   Non, je ne suis pas prêt(e) à payer

13. **Si vous étiez prêt(e) à payer pour un abonnement mensuel donnant accès à des services premium, quel serait le montant maximum que vous seriez prêt(e) à dépenser par mois ?** (Question à choix multiple)
    *   Moins de 5€
    *   5€ - 10€
    *   10€ - 15€
    *   15€ - 20€
    *   Plus de 20€
    *   Je ne suis pas prêt(e) à payer pour un abonnement

--- 

## Section 5: Suggestions et Commentaires

14. **Avez-vous des suggestions ou des commentaires supplémentaires concernant cette plateforme ou les défis d'intégration ?** (Texte libre)

--- 

Merci d'avoir pris le temps de répondre à ce sondage. Vos réponses sont précieuses pour le développement de ce projet !

