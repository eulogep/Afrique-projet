from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class SurveyResponse(db.Model):
    __tablename__ = 'survey_responses'
    
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Section 1: Informations Démographiques et Parcours
    country_origin = db.Column(db.String(100))
    country_residence = db.Column(db.String(100))
    residence_duration = db.Column(db.String(20))
    current_status = db.Column(db.String(50))
    other_status_text = db.Column(db.String(200))
    
    # Section 2: Défis et Besoins d'Intégration
    difficulties = db.Column(db.Text)  # JSON string of selected difficulties
    other_difficulty_text = db.Column(db.String(200))
    difficulty_admin = db.Column(db.Integer)
    difficulty_info = db.Column(db.Integer)
    info_sources = db.Column(db.Text)  # JSON string of selected sources
    other_source_text = db.Column(db.String(200))
    
    # Section 3: Intérêt pour une Plateforme Numérique
    platform_services = db.Column(db.Text)  # JSON string of selected services
    other_service_text = db.Column(db.String(200))
    mentor_utility = db.Column(db.Integer)
    rank_guides = db.Column(db.Integer)
    rank_directory = db.Column(db.Integer)
    rank_mentor_matching = db.Column(db.Integer)
    rank_community = db.Column(db.Integer)
    rank_webinars = db.Column(db.Integer)
    
    # Section 4: Disposition à Payer
    willing_to_pay_services = db.Column(db.Text)  # JSON string of selected services
    monthly_subscription_amount = db.Column(db.String(20))
    
    # Section 5: Suggestions et Commentaires
    suggestions = db.Column(db.Text)
    
    def __repr__(self):
        return f'<SurveyResponse {self.id}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'country_origin': self.country_origin,
            'country_residence': self.country_residence,
            'residence_duration': self.residence_duration,
            'current_status': self.current_status,
            'other_status_text': self.other_status_text,
            'difficulties': self.difficulties,
            'other_difficulty_text': self.other_difficulty_text,
            'difficulty_admin': self.difficulty_admin,
            'difficulty_info': self.difficulty_info,
            'info_sources': self.info_sources,
            'other_source_text': self.other_source_text,
            'platform_services': self.platform_services,
            'other_service_text': self.other_service_text,
            'mentor_utility': self.mentor_utility,
            'rank_guides': self.rank_guides,
            'rank_directory': self.rank_directory,
            'rank_mentor_matching': self.rank_mentor_matching,
            'rank_community': self.rank_community,
            'rank_webinars': self.rank_webinars,
            'willing_to_pay_services': self.willing_to_pay_services,
            'monthly_subscription_amount': self.monthly_subscription_amount,
            'suggestions': self.suggestions
        }

