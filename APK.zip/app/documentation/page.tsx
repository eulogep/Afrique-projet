'use client';
import { useState } from 'react';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function DocumentationPage() {
  const [activeSection, setActiveSection] = useState('overview');

  const sections = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: 'ri-eye-line' },
    { id: 'getting-started', label: 'Démarrage', icon: 'ri-rocket-line' },
    { id: 'api', label: 'API Reference', icon: 'ri-code-line' },
    { id: 'projects', label: 'Gestion Projets', icon: 'ri-folder-line' },
    { id: 'investments', label: 'Investissements', icon: 'ri-funds-line' },
    { id: 'analytics', label: 'Analytics', icon: 'ri-bar-chart-line' },
    { id: 'ai', label: 'Intelligence IA', icon: 'ri-brain-line' },
    { id: 'blockchain', label: 'Blockchain', icon: 'ri-links-line' },
    { id: 'security', label: 'Sécurité', icon: 'ri-shield-check-line' },
    { id: 'examples', label: 'Exemples', icon: 'ri-file-code-line' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Documentation Solutions Afrique
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Guide complet pour développeurs, investisseurs et gestionnaires de projets
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-6">
              <h2 className="font-bold text-gray-900 mb-4">Sections</h2>
              <nav className="space-y-2">
                {sections.map(section => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-all flex items-center gap-3 ${
                      activeSection === section.id
                        ? 'bg-green-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <i className={`${section.icon} text-lg`}></i>
                    {section.label}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-xl shadow-lg p-8">
              {activeSection === 'overview' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-gray-900">Vue d'ensemble de la Plateforme</h2>
                  
                  <p className="text-lg text-gray-600">
                    Solutions Afrique est une plateforme complète de gestion de projets d'impact social 
                    et économique en Afrique, intégrant des technologies avancées d'IA, blockchain et analytics temps réel.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-xl p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <i className="ri-rocket-line mr-2 text-green-600"></i>
                        Fonctionnalités Principales
                      </h3>
                      <ul className="space-y-2 text-gray-700">
                        <li className="flex items-center gap-2">
                          <i className="ri-check-line text-green-600"></i>
                          Gestion complète des projets
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-check-line text-green-600"></i>
                          Système d'investissement avancé
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-check-line text-green-600"></i>
                          Recommandations IA personnalisées
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-check-line text-green-600"></i>
                          Traçabilité blockchain
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-check-line text-green-600"></i>
                          Analytics temps réel
                        </li>
                      </ul>
                    </div>

                    <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                        <i className="ri-global-line mr-2 text-purple-600"></i>
                        Impact & Chiffres Clés
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Projets actifs:</span>
                          <span className="font-bold text-purple-600">189</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Investissements:</span>
                          <span className="font-bold text-purple-600">€24.8M</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Bénéficiaires:</span>
                          <span className="font-bold text-purple-600">847K</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Pays couverts:</span>
                          <span className="font-bold text-purple-600">54</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Taux de réussite:</span>
                          <span className="font-bold text-purple-600">97%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Architecture Technique</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-white rounded-lg p-4 text-center">
                        <i className="ri-reactjs-line text-3xl text-blue-600 mb-2"></i>
                        <div className="font-semibold">Frontend</div>
                        <div className="text-sm text-gray-600">Next.js + React</div>
                      </div>
                      <div className="bg-white rounded-lg p-4 text-center">
                        <i className="ri-database-2-line text-3xl text-green-600 mb-2"></i>
                        <div className="font-semibold">Backend</div>
                        <div className="text-sm text-gray-600">Supabase</div>
                      </div>
                      <div className="bg-white rounded-lg p-4 text-center">
                        <i className="ri-brain-line text-3xl text-purple-600 mb-2"></i>
                        <div className="font-semibold">IA</div>
                        <div className="text-sm text-gray-600">Edge Functions</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'getting-started' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-gray-900">Guide de Démarrage Rapide</h2>
                  
                  <div className="bg-blue-50 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-blue-900 mb-4">
                      Étapes d'Installation et Configuration
                    </h3>
                    
                    <div className="space-y-4">
                      <div className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">1</div>
                        <div>
                          <h4 className="font-semibold text-gray-900">Installation des Dépendances</h4>
                          <div className="bg-gray-900 rounded-lg p-4 mt-2">
                            <code className="text-green-400">
                              npm install @supabase/supabase-js<br/>
                              npm install @supabase/auth-ui-react
                            </code>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">2</div>
                        <div>
                          <h4 className="font-semibold text-gray-900">Configuration Supabase</h4>
                          <div className="bg-gray-900 rounded-lg p-4 mt-2">
                            <code className="text-green-400">
                              NEXT_PUBLIC_SUPABASE_URL=your_supabase_url<br/>
                              NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
                            </code>
                          </div>
                        </div>
                      </div>

                      <div className="flex gap-4">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold flex-shrink-0">3</div>
                        <div>
                          <h4 className="font-semibold text-gray-900">Initialisation du Client</h4>
                          <div className="bg-gray-900 rounded-lg p-4 mt-2">
                            <code className="text-green-400">
                              import {'{ createClient }'} from '@supabase/supabase-js'<br/>
                              <br/>
                              const supabase = createClient(<br/>
                              &nbsp;&nbsp;process.env.NEXT_PUBLIC_SUPABASE_URL,<br/>
                              &nbsp;&nbsp;process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY<br/>
                              )
                            </code>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-green-50 rounded-xl p-6">
                      <h3 className="text-xl font-bold text-green-900 mb-4">Premiers Pas</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <i className="ri-arrow-right-line text-green-600"></i>
                          Créer un compte utilisateur
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-arrow-right-line text-green-600"></i>
                          Explorer le dashboard
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-arrow-right-line text-green-600"></i>
                          Consulter les projets
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-arrow-right-line text-green-600"></i>
                          Tester les recommandations IA
                        </li>
                      </ul>
                    </div>

                    <div className="bg-purple-50 rounded-xl p-6">
                      <h3 className="text-xl font-bold text-purple-900 mb-4">Ressources Utiles</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <i className="ri-book-line text-purple-600"></i>
                          Documentation API complète
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-video-line text-purple-600"></i>
                          Tutoriels vidéo
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-github-line text-purple-600"></i>
                          Code source GitHub
                        </li>
                        <li className="flex items-center gap-2">
                          <i className="ri-customer-service-line text-purple-600"></i>
                          Support technique 24/7
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {activeSection === 'api' && (
                <div className="space-y-6">
                  <h2 className="text-3xl font-bold text-gray-900">Référence API</h2>
                  
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6">
                    <h3 className="text-xl font-bold text-gray-900 mb-4">Endpoints Principaux</h3>
                    
                    <div className="space-y-4">
                      <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-gray-900">GET /api/projects</h4>
                          <span className="bg-green-100 text-green-700 px-2 py-1 rounded text-sm">GET</span>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">Récupérer la liste des projets avec filtres optionnels</p>
                        <div className="bg-gray-900 rounded p-2">
                          <code className="text-green-400 text-sm">
                            curl -H "Authorization: Bearer YOUR_API_KEY" \\<br/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;https://api.solutions-afrique.org/projects
                          </code>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg p-4 border-l-4 border-blue-500">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-gray-900">POST /api/investments</h4>
                          <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded text-sm">POST</span>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">Créer un nouvel investissement avec traçabilité blockchain</p>
                        <div className="bg-gray-900 rounded p-2">
                          <code className="text-green-400 text-sm">
                            curl -X POST -H "Content-Type: application/json" \\<br/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-d '{{"project_id": 1, "amount": 50000}}' \\<br/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;https://api.solutions-afrique.org/investments
                          </code>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg p-4 border-l-4 border-purple-500">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-gray-900">POST /api/ai/recommendations</h4>
                          <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded text-sm">POST</span>
                        </div>
                        <p className="text-gray-600 text-sm mb-2">Obtenir des recommandations personnalisées via IA</p>
                        <div className="bg-gray-900 rounded p-2">
                          <code className="text-green-400 text-sm">
                            curl -X POST -H "Content-Type: application/json" \\<br/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;-d '{{"user_profile": "investisseur"}}' \\<br/>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;https://api.solutions-afrique.org/ai/recommendations
                          </code>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white border border-gray-200 rounded-xl p-6">
                      <h3 className="font-bold text-gray-900 mb-4">Authentification</h3>
                      <div className="space-y-3">
                        <div className="bg-gray-50 p-3 rounded">
                          <div className="font-semibold text-sm mb-1">Header requis:</div>
                          <code className="text-purple-600">Authorization: Bearer YOUR_API_KEY</code>
                        </div>
                        <div className="bg-gray-50 p-3 rounded">
                          <div className="font-semibold text-sm mb-1">Content-Type:</div>
                          <code className="text-purple-600">application/json</code>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white border border-gray-200 rounded-xl p-6">
                      <h3 className="font-bold text-gray-900 mb-4">Limites de Taux</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Requêtes/heure:</span>
                          <span className="font-semibold">1,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Requêtes/jour:</span>
                          <span className="font-semibold">10,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Timeout:</span>
                          <span className="font-semibold">30s</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {['projects', 'investments', 'analytics', 'ai', 'blockchain', 'security', 'examples'].includes(activeSection) && (
                <div className="text-center py-12">
                  <i className="ri-file-text-line text-6xl text-gray-300 mb-4"></i>
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">
                    Section en Construction
                  </h3>
                  <p className="text-gray-600 mb-6">
                    Cette section de documentation sera complétée prochainement avec des exemples détaillés et des guides pratiques.
                  </p>
                  <button 
                    onClick={() => setActiveSection('overview')}
                    className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-medium"
                  >
                    Retour à la Vue d'ensemble
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}