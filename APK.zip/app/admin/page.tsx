'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';
import Header from '../../components/Header';
import Footer from '../../components/Footer';

export default function AdminPage() {
  const [activeSection, setActiveSection] = useState('dashboard');
  const [projects, setProjects] = useState([]);
  const [investments, setInvestments] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [projectsRes, investmentsRes] = await Promise.all([
        supabase.from('projects').select('*').order('created_at', { ascending: false }),
        supabase.from('investments').select('*, projects(name)').order('created_at', { ascending: false })
      ]);

      if (projectsRes.data) setProjects(projectsRes.data);
      if (investmentsRes.data) setInvestments(investmentsRes.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const adminSections = [
    { id: 'dashboard', label: 'Tableau de Bord', icon: 'ri-dashboard-line' },
    { id: 'projects', label: 'Gestion Projets', icon: 'ri-folder-line' },
    { id: 'investments', label: 'Suivi Investissements', icon: 'ri-funds-line' },
    { id: 'analytics', label: 'Analytics Avancées', icon: 'ri-bar-chart-line' },
    { id: 'users', label: 'Gestion Utilisateurs', icon: 'ri-user-line' },
    { id: 'reports', label: 'Rapports', icon: 'ri-file-chart-line' }
  ];

  const quickStats = {
    totalProjects: projects.length,
    totalInvestments: investments.reduce((sum, inv) => sum + parseFloat(inv.amount || 0), 0),
    avgROI: investments.length > 0 ? 
      investments.reduce((sum, inv) => sum + parseFloat(inv.expected_roi || 0), 0) / investments.length : 0,
    completedProjects: projects.filter(p => p.progress === 100).length
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Administration Solutions Afrique
          </h1>
          <p className="text-gray-600">
            Interface de gestion complète pour le pilotage de la plateforme
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="font-bold text-gray-900 mb-4">Sections</h2>
              <nav className="space-y-2">
                {adminSections.map(section => (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full text-left px-4 py-3 rounded-lg font-medium transition-all flex items-center gap-3 ${
                      activeSection === section.id
                        ? 'bg-green-600 text-white'
                        : 'text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <i className={`${section.icon} text-lg`}></i>
                    {section.label}
                  </button>
                ))}
              </nav>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-lg p-6 mt-6">
              <h2 className="font-bold text-gray-900 mb-4">Actions Rapides</h2>
              <div className="space-y-3">
                <button className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors text-sm font-medium">
                  Nouveau Projet
                </button>
                <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-sm font-medium">
                  Exporter Données
                </button>
                <button className="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors text-sm font-medium">
                  Rapport Mensuel
                </button>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {activeSection === 'dashboard' && (
              <div className="space-y-6">
                {/* Quick Stats */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <div className="bg-white rounded-xl p-6 shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                        <i className="ri-folder-line text-blue-600 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-gray-900">{quickStats.totalProjects}</div>
                        <div className="text-gray-600 text-sm">Projets Total</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-6 shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                        <i className="ri-funds-line text-green-600 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-gray-900">
                          €{(quickStats.totalInvestments/1000000).toFixed(1)}M
                        </div>
                        <div className="text-gray-600 text-sm">Investissements</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-6 shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <i className="ri-percent-line text-purple-600 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-gray-900">
                          {quickStats.avgROI.toFixed(1)}%
                        </div>
                        <div className="text-gray-600 text-sm">ROI Moyen</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-6 shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                        <i className="ri-check-double-line text-orange-600 text-xl"></i>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-gray-900">{quickStats.completedProjects}</div>
                        <div className="text-gray-600 text-sm">Projets Terminés</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-white rounded-xl shadow-lg p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-4">Activité Récente</h3>
                  <div className="space-y-4">
                    {loading ? (
                      <div className="text-center py-8">
                        <i className="ri-loader-4-line text-2xl text-gray-400 animate-spin"></i>
                      </div>
                    ) : (
                      investments.slice(0, 5).map((investment, index) => (
                        <div key={index} className="flex items-center justify-between border-b border-gray-100 pb-3">
                          <div>
                            <div className="font-semibold text-gray-900">
                              Nouvel investissement
                            </div>
                            <div className="text-sm text-gray-600">
                              €{investment.amount?.toLocaleString()} • {investment.projects?.name || 'Projet'}
                            </div>
                          </div>
                          <div className="text-sm text-gray-500">
                            {new Date(investment.created_at).toLocaleDateString()}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            )}

            {activeSection === 'projects' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold text-gray-900">Gestion des Projets</h3>
                  <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors font-medium">
                    Ajouter Projet
                  </button>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="text-left p-4 font-semibold text-gray-700">Nom</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Secteur</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Phase</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Progression</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Budget</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {projects.slice(0, 10).map((project) => (
                        <tr key={project.id} className="border-b border-gray-100 hover:bg-gray-50">
                          <td className="p-4">
                            <div className="font-semibold text-gray-900">{project.name}</div>
                            <div className="text-sm text-gray-600">{project.country}</div>
                          </td>
                          <td className="p-4 text-gray-700">{project.sector}</td>
                          <td className="p-4">
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              project.phase === 'study' ? 'bg-blue-100 text-blue-700' :
                              project.phase === 'funding' ? 'bg-yellow-100 text-yellow-700' :
                              project.phase === 'deployment' ? 'bg-green-100 text-green-700' :
                              'bg-purple-100 text-purple-700'
                            }`}>
                              {project.phase}
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <div className="w-20 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-green-500 h-2 rounded-full"
                                  style={{ width: `${project.progress}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium">{project.progress}%</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="font-semibold text-gray-900">
                              €{(project.budget_total/1000000).toFixed(1)}M
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <button className="text-blue-600 hover:text-blue-800">
                                <i className="ri-edit-line"></i>
                              </button>
                              <button className="text-green-600 hover:text-green-800">
                                <i className="ri-eye-line"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeSection === 'investments' && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Suivi des Investissements</h3>
                
                <div className="space-y-4">
                  {investments.slice(0, 10).map((investment) => (
                    <div key={investment.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all">
                      <div className="flex justify-between items-center">
                        <div>
                          <div className="font-semibold text-gray-900">
                            {investment.investor_name}
                          </div>
                          <div className="text-sm text-gray-600">
                            Projet: {investment.projects?.name || 'N/A'}
                          </div>
                          <div className="text-xs text-gray-500">
                            {new Date(investment.created_at).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-bold text-green-600">
                            €{investment.amount?.toLocaleString()}
                          </div>
                          <div className="text-sm text-blue-600">
                            ROI: {investment.expected_roi}%
                          </div>
                          <div className="text-xs text-gray-500">
                            Hash: {investment.blockchain_hash?.slice(0, 8)}...
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {['analytics', 'users', 'reports'].includes(activeSection) && (
              <div className="bg-white rounded-xl shadow-lg p-12 text-center">
                <i className="ri-tools-line text-6xl text-gray-300 mb-4"></i>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">
                  Section en Développement
                </h3>
                <p className="text-gray-600 mb-6">
                  Cette fonctionnalité sera disponible dans une prochaine version.
                </p>
                <button className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors font-medium">
                  Retour au Dashboard
                </button>
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}