
import ProjectsHero from './ProjectsHero';
import BusinessCanvas from './BusinessCanvas';
import ImpactAnalysis from './ImpactAnalysis';
import CollaborativeInterface from './CollaborativeInterface';
import ProjectTracking from './ProjectTracking';
import InvestmentSystem from './InvestmentSystem';
import AIRecommendations from './AIRecommendations';

export default function ProjectsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <ProjectsHero />
      <BusinessCanvas />
      <ImpactAnalysis />
      <CollaborativeInterface />
      <ProjectTracking />
      <InvestmentSystem />
      <AIRecommendations />
    </div>
  );
}