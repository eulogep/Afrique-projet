'use client';
import { useState, useEffect } from 'react';
import { supabase, Project } from '../../lib/supabase';

export default function ProjectTracking() {
  const [selectedPhase, setSelectedPhase] = useState('all');
  const [viewMode, setViewMode] = useState('grid');
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  // Fetch projects from Supabase
  const fetchProjects = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from('projects')
        .select('*')
        .order('created_at', { ascending: false });

      if (selectedPhase !== 'all') {
        query = query.eq('phase', selectedPhase);
      }

      const { data, error } = await query;

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  // Update project progress
  const updateProgress = async (projectId: number, newProgress: number) => {
    try {
      const { data, error } = await supabase.functions.invoke('investment-tracker', {
        body: { 
          action: 'update_project_progress',
          data: { projectId, progress: newProgress }
        }
      });

      if (error) throw error;
      
      // Refresh projects list
      fetchProjects();
    } catch (error) {
      console.error('Error updating project:', error);
    }
  };

  useEffect(() => {
    fetchProjects();
  }, [selectedPhase]);

  const phases = {
    all: { label: 'All Projects', count: projects.length, color: 'gray' },
    study: { label: 'Study', count: projects.filter(p => p.phase === 'study').length, color: 'blue' },
    funding: { label: 'Funding', count: projects.filter(p => p.phase === 'funding').length, color: 'yellow' },
    deployment: { label: 'Deployment', count: projects.filter(p => p.phase === 'deployment').length, color: 'green' },
    closure: { label: 'Closure', count: projects.filter(p => p.phase === 'closure').length, color: 'purple' }
  };

  const filteredProjects = selectedPhase === 'all' ? projects : projects.filter(p => p.phase === selectedPhase);

  const getRiskColor = (level: string) => {
    switch(level) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-orange-600 bg-orange-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPhaseColor = (phase: string) => {
    switch(phase) {
      case 'study': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'funding': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'deployment': return 'bg-green-100 text-green-700 border-green-200';
      case 'closure': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  // Mock data for next milestones and risks (in real app would come from database)
  const getMockData = (projectId: number) => ({
    risks: [
      { level: 'medium', description: 'Equipment delivery delays' },
      { level: 'low', description: 'Weather conditions' }
    ],
    nextMilestones: [
      { date: '2024-04-15', task: 'Phase 3 installation completion' },
      { date: '2024-05-30', task: 'Technical training program' }
    ]
  });

  return (
    <div className="py-20 bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Real-Time Project Tracking
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Total transparency on each project's progress with real-time metrics, 
            risk management and updated impact forecasts
          </p>
        </div>

        {/* Phase filters */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-2xl p-2 shadow-lg border border-gray-200 flex flex-wrap gap-2">
            {Object.entries(phases).map(([key, phase]) => (
              <button
                key={key}
                onClick={() => setSelectedPhase(key)}
                className={`px-6 py-3 rounded-xl font-semibold transition-all duration-300 flex items-center gap-2 whitespace-nowrap ${
                  selectedPhase === key
                    ? `bg-${phase.color}-600 text-white shadow-lg transform scale-105`
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                {phase.label} ({phase.count})
              </button>
            ))}
          </div>
        </div>

        {/* Display controls */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-4">
            <span className="text-gray-600 font-medium">
              {filteredProjects.length} project{filteredProjects.length > 1 ? 's' : ''} found
              {loading && <span className="text-blue-600 ml-2">(Loading...)</span>}
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'grid' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <i className="ri-grid-line text-xl"></i>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg transition-colors ${viewMode === 'list' ? 'bg-blue-100 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <i className="ri-list-check text-xl"></i>
            </button>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-gray-100 rounded-3xl h-96 animate-pulse"></div>
            ))}
          </div>
        ) : (
          <>
            {/* Grid view */}
            {viewMode === 'grid' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {filteredProjects.map((project) => {
                  const mockData = getMockData(project.id);
                  return (
                    <div key={project.id} className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300">
                      <div className="relative">
                        <img
                          src={project.image_url}
                          alt={project.name}
                          className="w-full h-48 object-cover object-top"
                        />
                        <div className="absolute top-4 left-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getPhaseColor(project.phase)}`}>
                            {project.phase.charAt(0).toUpperCase() + project.phase.slice(1)}
                          </span>
                        </div>
                        <div className="absolute top-4 right-4">
                          <div className="bg-white/90 backdrop-blur-sm rounded-full px-3 py-1 text-sm font-bold text-gray-900">
                            {project.progress}%
                          </div>
                        </div>
                      </div>

                      <div className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <h3 className="text-xl font-bold text-gray-900">{project.name}</h3>
                        </div>

                        {/* Progress bar */}
                        <div className="mb-6">
                          <div className="flex justify-between text-sm text-gray-600 mb-2">
                            <span>Global progress</span>
                            <span>{project.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500"
                              style={{ width: `${project.progress}%` }}
                            ></div>
                          </div>
                          <div className="flex justify-between mt-2">
                            <button
                              onClick={() => updateProgress(project.id, Math.max(0, project.progress - 5))}
                              className="text-xs px-2 py-1 bg-gray-200 rounded hover:bg-gray-300 transition-colors"
                            >
                              -5%
                            </button>
                            <button
                              onClick={() => updateProgress(project.id, Math.min(100, project.progress + 5))}
                              className="text-xs px-2 py-1 bg-blue-200 rounded hover:bg-blue-300 transition-colors"
                            >
                              +5%
                            </button>
                          </div>
                        </div>

                        {/* Key metrics */}
                        <div className="grid grid-cols-2 gap-4 mb-6">
                          <div className="text-center bg-gray-50 rounded-xl p-3">
                            <div className="text-lg font-bold text-gray-900">€{(project.budget_total/1000000).toFixed(1)}M</div>
                            <div className="text-xs text-gray-600">Total Budget</div>
                          </div>
                          <div className="text-center bg-gray-50 rounded-xl p-3">
                            <div className="text-lg font-bold text-green-600">{project.roi_projected}%</div>
                            <div className="text-xs text-gray-600">Projected ROI</div>
                          </div>
                        </div>

                        {/* Manager */}
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                              <i className="ri-user-line text-blue-600"></i>
                            </div>
                            <span className="text-sm text-gray-600">{project.manager_name}</span>
                          </div>
                          <span className="text-sm text-gray-500">{project.beneficiaries.toLocaleString()} beneficiaries</span>
                        </div>

                        {/* Risks */}
                        {mockData.risks.length > 0 && (
                          <div className="mb-4">
                            <div className="text-sm font-semibold text-gray-700 mb-2">Identified risks:</div>
                            <div className="flex flex-wrap gap-2">
                              {mockData.risks.map((risk, index) => (
                                <span key={index} className={`text-xs px-2 py-1 rounded-full ${getRiskColor(risk.level)}`}>
                                  {risk.description}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Next steps */}
                        <div className="border-t border-gray-100 pt-4">
                          <div className="text-sm font-semibold text-gray-700 mb-2">Next steps:</div>
                          <div className="space-y-1">
                            {mockData.nextMilestones.slice(0, 2).map((milestone, index) => (
                              <div key={index} className="text-xs text-gray-600 flex items-center gap-2">
                                <div className="w-1 h-1 bg-blue-400 rounded-full"></div>
                                <span className="font-medium">{milestone.date}</span> - {milestone.task}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* List view */}
            {viewMode === 'list' && (
              <div className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="text-left p-4 font-semibold text-gray-700">Project</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Phase</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Progress</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Budget</th>
                        <th className="text-left p-4 font-semibold text-gray-700">ROI</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Manager</th>
                        <th className="text-left p-4 font-semibold text-gray-700">Country</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredProjects.map((project, index) => (
                        <tr key={project.id} className={`border-b border-gray-100 hover:bg-gray-50 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}`}>
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <img
                                src={project.image_url}
                                alt={project.name}
                                className="w-12 h-12 object-cover object-top rounded-lg"
                              />
                              <div>
                                <div className="font-semibold text-gray-900">{project.name}</div>
                                <div className="text-sm text-gray-600">{project.beneficiaries.toLocaleString()} beneficiaries</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getPhaseColor(project.phase)}`}>
                              {project.phase.charAt(0).toUpperCase() + project.phase.slice(1)}
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-3">
                              <div className="w-20 bg-gray-200 rounded-full h-2">
                                <div 
                                  className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full"
                                  style={{ width: `${project.progress}%` }}
                                ></div>
                              </div>
                              <span className="text-sm font-medium">{project.progress}%</span>
                            </div>
                          </td>
                          <td className="p-4">
                            <div className="text-sm">
                              <div className="font-semibold text-gray-900">€{(project.budget_total/1000000).toFixed(1)}M</div>
                              <div className="text-gray-600">Spent: €{(project.budget_spent/1000000).toFixed(1)}M</div>
                            </div>
                          </td>
                          <td className="p-4">
                            <span className="font-semibold text-green-600">{project.roi_projected}%</span>
                          </td>
                          <td className="p-4">
                            <span className="text-sm text-gray-700">{project.manager_name}</span>
                          </td>
                          <td className="p-4">
                            <span className="text-sm text-gray-700">{project.country}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </>
        )}

        {/* Real-time update notification */}
        <div className="mt-8 bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-6 border border-blue-100">
          <div className="flex items-center justify-center gap-4">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-gray-700 font-medium">
              Connected to Supabase • Real-time updates active • Last sync: {new Date().toLocaleTimeString()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}