
'use client';
import { useState } from 'react';

export default function BusinessCanvas() {
  const [selectedProject, setSelectedProject] = useState('solar-senegal');
  const [showCanvas, setShowCanvas] = useState(false);

  const projects = {
    'solar-senegal': {
      title: 'SolarVillage Sénégal',
      subtitle: 'Solutions énergétiques rurales durables',
      image: 'https://readdy.ai/api/search-image?query=Solar%20panels%20installation%20in%20Senegalese%20rural%20village%2C%20African%20workers%20installing%20solar%20equipment%2C%20traditional%20houses%20with%20modern%20solar%20technology%2C%20bright%20sunlight%2C%20sustainable%20energy%20development%2C%20community%20gathering%2C%20professional%20photography&width=800&height=600&seq=solar-senegal&orientation=landscape',
      canvas: {
        partners: ['Ministère Énergie Sénégal', 'SolarTech Africa', 'Banque Mondiale'],
        activities: ['Installation panneaux solaires', 'Formation technique locale', 'Maintenance préventive'],
        resources: ['Équipements solaires', 'Expertise technique', 'Financement initial'],
        value: 'Électrification rurale accessible et durable pour 15,000 habitants',
        relations: ['Support communautaire', 'Formation continue', 'Assistance technique 24/7'],
        channels: ['Coopératives locales', 'Agents terrain', 'Application mobile'],
        segments: ['Ménages ruraux', 'Écoles et centres de santé', 'Petites entreprises'],
        costs: ['Équipements: €2.3M', 'Installation: €800K', 'Formation: €200K', 'Maintenance: €150K/an'],
        revenue: ['Abonnements mensuels: €45/ménage', 'Services entreprises: €200/mois', 'Formation: €50/personne']
      },
      metrics: {
        investment: '€3.8M',
        roi: '28.4%',
        beneficiaires: '15,247',
        jobs: '89',
        co2: '2,340 tonnes/an'
      }
    },
    'agritech-ghana': {
      title: 'SmartFarm Ghana',
      subtitle: 'Agriculture de précision pour petits exploitants',
      image: 'https://readdy.ai/api/search-image?query=Modern%20agricultural%20technology%20in%20Ghana%2C%20African%20farmers%20using%20tablets%20and%20sensors%20in%20crop%20fields%2C%20precision%20agriculture%20equipment%2C%20green%20crops%2C%20data%20analysis%20tools%2C%20sustainable%20farming%20practices%2C%20technology%20integration&width=800&height=600&seq=agritech-ghana&orientation=landscape',
      canvas: {
        partners: ['Université d\'Agriculture Ghana', 'AgriTech Solutions', 'FAO'],
        activities: ['Capteurs IoT agriculture', 'Analyse données climatiques', 'Conseil agricole personnalisé'],
        resources: ['Capteurs IoT', 'Plateforme IA', 'Réseau agronomes'],
        value: 'Augmentation rendements de 40% via agriculture de précision',
        relations: ['Formation agriculteurs', 'Support technique', 'Communauté d\'échange'],
        channels: ['Coopératives agricoles', 'Centres ruraux', 'Application mobile'],
        segments: ['Petits exploitants', 'Coopératives agricoles', 'Agro-industries'],
        costs: ['R&D: €1.2M', 'Capteurs: €800K', 'Plateforme: €600K', 'Support: €300K/an'],
        revenue: ['Abonnements: €25/mois/exploitant', 'Données premium: €100/mois', 'Formation: €75/session']
      },
      metrics: {
        investment: '€2.9M',
        roi: '34.7%',
        beneficiaires: '8,456',
        jobs: '67',
        co2: '1,890 tonnes/an'
      }
    }
  };

  const currentProject = projects[selectedProject];

  return (
    <div className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Business Model Canvas
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Analyse détaillée de nos projets phares avec modèles économiques transparents 
            et métriques d'impact vérifiables
          </p>
        </div>

        {/* Sélecteur de projets */}
        <div className="flex justify-center mb-12">
          <div className="bg-gray-100 rounded-full p-2 flex gap-2">
            {Object.entries(projects).map(([key, project]) => (
              <button
                key={key}
                onClick={() => setSelectedProject(key)}
                className={`px-6 py-3 rounded-full font-medium transition-all duration-300 whitespace-nowrap ${
                  selectedProject === key
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'text-gray-600 hover:text-blue-600'
                }`}
              >
                {project.title}
              </button>
            ))}
          </div>
        </div>

        {/* Carte projet principal */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-3xl p-8 mb-12 border border-blue-100">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-3">
                {currentProject.title}
              </h3>
              <p className="text-xl text-gray-600 mb-8">
                {currentProject.subtitle}
              </p>
              
              {/* Métriques clés */}
              <div className="grid grid-cols-2 gap-6 mb-8">
                <div className="bg-white rounded-xl p-4 border border-blue-100">
                  <div className="text-2xl font-bold text-blue-600 mb-1">
                    {currentProject.metrics.investment}
                  </div>
                  <div className="text-sm text-gray-600">Investissement Total</div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-green-100">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    {currentProject.metrics.roi}
                  </div>
                  <div className="text-sm text-gray-600">ROI Projeté</div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-purple-100">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    {currentProject.metrics.beneficiaires}
                  </div>
                  <div className="text-sm text-gray-600">Bénéficiaires</div>
                </div>
                <div className="bg-white rounded-xl p-4 border border-orange-100">
                  <div className="text-2xl font-bold text-orange-600 mb-1">
                    {currentProject.metrics.jobs}
                  </div>
                  <div className="text-sm text-gray-600">Emplois Créés</div>
                </div>
              </div>

              <button
                onClick={() => setShowCanvas(!showCanvas)}
                className="bg-blue-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-blue-700 transition-all duration-300 whitespace-nowrap"
              >
                <i className="ri-layout-grid-line mr-2"></i>
                {showCanvas ? 'Masquer' : 'Voir'} le Business Canvas
              </button>
            </div>

            <div>
              <img
                src={currentProject.image}
                alt={currentProject.title}
                className="w-full h-80 object-cover object-top rounded-2xl shadow-lg"
              />
            </div>
          </div>
        </div>

        {/* Business Canvas détaillé */}
        {showCanvas && (
          <div className="bg-white rounded-3xl border-2 border-blue-100 p-8 mb-12">
            <h4 className="text-2xl font-bold text-center mb-8 text-gray-900">
              Business Model Canvas - {currentProject.title}
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Partenaires clés */}
              <div className="bg-red-50 p-6 rounded-xl border-l-4 border-red-400">
                <h5 className="font-bold text-red-700 mb-3 flex items-center">
                  <i className="ri-team-line mr-2"></i>
                  Partenaires Clés
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.partners.map((partner, index) => (
                    <li key={index} className="text-red-600">• {partner}</li>
                  ))}
                </ul>
              </div>

              {/* Activités clés */}
              <div className="bg-orange-50 p-6 rounded-xl border-l-4 border-orange-400">
                <h5 className="font-bold text-orange-700 mb-3 flex items-center">
                  <i className="ri-settings-line mr-2"></i>
                  Activités Clés
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.activities.map((activity, index) => (
                    <li key={index} className="text-orange-600">• {activity}</li>
                  ))}
                </ul>
              </div>

              {/* Ressources clés */}
              <div className="bg-yellow-50 p-6 rounded-xl border-l-4 border-yellow-400">
                <h5 className="font-bold text-yellow-700 mb-3 flex items-center">
                  <i className="ri-database-line mr-2"></i>
                  Ressources Clés
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.resources.map((resource, index) => (
                    <li key={index} className="text-yellow-600">• {resource}</li>
                  ))}
                </ul>
              </div>

              {/* Proposition de valeur */}
              <div className="md:col-span-3 bg-green-50 p-8 rounded-xl border-l-4 border-green-400 text-center">
                <h5 className="font-bold text-green-700 mb-3 flex items-center justify-center">
                  <i className="ri-star-line mr-2"></i>
                  Proposition de Valeur
                </h5>
                <p className="text-green-600 font-medium text-lg">
                  {currentProject.canvas.value}
                </p>
              </div>

              {/* Relations clients */}
              <div className="bg-blue-50 p-6 rounded-xl border-l-4 border-blue-400">
                <h5 className="font-bold text-blue-700 mb-3 flex items-center">
                  <i className="ri-customer-service-line mr-2"></i>
                  Relations Clients
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.relations.map((relation, index) => (
                    <li key={index} className="text-blue-600">• {relation}</li>
                  ))}
                </ul>
              </div>

              {/* Canaux */}
              <div className="bg-purple-50 p-6 rounded-xl border-l-4 border-purple-400">
                <h5 className="font-bold text-purple-700 mb-3 flex items-center">
                  <i className="ri-roadmap-line mr-2"></i>
                  Canaux
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.channels.map((channel, index) => (
                    <li key={index} className="text-purple-600">• {channel}</li>
                  ))}
                </ul>
              </div>

              {/* Segments clients */}
              <div className="bg-pink-50 p-6 rounded-xl border-l-4 border-pink-400">
                <h5 className="font-bold text-pink-700 mb-3 flex items-center">
                  <i className="ri-group-line mr-2"></i>
                  Segments Clients
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.segments.map((segment, index) => (
                    <li key={index} className="text-pink-600">• {segment}</li>
                  ))}
                </ul>
              </div>

              {/* Structure des coûts */}
              <div className="md:col-span-1 bg-red-100 p-6 rounded-xl border-l-4 border-red-500">
                <h5 className="font-bold text-red-800 mb-3 flex items-center">
                  <i className="ri-money-dollar-circle-line mr-2"></i>
                  Structure des Coûts
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.costs.map((cost, index) => (
                    <li key={index} className="text-red-700">• {cost}</li>
                  ))}
                </ul>
              </div>

              {/* Sources de revenus */}
              <div className="md:col-span-2 bg-green-100 p-6 rounded-xl border-l-4 border-green-500">
                <h5 className="font-bold text-green-800 mb-3 flex items-center">
                  <i className="ri-money-euro-circle-line mr-2"></i>
                  Sources de Revenus
                </h5>
                <ul className="text-sm space-y-2">
                  {currentProject.canvas.revenue.map((revenue, index) => (
                    <li key={index} className="text-green-700">• {revenue}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}