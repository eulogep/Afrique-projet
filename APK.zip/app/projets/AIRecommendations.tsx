
'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

export default function AIRecommendations() {
  const [userProfile, setUserProfile] = useState('investisseur');
  const [showPersonalization, setShowPersonalization] = useState(false);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(false);

  const profiles = {
    investisseur: {
      title: 'Investisseur Impact',
      icon: 'ri-funds-line',
      description: 'Recherche rendement et impact social',
      preferences: ['ROI élevé', 'Impact mesurable', 'Diversification']
    },
    innovateur: {
      title: 'Innovateur',
      icon: 'ri-lightbulb-line',
      description: 'Créateur de solutions technologiques',
      preferences: ['Innovation tech', 'Scalabilité', 'Disruption']
    },
    collectivite: {
      title: 'Collectivité',
      icon: 'ri-government-line',
      description: 'Représentant institutionnel',
      preferences: ['Bien commun', 'Développement local', 'Durabilité']
    },
    ong: {
      title: 'ONG/Association',
      icon: 'ri-heart-line',
      description: 'Organisation à but non lucratif',
      preferences: ['Impact social', 'Communautés', 'Transparence']
    }
  };

  const aiRecommendations = {
    investisseur: [
      {
        project: 'GreenEnergy Cameroun',
        match: 96,
        reason: 'ROI projeté de 32% avec fort impact environnemental',
        sector: 'Énergie Renouvelable',
        investment: '€750K recherchés',
        timeline: '18 mois',
        risk: 'Modéré',
        image: 'https://readdy.ai/api/search-image?query=Modern%20solar%20energy%20facility%20in%20Cameroon%2C%20large%20scale%20renewable%20energy%20project%2C%20solar%20panels%20installation%2C%20green%20technology%20infrastructure%2C%20investment%20opportunity%20visualization&width=400&height=300&seq=green-cameroun&orientation=landscape',
        highlights: ['Contrats gouvernementaux sécurisés', 'Équipe expérimentée', 'Marché en croissance +40%/an']
      },
      {
        project: 'FinTech Inclusive RDC',
        match: 93,
        reason: 'Marché sous-bancarisé avec potentiel de croissance exponentiel',
        sector: 'Services Financiers',
        investment: '€1.2M recherchés',
        timeline: '24 mois',
        risk: 'Modéré-Élevé',
        image: 'https://readdy.ai/api/search-image?query=Digital%20financial%20services%20in%20Democratic%20Republic%20of%20Congo%2C%20mobile%20banking%20technology%2C%20fintech%20innovation%2C%20inclusive%20finance%20solutions%2C%20modern%20financial%20infrastructure&width=400&height=300&seq=fintech-rdc&orientation=landscape',
        highlights: ['8M de non-bancarisés', 'Partenariat avec banques locales', 'Croissance 150% prévue']
      },
      {
        project: 'AgriDrone Burkina',
        match: 89,
        reason: 'Innovation agricole avec retours mesurables',
        sector: 'AgriTech',
        investment: '€650K recherchés',
        timeline: '15 mois',
        risk: 'Faible-Modéré',
        image: 'https://readdy.ai/api/search-image?query=Agricultural%20drones%20in%20Burkina%20Faso%2C%20precision%20farming%20technology%2C%20aerial%20crop%20monitoring%2C%20modern%20agriculture%20innovation%2C%20drone%20technology%20in%20African%20farming&width=400&height=300&seq=agridrone-bf&orientation=landscape',
        highlights: ['Augmentation rendement +35%', 'Réduction coûts -25%', 'Déjà 500 agriculteurs pilotes']
      }
    ],
    innovateur: [
      {
        project: 'IoT WaterSense Mali',
        match: 98,
        reason: 'Technologie IoT innovante pour gestion intelligente de l\'eau',
        sector: 'WaterTech',
        investment: '€450K recherchés',
        timeline: '12 mois',
        risk: 'Modéré',
        image: 'https://readdy.ai/api/search-image?query=Smart%20water%20management%20IoT%20sensors%20in%20Mali%2C%20water%20quality%20monitoring%20technology%2C%20intelligent%20water%20systems%2C%20sensor%20networks%20in%20African%20water%20infrastructure&width=400&height=300&seq=watersense-mali&orientation=landscape',
        highlights: ['Capteurs IoT propriétaires', 'IA prédictive', 'Marché 50M$ en croissance']
      },
      {
        project: 'EduVR Sénégal',
        match: 94,
        reason: 'Réalité virtuelle pour éducation immersive',
        sector: 'EdTech',
        investment: '€800K recherchés',
        timeline: '18 mois',
        risk: 'Modéré-Élevé',
        image: 'https://readdy.ai/api/search-image?query=Virtual%20reality%20education%20technology%20in%20Senegal%2C%20VR%20headsets%20in%20African%20classroom%2C%20immersive%20learning%20experience%2C%20educational%20innovation%20technology&width=400&height=300&seq=eduvr-senegal&orientation=landscape',
        highlights: ['Première solution VR éducative', 'Partenariat ministère', 'Contenu localisé']
      }
    ],
    collectivite: [
      {
        project: 'SmartCity Abidjan',
        match: 95,
        reason: 'Infrastructure urbaine intelligente pour développement durable',
        sector: 'Urban Tech',
        investment: '€2.5M recherchés',
        timeline: '30 mois',
        risk: 'Faible',
        image: 'https://readdy.ai/api/search-image?query=Smart%20city%20infrastructure%20in%20Abidjan%20Ivory%20Coast%2C%20urban%20development%20technology%2C%20intelligent%20traffic%20systems%2C%20modern%20city%20planning%2C%20sustainable%20urban%20solutions&width=400&height=300&seq=smartcity-abidjan&orientation=landscape',
        highlights: ['Réduction trafic -30%', 'Efficacité énergétique +45%', 'Création 1200 emplois']
      }
    ],
    ong: [
      {
        project: 'WaterForAll Niger',
        match: 97,
        reason: 'Accès à l\'eau potable pour communautés rurales',
        sector: 'Humanitarian Tech',
        investment: '€400K recherchés',
        timeline: '12 mois',
        risk: 'Faible',
        image: 'https://readdy.ai/api/search-image?query=Clean%20water%20access%20project%20in%20Niger%2C%20water%20purification%20systems%2C%20rural%20community%20water%20infrastructure%2C%20humanitarian%20water%20technology%2C%20community%20wells&width=400&height=300&seq=water-niger&orientation=landscape',
        highlights: ['25K bénéficiaires directs', 'Technologie locale', 'Formation communautaire']
      }
    ]
  };

  const fetchRecommendations = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-recommendations', {
        body: { userProfile, preferences: profiles[userProfile].preferences }
      });

      if (error) throw error;
      setRecommendations(data.recommendations || []);
    } catch (error) {
      console.error('Error fetching recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, [userProfile]);

  const aiInsights = {
    trending: [
      { sector: 'Énergie Solaire', growth: '+67%', projects: 23, investment: '€12.4M' },
      { sector: 'FinTech', growth: '+54%', projects: 18, investment: '€8.7M' },
      { sector: 'AgriTech', growth: '+41%', projects: 31, investment: '€15.2M' },
      { sector: 'HealthTech', growth: '+38%', projects: 15, investment: '€6.9M' }
    ],
    predictions: [
      {
        title: 'Boom des Solutions Énergétiques',
        probability: 92,
        timeframe: '6-12 mois',
        description: 'Forte croissance attendue du secteur énergétique avec l\'adoption massive du solaire'
      },
      {
        title: 'Émergence FinTech Rurales',
        probability: 87,
        timeframe: '12-18 mois',
        description: 'Expansion des services financiers numériques vers les zones rurales'
      },
      {
        title: 'Agriculture Connectée',
        probability: 83,
        timeframe: '18-24 mois',
        description: 'Démocratisation des technologies IoT pour l\'agriculture de précision'
      }
    ]
  };

  const currentRecommendations = recommendations.length > 0 ? recommendations : aiRecommendations[userProfile] || [];

  return (
    <div className="py-20 bg-gradient-to-br from-purple-50 via-indigo-50 to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            AI Personalized Recommendations
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Our artificial intelligence analyzes your preferences, local urgencies and market trends 
            to recommend the most suitable projects for your profile
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-2xl p-2 shadow-lg border border-gray-200 flex flex-wrap gap-2">
            {Object.entries(profiles).map(([key, profile]) => (
              <button
                key={key}
                onClick={() => setUserProfile(key)}
                className={`px-6 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center gap-3 whitespace-nowrap ${
                  userProfile === key
                    ? 'bg-purple-600 text-white shadow-lg transform scale-105'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <i className={`${profile.icon} text-xl`}></i>
                {profile.title}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100 mb-12">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center">
                <i className={`${profiles[userProfile].icon} text-2xl text-purple-600`}></i>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{profiles[userProfile].title}</h3>
                <p className="text-gray-600">{profiles[userProfile].description}</p>
              </div>
            </div>
            <button
              onClick={() => setShowPersonalization(true)}
              className="bg-purple-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-purple-700 transition-colors whitespace-nowrap"
            >
              <i className="ri-settings-3-line mr-2"></i>
              Personalize
            </button>
          </div>

          <div className="flex flex-wrap gap-3">
            <span className="text-sm text-gray-600 mr-2">Preferences:</span>
            {profiles[userProfile].preferences.map((pref, index) => (
              <span key={index} className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm font-semibold">
                {pref}
              </span>
            ))}
          </div>
        </div>

        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 flex items-center">
            <i className="ri-robot-line mr-3 text-purple-600"></i>
            Recommended Projects for You
            {loading && <span className="ml-2 text-sm text-gray-500">(Updating...)</span>}
          </h3>

          {loading ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="bg-gray-100 rounded-3xl h-96 animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {currentRecommendations.map((rec, index) => (
                <div key={index} className="bg-white rounded-3xl shadow-lg border border-gray-100 overflow-hidden hover:shadow-xl transition-all duration-300">
                  <div className="relative">
                    <img
                      src={rec.image_url || rec.image}
                      alt={rec.name || rec.project}
                      className="w-full h-48 object-cover object-top"
                    />
                    <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
                      <span className="text-green-600 font-bold text-sm">{rec.aiScore || rec.match}% Match</span>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="bg-black/70 backdrop-blur-sm rounded-xl p-3 text-white">
                        <div className="font-semibold text-lg mb-1">{rec.name || rec.project}</div>
                        <div className="text-sm opacity-90">{rec.sector}</div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm text-gray-600">AI Correspondence</span>
                        <span className="font-bold text-green-600">{rec.aiScore || rec.match}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-500"
                          style={{ width: `${rec.aiScore || rec.match}%` }}
                        ></div>
                      </div>
                    </div>

                    <p className="text-gray-700 text-sm mb-4 italic">
                      "{rec.description || rec.reason || 'AI-powered recommendation based on your profile'}"
                    </p>

                    <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                      <div>
                        <div className="text-gray-500">Investment</div>
                        <div className="font-semibold">€{rec.budget_total ? (rec.budget_total/1000) + 'K' : rec.investment}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">ROI</div>
                        <div className="font-semibold">{rec.roi_projected || rec.timeline}%</div>
                      </div>
                    </div>

                    <div className="mb-4">
                      <div className="text-sm text-gray-600 mb-2">Key highlights:</div>
                      <ul className="space-y-1">
                        <li className="text-xs text-gray-700 flex items-center gap-2">
                          <div className="w-1 h-1 bg-purple-400 rounded-full"></div>
                          {rec.beneficiaries ? `${rec.beneficiaries.toLocaleString()} beneficiaries` : 'Strong market potential'}
                        </li>
                        <li className="text-xs text-gray-700 flex items-center gap-2">
                          <div className="w-1 h-1 bg-purple-400 rounded-full"></div>
                          {rec.jobs_created ? `${rec.jobs_created} jobs created` : 'Experienced team'}
                        </li>
                        <li className="text-xs text-gray-700 flex items-center gap-2">
                          <div className="w-1 h-1 bg-purple-400 rounded-full"></div>
                          {rec.co2_saved ? `${rec.co2_saved}t CO2 saved/year` : 'Sustainable growth'}
                        </li>
                      </ul>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                      <div className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        rec.phase === 'study' ? 'bg-blue-100 text-blue-700' :
                        rec.phase === 'funding' ? 'bg-yellow-100 text-yellow-700' :
                        rec.phase === 'deployment' ? 'bg-green-100 text-green-700' :
                        rec.phase === 'closure' ? 'bg-purple-100 text-purple-700' :
                        'bg-green-100 text-green-700'
                      }`}>
                        {rec.phase ? rec.phase.charAt(0).toUpperCase() + rec.phase.slice(1) : 'Low Risk'}
                      </div>
                      <button className="bg-purple-600 text-white px-4 py-2 rounded-full text-sm font-semibold hover:bg-purple-700 transition-colors whitespace-nowrap">
                        Analyze
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <i className="ri-trending-up-line mr-3 text-green-600"></i>
              Secteurs en Croissance
            </h3>

            <div className="space-y-4">
              {aiInsights.trending.map((trend, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                  <div className="flex-1">
                    <div className="font-semibold text-gray-900 mb-1">{trend.sector}</div>
                    <div className="text-sm text-gray-600">{trend.projects} projets • {trend.investment} levés</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-green-600 text-lg">{trend.growth}</div>
                    <div className="text-xs text-gray-500">croissance</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-xl font-bold text-gray-900 mb-6 flex items-center">
              <i className="ri-brain-line mr-3 text-blue-600"></i>
              Prédictions IA
            </h3>

            <div className="space-y-6">
              {aiInsights.predictions.map((prediction, index) => (
                <div key={index} className="border-l-4 border-blue-400 pl-4">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-gray-900">{prediction.title}</h4>
                    <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-semibold">
                      {prediction.probability}%
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{prediction.description}</p>
                  <div className="text-xs text-gray-500">
                    Horizon: {prediction.timeframe}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">
            Prêt à Transformer l'Afrique ?
          </h3>
          <p className="mb-8 max-w-2xl mx-auto">
            Rejoignez notre communauté d'innovateurs, d'investisseurs et de changemakers 
            pour créer un impact durable sur le continent africain
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-purple-600 px-8 py-4 rounded-full font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap">
              <i className="ri-user-add-line mr-2"></i>
              Créer Mon Profil
            </button>
            <button className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-full font-semibold hover:bg-yellow-300 transition-colors whitespace-nowrap">
              <i className="ri-rocket-line mr-2"></i>
              Explorer les Projets
            </button>
          </div>
        </div>

        {showPersonalization && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-8 max-w-2xl w-full">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold">Personalize Recommendations</h3>
                <button
                  onClick={() => setShowPersonalization(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
              
              <div className="text-center py-12">
                <i className="ri-brain-line text-6xl text-purple-300 mb-4"></i>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Advanced Personalized AI
                </h4>
                <p className="text-gray-600 mb-6">
                  AI system is now active with Supabase integration for personalized recommendations and real-time analysis
                </p>
                <div className="flex items-center justify-center gap-2 text-green-600">
                  <i className="ri-check-double-line"></i>
                  <span className="font-semibold">Supabase Connected & Active</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
