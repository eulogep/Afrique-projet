
'use client';
import { useState } from 'react';

export default function ImpactAnalysis() {
  const [selectedAnalysis, setSelectedAnalysis] = useState('social');

  const impactData = {
    social: {
      title: 'Impact Social',
      icon: 'ri-group-line',
      color: 'blue',
      metrics: [
        { label: 'Familles bénéficiaires', value: '23,847', change: '+18%', icon: 'ri-home-heart-line' },
        { label: 'Emplois créés', value: '1,247', change: '+32%', icon: 'ri-briefcase-line' },
        { label: 'Femmes entrepreneures', value: '456', change: '+45%', icon: 'ri-women-line' },
        { label: 'Formations dispensées', value: '8,934', change: '+28%', icon: 'ri-graduation-cap-line' }
      ],
      projects: [
        {
          name: 'EduTech Mali',
          impact: '2,340 étudiants formés',
          image: 'https://readdy.ai/api/search-image?query=African%20students%20learning%20with%20tablets%20and%20computers%2C%20modern%20classroom%20in%20Mali%2C%20educational%20technology%2C%20young%20people%20engaged%20in%20digital%20learning%2C%20bright%20classroom%20setting%2C%20diverse%20group%20of%20students&width=400&height=300&seq=edutech-mali&orientation=landscape'
        },
        {
          name: 'HealthCare+ RDC',
          impact: '15,000 consultations/mois',
          image: 'https://readdy.ai/api/search-image?query=Modern%20healthcare%20clinic%20in%20Democratic%20Republic%20of%20Congo%2C%20African%20doctors%20with%20medical%20technology%2C%20telemedicine%20equipment%2C%20patients%20receiving%20care%2C%20clean%20medical%20facility&width=400&height=300&seq=healthcare-rdc&orientation=landscape'
        },
        {
          name: 'WomenTech Nigeria',
          impact: '567 femmes formées',
          image: 'https://readdy.ai/api/search-image?query=African%20women%20entrepreneurs%20working%20with%20laptops%20and%20technology%2C%20business%20training%20session%20in%20Nigeria%2C%20empowerment%20workshop%2C%20professional%20setting%2C%20diverse%20group%20of%20women%20learning&width=400&height=300&seq=womentech-nigeria&orientation=landscape'
        }
      ]
    },
    environmental: {
      title: 'Impact Environnemental',
      icon: 'ri-leaf-line',
      color: 'green',
      metrics: [
        { label: 'CO2 évité', value: '145,670 t', change: '+25%', icon: 'ri-cloud-line' },
        { label: 'Énergie renouvelable', value: '89.2 GWh', change: '+41%', icon: 'ri-sun-line' },
        { label: 'Eau économisée', value: '2.8M L', change: '+15%', icon: 'ri-drop-line' },
        { label: 'Déchets valorisés', value: '34,560 t', change: '+38%', icon: 'ri-recycle-line' }
      ],
      projects: [
        {
          name: 'GreenEnergy Sénégal',
          impact: '67,000 t CO2 évité/an',
          image: 'https://readdy.ai/api/search-image?query=Large%20solar%20panel%20installation%20in%20Senegal%2C%20renewable%20energy%20infrastructure%2C%20wind%20turbines%2C%20green%20technology%2C%20sustainable%20development%2C%20clear%20blue%20sky%2C%20modern%20clean%20energy%20facility&width=400&height=300&seq=green-senegal&orientation=landscape'
        },
        {
          name: 'WaterTech Ghana',
          impact: '1.2M L eau purifiée/jour',
          image: 'https://readdy.ai/api/search-image?query=Water%20purification%20facility%20in%20Ghana%2C%20clean%20water%20technology%2C%20water%20treatment%20plant%2C%20African%20communities%20accessing%20clean%20water%2C%20modern%20water%20infrastructure&width=400&height=300&seq=water-ghana&orientation=landscape'
        },
        {
          name: 'EcoFarm Kenya',
          impact: '15,000 t déchets valorisés',
          image: 'https://readdy.ai/api/search-image?query=Sustainable%20agriculture%20farm%20in%20Kenya%2C%20organic%20farming%20practices%2C%20composting%20facility%2C%20eco-friendly%20agricultural%20technology%2C%20green%20crops%2C%20environmental%20conservation&width=400&height=300&seq=ecofarm-kenya&orientation=landscape'
        }
      ]
    },
    economic: {
      title: 'Impact Économique',
      icon: 'ri-money-euro-circle-line',
      color: 'purple',
      metrics: [
        { label: 'PIB local généré', value: '€89.4M', change: '+29%', icon: 'ri-line-chart-line' },
        { label: 'Revenus moyens', value: '+67%', change: '+12%', icon: 'ri-wallet-line' },
        { label: 'Entreprises créées', value: '1,847', change: '+34%', icon: 'ri-building-line' },
        { label: 'Investissements attirés', value: '€156M', change: '+52%', icon: 'ri-fund-line' }
      ],
      projects: [
        {
          name: 'FinTech Cameroun',
          impact: '€12M transactions/mois',
          image: 'https://readdy.ai/api/search-image?query=Modern%20fintech%20office%20in%20Cameroon%2C%20African%20professionals%20working%20with%20financial%20technology%2C%20mobile%20banking%2C%20digital%20payments%2C%20modern%20office%20environment&width=400&height=300&seq=fintech-cameroun&orientation=landscape'
        },
        {
          name: 'AgriMarket Burkina',
          impact: '3,456 producteurs connectés',
          image: 'https://readdy.ai/api/search-image?query=Agricultural%20marketplace%20in%20Burkina%20Faso%2C%20farmers%20selling%20produce%2C%20modern%20market%20infrastructure%2C%20agricultural%20products%2C%20community%20commerce%2C%20vibrant%20market%20scene&width=400&height=300&seq=agri-burkina&orientation=landscape'
        },
        {
          name: 'TechHub Côte d\'Ivoire',
          impact: '234 startups incubées',
          image: 'https://readdy.ai/api/search-image?query=Technology%20incubator%20in%20Ivory%20Coast%2C%20young%20entrepreneurs%2C%20startup%20workspace%2C%20modern%20office%2C%20innovation%20hub%2C%20collaborative%20working%20environment%2C%20tech%20development&width=400&height=300&seq=techhub-ci&orientation=landscape'
        }
      ]
    }
  };

  const currentAnalysis = impactData[selectedAnalysis];

  return (
    <div className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Analyse d'Impact Triple
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mesure scientifique de l'impact social, environnemental et économique 
            de nos projets avec données vérifiées par des organismes indépendants
          </p>
        </div>

        {/* Sélecteur d'analyse */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-2xl p-2 shadow-lg border border-gray-200 flex gap-2">
            {Object.entries(impactData).map(([key, analysis]) => (
              <button
                key={key}
                onClick={() => setSelectedAnalysis(key)}
                className={`px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center gap-3 whitespace-nowrap ${
                  selectedAnalysis === key
                    ? `bg-${analysis.color}-600 text-white shadow-lg transform scale-105`
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <i className={`${analysis.icon} text-xl`}></i>
                {analysis.title}
              </button>
            ))}
          </div>
        </div>

        {/* Métriques principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {currentAnalysis.metrics.map((metric, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300">
              <div className={`w-12 h-12 bg-${currentAnalysis.color}-100 rounded-xl flex items-center justify-center mb-4`}>
                <i className={`${metric.icon} text-xl text-${currentAnalysis.color}-600`}></i>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">
                {metric.value}
              </div>
              <div className="text-gray-600 mb-2">{metric.label}</div>
              <div className={`text-${currentAnalysis.color}-600 font-semibold text-sm flex items-center`}>
                <i className="ri-arrow-up-line mr-1"></i>
                {metric.change} vs 2023
              </div>
            </div>
          ))}
        </div>

        {/* Projets phares par impact */}
        <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
          <h3 className={`text-2xl font-bold text-${currentAnalysis.color}-900 mb-8 flex items-center`}>
            <i className={`${currentAnalysis.icon} mr-3`}></i>
            Projets Phares - {currentAnalysis.title}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {currentAnalysis.projects.map((project, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-2xl mb-4">
                  <img
                    src={project.image}
                    alt={project.name}
                    className="w-full h-48 object-cover object-top group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t from-${currentAnalysis.color}-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300`}></div>
                  <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="font-semibold text-lg">{project.name}</div>
                    <div className="text-sm opacity-90">{project.impact}</div>
                  </div>
                </div>
                <div className="p-6 bg-gray-50 rounded-xl">
                  <h4 className="font-bold text-gray-900 mb-2">{project.name}</h4>
                  <p className={`text-${currentAnalysis.color}-600 font-semibold`}>{project.impact}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Certification et validation */}
        <div className="mt-16 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-3xl p-8 border border-yellow-200">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Certification & Validation Indépendante
            </h3>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
              Nos métriques d'impact sont auditées et certifiées par des organismes indépendants reconnus internationalement
            </p>
            
            <div className="flex flex-wrap justify-center items-center gap-8">
              <div className="flex items-center gap-3 bg-white px-6 py-3 rounded-full shadow-md">
                <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                  <i className="ri-shield-check-line text-white"></i>
                </div>
                <span className="font-semibold">Bureau Veritas</span>
              </div>
              <div className="flex items-center gap-3 bg-white px-6 py-3 rounded-full shadow-md">
                <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                  <i className="ri-earth-line text-white"></i>
                </div>
                <span className="font-semibold">B-Corp Certified</span>
              </div>
              <div className="flex items-center gap-3 bg-white px-6 py-3 rounded-full shadow-md">
                <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                  <i className="ri-award-line text-white"></i>
                </div>
                <span className="font-semibold">Impact Management Project</span>
              </div>
              <div className="flex items-center gap-3 bg-white px-6 py-3 rounded-full shadow-md">
                <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                  <i className="ri-global-line text-white"></i>
                </div>
                <span className="font-semibold">GRI Standards</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}