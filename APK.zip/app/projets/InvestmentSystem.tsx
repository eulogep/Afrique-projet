
'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

export default function InvestmentSystem() {
  const [selectedInvestment, setSelectedInvestment] = useState(500);
  const [investmentType, setInvestmentType] = useState('diversifie');
  const [showPortfolio, setShowPortfolio] = useState(false);
  const [portfolio, setPortfolio] = useState({ investments: [], summary: {} });
  const [loading, setLoading] = useState(false);

  const investmentTypes = {
    diversifie: {
      title: 'Portefeuille Diversifié',
      description: 'Répartition automatique sur plusieurs secteurs',
      minInvestment: 100,
      expectedROI: '18-25%',
      riskLevel: 'Modéré',
      sectors: ['Énergie 35%', 'Agriculture 25%', 'Éducation 20%', 'Santé 20%']
    },
    energie: {
      title: 'Énergie Verte',
      description: 'Focus sur les projets énergétiques durables',
      minInvestment: 250,
      expectedROI: '22-30%',
      riskLevel: 'Modéré-Élevé',
      sectors: ['Solaire 60%', 'Éolien 25%', 'Hydro 15%']
    },
    agriculture: {
      title: 'Agriculture Durable',
      description: 'Technologies agricoles innovantes',
      minInvestment: 150,
      expectedROI: '20-28%',
      riskLevel: 'Modéré',
      sectors: ['AgriTech 50%', 'Irrigation 30%', 'Formation 20%']
    },
    impact: {
      title: 'Impact Social',
      description: 'Projets à fort impact communautaire',
      minInvestment: 100,
      expectedROI: '15-22%',
      riskLevel: 'Faible-Modéré',
      sectors: ['Éducation 40%', 'Santé 35%', 'Eau 25%']
    }
  };

  const topInvestors = [
    {
      name: 'AfriCapital Partners',
      invested: '€2.8M',
      projects: 34,
      roi: '31.2%',
      badge: 'Impact Leader',
      avatar: 'https://readdy.ai/api/search-image?query=Professional%20African%20business%20leader%20in%20modern%20office%2C%20corporate%20executive%2C%20investment%20partner%2C%20financial%20sector%20professional%2C%20confident%20business%20person&width=100&height=100&seq=investor1&orientation=squarish'
    },
    {
      name: 'Green Growth Fund',
      invested: '€2.1M',
      projects: 28,
      roi: '28.7%',
      badge: 'ESG Champion',
      avatar: 'https://readdy.ai/api/search-image?query=Sustainable%20investment%20fund%20manager%2C%20green%20finance%20professional%2C%20environmental%20investment%20specialist%2C%20modern%20office%20setting&width=100&height=100&seq=investor2&orientation=squarish'
    },
    {
      name: 'Tech4Good Ventures',
      invested: '€1.9M',
      projects: 42,
      roi: '26.4%',
      badge: 'Innovation Focus',
      avatar: 'https://readdy.ai/api/search-image?query=Technology%20venture%20capital%20investor%2C%20innovation%20fund%20manager%2C%20tech%20investment%20professional%2C%20modern%20workspace&width=100&height=100&seq=investor3&orientation=squarish'
    },
    {
      name: 'Community Impact Fund',
      invested: '€1.7M',
      projects: 38,
      roi: '24.8%',
      badge: 'Social Impact',
      avatar: 'https://readdy.ai/api/search-image?query=Social%20impact%20investor%2C%20community%20development%20fund%20manager%2C%20impact%20investment%20professional%2C%20collaborative%20workspace&width=100&height=100&seq=investor4&orientation=squarish'
    }
  ];

  const fetchPortfolio = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('investment-tracker', {
        body: { action: 'get_portfolio' }
      });

      if (error) throw error;
      setPortfolio(data);
    } catch (error) {
      console.error('Error fetching portfolio:', error);
    } finally {
      setLoading(false);
    }
  };

  const createInvestment = async () => {
    setLoading(true);
    try {
      const investmentData = {
        project_id: 1, 
        investor_name: 'Demo Investor',
        amount: selectedInvestment,
        investment_type: investmentType,
        expected_roi: parseFloat(investmentTypes[investmentType].expectedROI.split('-')[1])
      };

      const { data, error } = await supabase.functions.invoke('investment-tracker', {
        body: { action: 'create_investment', data: investmentData }
      });

      if (error) throw error;
      
      await fetchPortfolio();
      
      alert(`Investment of €${selectedInvestment} created successfully! Blockchain hash: ${data.blockchainHash}`);
    } catch (error) {
      console.error('Error creating investment:', error);
      alert('Error creating investment. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (showPortfolio) {
      fetchPortfolio();
    }
  }, [showPortfolio]);

  const calculateReturns = (amount, timeframe) => {
    const currentType = investmentTypes[investmentType];
    const avgROI = parseFloat(currentType.expectedROI.split('-')[1]) / 100;
    return Math.round(amount * (1 + avgROI * timeframe / 12));
  };

  const simulationData = [
    { months: 6, amount: selectedInvestment, returns: calculateReturns(selectedInvestment, 6) },
    { months: 12, amount: selectedInvestment, returns: calculateReturns(selectedInvestment, 12) },
    { months: 24, amount: selectedInvestment, returns: calculateReturns(selectedInvestment, 24) },
    { months: 36, amount: selectedInvestment, returns: calculateReturns(selectedInvestment, 36) }
  ];

  return (
    <div className="py-20 bg-gradient-to-br from-green-50 via-white to-blue-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Intelligent Investment System
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Invest in Africa's future with total transparency, 
            blockchain traceability and measurable social impact returns
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          {/* Investment simulator */}
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <i className="ri-calculator-line mr-3 text-green-600"></i>
              Investment Simulator
            </h3>

            {/* Investment types */}
            <div className="mb-8">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Investment type
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {Object.entries(investmentTypes).map(([key, type]) => (
                  <button
                    key={key}
                    onClick={() => setInvestmentType(key)}
                    className={`p-4 rounded-xl border-2 text-left transition-all duration-300 ${
                      investmentType === key
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                  >
                    <div className="font-semibold text-gray-900 mb-1">{type.title}</div>
                    <div className="text-sm text-gray-600 mb-2">{type.description}</div>
                    <div className="flex justify-between text-xs">
                      <span className="text-green-600 font-semibold">ROI: {type.expectedROI}</span>
                      <span className="text-gray-500">Min: €{type.minInvestment}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Investment amount */}
            <div className="mb-8">
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Investment amount (€)
              </label>
              <div className="relative">
                <input
                  type="range"
                  min={investmentTypes[investmentType].minInvestment}
                  max="10000"
                  value={selectedInvestment}
                  onChange={(e) => setSelectedInvestment(parseInt(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-2">
                  <span>€{investmentTypes[investmentType].minInvestment}</span>
                  <span className="text-2xl font-bold text-green-600">€{selectedInvestment}</span>
                  <span>€10,000</span>
                </div>
              </div>
            </div>

            {/* Sector breakdown */}
            <div className="mb-8">
              <h4 className="font-semibold text-gray-700 mb-3">Sector breakdown</h4>
              <div className="space-y-2">
                {investmentTypes[investmentType].sectors.map((sector, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">{sector.split(' ')[0]}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-2 bg-green-500 rounded-full"
                          style={{ width: sector.split(' ')[1] }}
                        ></div>
                      </div>
                      <span className="text-sm font-semibold">{sector.split(' ')[1]}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Returns projection */}
            <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl p-6 mb-6">
              <h4 className="font-semibold text-gray-700 mb-4">Returns projection</h4>
              <div className="grid grid-cols-2 gap-4">
                {simulationData.map((data, index) => (
                  <div key={index} className="bg-white rounded-xl p-4 text-center">
                    <div className="text-sm text-gray-600 mb-1">{data.months} months</div>
                    <div className="text-lg font-bold text-green-600">€{data.returns.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">
                      +€{(data.returns - data.amount).toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button 
              onClick={createInvestment}
              disabled={loading}
              className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white py-4 rounded-full font-semibold text-lg hover:from-green-700 hover:to-blue-700 transition-all duration-300 whitespace-nowrap disabled:opacity-50"
            >
              <i className="ri-secure-payment-line mr-2"></i>
              {loading ? 'Processing...' : 'Invest Now'}
            </button>
          </div>

          {/* Top investors / Portfolio */}
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900 flex items-center">
                <i className="ri-trophy-line mr-3 text-yellow-600"></i>
                {showPortfolio ? 'My Portfolio' : 'Top Investors'}
              </h3>
              <button
                onClick={() => setShowPortfolio(!showPortfolio)}
                className="text-blue-600 hover:text-blue-700 font-semibold text-sm whitespace-nowrap"
              >
                {showPortfolio ? 'View Top Investors' : 'View My Portfolio'}
              </button>
            </div>

            {showPortfolio ? (
              // Portfolio view
              <div>
                {loading ? (
                  <div className="animate-pulse space-y-4">
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded"></div>
                    <div className="h-4 bg-gray-200 rounded"></div>
                  </div>
                ) : (
                  <>
                    {portfolio.summary && (
                      <div className="grid grid-cols-3 gap-4 mb-6">
                        <div className="bg-green-50 rounded-xl p-4 text-center">
                          <div className="text-lg font-bold text-green-600">
                            €{portfolio.summary.totalInvested?.toLocaleString() || '0'}
                          </div>
                          <div className="text-xs text-gray-600">Total Invested</div>
                        </div>
                        <div className="bg-blue-50 rounded-xl p-4 text-center">
                          <div className="text-lg font-bold text-blue-600">
                            {portfolio.summary.avgROI || '0'}%
                          </div>
                          <div className="text-xs text-gray-600">Avg ROI</div>
                        </div>
                        <div className="bg-purple-50 rounded-xl p-4 text-center">
                          <div className="text-lg font-bold text-purple-600">
                            {portfolio.summary.projectCount || 0}
                          </div>
                          <div className="text-xs text-gray-600">Projects</div>
                        </div>
                      </div>
                    )}

                    <div className="space-y-4">
                      {portfolio.investments.map((investment, index) => (
                        <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl">
                          <img
                            src={investment.projects?.image_url || 'https://via.placeholder.com/60'}
                            alt={investment.projects?.name || 'Project'}
                            className="w-12 h-12 rounded-lg object-cover object-top"
                          />
                          <div className="flex-1">
                            <div className="font-semibold text-gray-900">
                              {investment.projects?.name || 'Unknown Project'}
                            </div>
                            <div className="text-sm text-gray-600">
                              €{investment.amount.toLocaleString()} • {investment.expected_roi}% ROI
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold text-green-600">
                              {investment.projects?.progress || 0}%
                            </div>
                            <div className="text-xs text-gray-500">Progress</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            ) : (
              // Top investors view (existing code)
              <div className="space-y-6">
                {topInvestors.map((investor, index) => (
                  <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-colors">
                    <div className="relative">
                      <img
                        src={investor.avatar}
                        alt={investor.name}
                        className="w-16 h-16 rounded-full object-cover object-top"
                      />
                      <div className="absolute -top-1 -right-1 w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold text-yellow-900">#{index + 1}</span>
                      </div>
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-gray-900">{investor.name}</h4>
                        <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-semibold">
                          {investor.badge}
                        </span>
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <div className="text-gray-500">Invested</div>
                          <div className="font-semibold text-green-600">{investor.invested}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Projects</div>
                          <div className="font-semibold">{investor.projects}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Avg ROI</div>
                          <div className="font-semibold text-blue-600">{investor.roi}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-8 p-6 bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl border border-purple-100">
              <div className="text-center">
                <i className="ri-shield-check-line text-3xl text-green-600 mb-3"></i>
                <h4 className="font-bold text-lg text-gray-900 mb-2">
                  Blockchain Traceability
                </h4>
                <p className="text-sm text-gray-600 mb-4">
                  All investments are recorded on blockchain for total transparency
                </p>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="bg-white rounded-lg p-3">
                    <div className="text-lg font-bold text-blue-600">100%</div>
                    <div className="text-xs text-gray-600">Traceable</div>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <div className="text-lg font-bold text-green-600">0%</div>
                    <div className="text-xs text-gray-600">Hidden Fees</div>
                  </div>
                  <div className="bg-white rounded-lg p-3">
                    <div className="text-lg font-bold text-purple-600">24/7</div>
                    <div className="text-xs text-gray-600">Monitoring</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scoring automatique des projets */}
        <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100 mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <i className="ri-bar-chart-line mr-3 text-blue-600"></i>
            Scoring Automatique des Projets
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[ 
              {
                name: 'SolarVillage Sénégal',
                score: 94,
                impact: 98,
                rentabilite: 89,
                faisabilite: 95,
                image: 'https://readdy.ai/api/search-image?query=Solar%20panel%20project%20scoring%20visualization%2C%20data%20analytics%20dashboard%2C%20investment%20metrics%2C%20project%20performance%20indicators%2C%20financial%20analysis%20charts&width=300&height=200&seq=scoring-solar&orientation=landscape'
              },
              {
                name: 'SmartFarm Ghana',
                score: 91,
                impact: 92,
                rentabilite: 94,
                faisabilite: 87,
                image: 'https://readdy.ai/api/search-image?query=Agricultural%20technology%20project%20analysis%2C%20smart%20farming%20metrics%20dashboard%2C%20ROI%20calculation%20charts%2C%20project%20evaluation%20system&width=300&height=200&seq=scoring-farm&orientation=landscape'
              },
              {
                name: 'EduTech Mali',
                score: 87,
                impact: 95,
                rentabilite: 78,
                faisabilite: 88,
                image: 'https://readdy.ai/api/search-image?query=Educational%20technology%20project%20evaluation%2C%20learning%20impact%20metrics%2C%20digital%20education%20analytics%2C%20project%20assessment%20dashboard&width=300&height=200&seq=scoring-edu&orientation=landscape'
              }
            ].map((project, index) => (
              <div key={index} className="border border-gray-200 rounded-2xl p-6 hover:shadow-lg transition-all duration-300">
                <img
                  src={project.image}
                  alt={project.name}
                  className="w-full h-32 object-cover object-top rounded-xl mb-4"
                />

                <h4 className="font-bold text-lg text-gray-900 mb-4">{project.name}</h4>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Score Global</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-2 bg-green-500 rounded-full"
                          style={{ width: `${project.score}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold text-green-600">{project.score}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Impact</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-2 bg-blue-500 rounded-full"
                          style={{ width: `${project.impact}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold">{project.impact}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Rentabilité</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-2 bg-purple-500 rounded-full"
                          style={{ width: `${project.rentabilite}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold">{project.rentabilite}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Faisabilité</span>
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-gray-200 rounded-full">
                        <div 
                          className="h-2 bg-orange-500 rounded-full"
                          style={{ width: `${project.faisabilite}%` }}
                        ></div>
                      </div>
                      <span className="text-sm font-bold">{project.faisabilite}</span>
                    </div>
                  </div>
                </div>

                <button className="w-full mt-4 bg-blue-600 text-white py-2 rounded-full text-sm font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap">
                  Investir dans ce Projet
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
