
'use client';
import { useState } from 'react';

export default function CollaborativeInterface() {
  const [activeTab, setActiveTab] = useState('proposer');
  const [showProposalForm, setShowProposalForm] = useState(false);
  const [showImprovementModal, setShowImprovementModal] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);

  const communityStats = {
    proposals: 1247,
    improvements: 3456,
    activeUsers: 8934,
    implementedIdeas: 567
  };

  const recentProposals = [
    {
      id: 1,
      title: 'Système d\'irrigation solaire intelligent',
      author: 'Aminata Diallo',
      country: 'Burkina Faso',
      votes: 234,
      comments: 45,
      status: 'En évaluation',
      image: 'https://readdy.ai/api/search-image?query=Smart%20solar%20irrigation%20system%20in%20Burkina%20Faso%2C%20African%20farmers%20using%20automated%20watering%20technology%2C%20solar%20panels%20powering%20irrigation%2C%20green%20crops%2C%20sustainable%20agriculture%20innovation&width=400&height=300&seq=irrigation-bf&orientation=landscape',
      description: 'Solution automatisée pour optimiser l\'irrigation des cultures avec capteurs d\'humidité et panneaux solaires.'
    },
    {
      id: 2,
      title: 'Plateforme de télémédecine rurale',
      author: 'Dr. Kwame Asante',
      country: 'Ghana',
      votes: 189,
      comments: 67,
      status: 'Financement',
      image: 'https://readdy.ai/api/search-image?query=Telemedicine%20platform%20in%20rural%20Ghana%2C%20African%20doctor%20consulting%20patients%20via%20video%20call%2C%20medical%20technology%2C%20rural%20clinic%20with%20digital%20equipment%2C%20healthcare%20innovation&width=400&height=300&seq=telemedicine-ghana&orientation=landscape',
      description: 'Connecter les patients ruraux avec des spécialistes via une plateforme de téléconsultation sécurisée.'
    },
    {
      id: 3,
      title: 'Recyclage plastique en pavés écologiques',
      author: 'Jean-Baptiste Kone',
      country: 'Côte d\'Ivoire',
      votes: 156,
      comments: 29,
      status: 'Prototype',
      image: 'https://readdy.ai/api/search-image?query=Plastic%20recycling%20facility%20in%20Ivory%20Coast%2C%20workers%20transforming%20plastic%20waste%20into%20eco-friendly%20paving%20stones%2C%20sustainable%20manufacturing%2C%20environmental%20innovation%2C%20recycling%20equipment&width=400&height=300&seq=recycling-ci&orientation=landscape',
      description: 'Transformer les déchets plastiques en pavés durables pour les routes et trottoirs urbains.'
    }
  ];

  const improvements = [
    {
      project: 'SolarVillage Sénégal',
      suggestion: 'Intégrer un système de stockage par batterie communautaire',
      author: 'Fatou Ba',
      impact: 'Réduction coupures de 85%',
      votes: 67
    },
    {
      project: 'SmartFarm Ghana',
      suggestion: 'Ajouter capteurs de qualité du sol pH et nutriments',
      author: 'Emmanuel Osei',
      impact: 'Optimisation rendement +20%',
      votes: 43
    },
    {
      project: 'EduTech Mali',
      suggestion: 'Mode hors-ligne pour zones à faible connectivité',
      author: 'Aissata Traoré',
      impact: 'Accès élargi à 15K étudiants',
      votes: 89
    }
  ];

  return (
    <div className="py-20 bg-gradient-to-br from-purple-50 via-white to-pink-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Interface Collaborative
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Participez activement à l'amélioration continue de nos projets. 
            Proposez vos idées, améliorez les solutions existantes et collaborez avec la communauté.
          </p>
        </div>

        {/* Statistiques communauté */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <i className="ri-lightbulb-line text-2xl text-blue-600"></i>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-2">{communityStats.proposals.toLocaleString()}</div>
            <div className="text-gray-600">Propositions</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <i className="ri-tools-line text-2xl text-green-600"></i>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-2">{communityStats.improvements.toLocaleString()}</div>
            <div className="text-gray-600">Améliorations</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <i className="ri-team-line text-2xl text-purple-600"></i>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-2">{communityStats.activeUsers.toLocaleString()}</div>
            <div className="text-gray-600">Utilisateurs Actifs</div>
          </div>
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-4">
              <i className="ri-check-double-line text-2xl text-orange-600"></i>
            </div>
            <div className="text-2xl font-bold text-gray-900 mb-2">{communityStats.implementedIdeas.toLocaleString()}</div>
            <div className="text-gray-600">Idées Implémentées</div>
          </div>
        </div>

        {/* Navigation onglets */}
        <div className="flex justify-center mb-12">
          <div className="bg-white rounded-2xl p-2 shadow-lg border border-gray-200 flex gap-2">
            <button
              onClick={() => setActiveTab('proposer')}
              className={`px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center gap-3 whitespace-nowrap ${
                activeTab === 'proposer'
                  ? 'bg-blue-600 text-white shadow-lg transform scale-105'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <i className="ri-add-circle-line text-xl"></i>
              Proposer un Projet
            </button>
            <button
              onClick={() => setActiveTab('ameliorer')}
              className={`px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center gap-3 whitespace-nowrap ${
                activeTab === 'ameliorer'
                  ? 'bg-green-600 text-white shadow-lg transform scale-105'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <i className="ri-tools-line text-xl"></i>
              Améliorer Existant
            </button>
            <button
              onClick={() => setActiveTab('evaluer')}
              className={`px-8 py-4 rounded-xl font-semibold transition-all duration-300 flex items-center gap-3 whitespace-nowrap ${
                activeTab === 'evaluer'
                  ? 'bg-purple-600 text-white shadow-lg transform scale-105'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <i className="ri-star-line text-xl"></i>
              Évaluer & Voter
            </button>
          </div>
        </div>

        {/* Contenu onglet Proposer */}
        {activeTab === 'proposer' && (
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Propositions Récentes de la Communauté
              </h3>
              <button
                onClick={() => setShowProposalForm(true)}
                className="bg-blue-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-blue-700 transition-all duration-300 whitespace-nowrap"
              >
                <i className="ri-add-line mr-2"></i>
                Proposer Mon Projet
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {recentProposals.map((proposal) => (
                <div key={proposal.id} className="group cursor-pointer">
                  <div className="relative overflow-hidden rounded-2xl mb-4">
                    <img
                      src={proposal.image}
                      alt={proposal.title}
                      className="w-full h-48 object-cover object-top group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute top-4 right-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        proposal.status === 'En évaluation' ? 'bg-yellow-100 text-yellow-800' :
                        proposal.status === 'Financement' ? 'bg-green-100 text-green-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {proposal.status}
                      </span>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <h4 className="font-bold text-lg text-gray-900 group-hover:text-blue-600 transition-colors">
                      {proposal.title}
                    </h4>
                    <p className="text-gray-600 text-sm">{proposal.description}</p>
                    
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center">
                          <i className="ri-user-line text-blue-600 text-xs"></i>
                        </div>
                        <span className="text-gray-600">{proposal.author}</span>
                      </div>
                      <span className="text-gray-500">{proposal.country}</span>
                    </div>
                    
                    <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                      <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1 text-blue-600">
                          <i className="ri-thumb-up-line"></i>
                          {proposal.votes}
                        </span>
                        <span className="flex items-center gap-1 text-gray-500">
                          <i className="ri-chat-3-line"></i>
                          {proposal.comments}
                        </span>
                      </div>
                      <button className="text-blue-600 hover:text-blue-700 font-semibold text-sm whitespace-nowrap">
                        Voir Détails
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contenu onglet Améliorer */}
        {activeTab === 'ameliorer' && (
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Améliorations Proposées par la Communauté
              </h3>
              <button
                onClick={() => setShowImprovementModal(true)}
                className="bg-green-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-green-700 transition-all duration-300 whitespace-nowrap"
              >
                <i className="ri-tools-line mr-2"></i>
                Proposer une Amélioration
              </button>
            </div>

            <div className="space-y-6">
              {improvements.map((improvement, index) => (
                <div key={index} className="bg-gray-50 rounded-2xl p-6 border border-gray-100 hover:shadow-md transition-all duration-300">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <h4 className="font-bold text-lg text-gray-900">{improvement.project}</h4>
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <i className="ri-lightbulb-line text-green-600"></i>
                        </div>
                      </div>
                      
                      <p className="text-gray-700 mb-4 font-medium">{improvement.suggestion}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <span className="text-sm text-gray-600">
                            Proposé par <span className="font-semibold">{improvement.author}</span>
                          </span>
                          <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                            {improvement.impact}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-3">
                          <span className="flex items-center gap-1 text-green-600">
                            <i className="ri-thumb-up-line"></i>
                            {improvement.votes}
                          </span>
                          <button className="bg-green-600 text-white px-4 py-2 rounded-full text-sm hover:bg-green-700 transition-colors whitespace-nowrap">
                            Soutenir
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contenu onglet Évaluer */}
        {activeTab === 'evaluer' && (
          <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-100">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Évaluation Communautaire
              </h3>
              <p className="text-gray-600">
                Votez pour les projets et améliorations qui vous semblent les plus pertinents
              </p>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-2xl p-8 border border-purple-100">
              <div className="text-center">
                <i className="ri-star-fill text-4xl text-yellow-500 mb-4"></i>
                <h4 className="text-xl font-bold text-gray-900 mb-4">
                  Système de Vote Démocratique
                </h4>
                <p className="text-gray-600 mb-6">
                  Chaque membre de la communauté dispose d'un vote pour prioriser les projets selon leur impact potentiel
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white rounded-xl p-6 text-center">
                    <i className="ri-award-line text-3xl text-gold-500 mb-3"></i>
                    <div className="font-bold text-lg">Impact Social</div>
                    <div className="text-gray-600 text-sm">Bénéficiaires directs</div>
                  </div>
                  <div className="bg-white rounded-xl p-6 text-center">
                    <i className="ri-leaf-line text-3xl text-green-500 mb-3"></i>
                    <div className="font-bold text-lg">Durabilité</div>
                    <div className="text-gray-600 text-sm">Impact environnemental</div>
                  </div>
                  <div className="bg-white rounded-xl p-6 text-center">
                    <i className="ri-rocket-line text-3xl text-blue-500 mb-3"></i>
                    <div className="font-bold text-lg">Innovation</div>
                    <div className="text-gray-600 text-sm">Originalité technique</div>
                  </div>
                </div>
                
                <button className="mt-6 bg-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:bg-purple-700 transition-all duration-300 whitespace-nowrap">
                  <i className="ri-vote-line mr-2"></i>
                  Participer aux Votes
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Modal formulaire proposition (simplifié) */}
        {showProposalForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-2xl p-8 max-w-2xl w-full max-h-screen overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold">Proposer un Nouveau Projet</h3>
                <button
                  onClick={() => setShowProposalForm(false)}
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
                >
                  <i className="ri-close-line text-xl"></i>
                </button>
              </div>
              
              <div className="text-center py-12">
                <i className="ri-file-text-line text-6xl text-blue-300 mb-4"></i>
                <h4 className="text-xl font-semibold text-gray-900 mb-2">
                  Formulaire de Proposition
                </h4>
                <p className="text-gray-600 mb-6">
                  Connectez Supabase pour activer le système de soumission collaborative
                </p>
                <button className="bg-blue-600 text-white px-6 py-3 rounded-full font-semibold hover:bg-blue-700 transition-colors whitespace-nowrap">
                  Connecter Supabase
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}