
'use client';
import { useState } from 'react';

export default function ProjectsHero() {
  const [selectedFilter, setSelectedFilter] = useState('all');

  return (
    <div className="relative min-h-screen bg-gradient-to-r from-blue-900 via-purple-800 to-green-700">
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=African%20innovation%20hub%20with%20solar%20panels%2C%20wind%20turbines%2C%20modern%20technology%2C%20sustainable%20development%20projects%2C%20people%20working%20together%20on%20laptops%20and%20blueprints%2C%20bright%20natural%20lighting%2C%20professional%20photography%2C%20high-tech%20equipment%2C%20green%20energy%20solutions%2C%20collaborative%20workspace%20atmosphere&width=1920&height=1080&seq=projects-hero-bg&orientation=landscape')`
        }}
      ></div>
      
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 via-purple-800/70 to-green-700/80"></div>
      
      <div className="relative z-10 w-full">
        <div className="container mx-auto px-6 py-20">
          <div className="text-center text-white mb-16">
            <h1 className="text-6xl font-bold mb-8 leading-tight">
              Projets Solutions
              <span className="block text-yellow-300 text-5xl mt-2">Transformons l'Afrique</span>
            </h1>
            <p className="text-xl mb-12 max-w-4xl mx-auto leading-relaxed">
              Des défis aux opportunités : découvrez nos projets innovants, durables et rentables 
              qui connectent innovateurs, investisseurs et collectivités pour transformer le continent africain.
            </p>
            
            {/* Statistiques Hero */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-16">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold text-yellow-300 mb-2">247</div>
                <div className="text-lg">Projets Actifs</div>
                <div className="text-sm opacity-80 mt-1">+23% ce mois</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold text-green-300 mb-2">€34.2M</div>
                <div className="text-lg">Financements</div>
                <div className="text-sm opacity-80 mt-1">Levés en 2024</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold text-blue-300 mb-2">1.2M</div>
                <div className="text-lg">Bénéficiaires</div>
                <div className="text-sm opacity-80 mt-1">Impact direct</div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-4xl font-bold text-purple-300 mb-2">96.3%</div>
                <div className="text-lg">Taux de Réussite</div>
                <div className="text-sm opacity-80 mt-1">Projets déployés</div>
              </div>
            </div>

            {/* Filtres rapides */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {[
                { id: 'all', label: 'Tous les Projets', count: 247 },
                { id: 'energy', label: 'Énergie Verte', count: 67 },
                { id: 'water', label: 'Accès à l\'Eau', count: 43 },
                { id: 'agriculture', label: 'Agriculture Durable', count: 52 },
                { id: 'education', label: 'Éducation Numérique', count: 38 },
                { id: 'health', label: 'Santé Communautaire', count: 29 },
                { id: 'fintech', label: 'Fintech Inclusive', count: 18 }
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setSelectedFilter(filter.id)}
                  className={`px-6 py-3 rounded-full border-2 transition-all duration-300 whitespace-nowrap ${
                    selectedFilter === filter.id
                      ? 'bg-yellow-400 text-black border-yellow-400 font-semibold'
                      : 'bg-white/10 text-white border-white/30 hover:bg-white/20'
                  }`}
                >
                  {filter.label} ({filter.count})
                </button>
              ))}
            </div>

            {/* Boutons d'action principaux */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <button className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black px-8 py-4 rounded-full font-semibold text-lg hover:from-yellow-500 hover:to-orange-500 transform hover:scale-105 transition-all duration-300 whitespace-nowrap">
                <i className="ri-lightbulb-line mr-2"></i>
                Proposer un Projet
              </button>
              <button className="bg-white/20 backdrop-blur-sm text-white px-8 py-4 rounded-full font-semibold text-lg border-2 border-white/30 hover:bg-white/30 transform hover:scale-105 transition-all duration-300 whitespace-nowrap">
                <i className="ri-investment-line mr-2"></i>
                Devenir Investisseur
              </button>
              <button className="bg-green-600 text-white px-8 py-4 rounded-full font-semibold text-lg hover:bg-green-700 transform hover:scale-105 transition-all duration-300 whitespace-nowrap">
                <i className="ri-team-line mr-2"></i>
                Rejoindre la Communauté
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}