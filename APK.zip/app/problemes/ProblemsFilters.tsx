'use client';
import { useState } from 'react';

export default function ProblemsFilters() {
  const [activeFilters, setActiveFilters] = useState({
    urgency: 'all',
    category: 'all',
    region: 'all',
    population: 'all'
  });

  const urgencyLevels = [
    { value: 'all', label: 'Tous les niveaux', count: 347 },
    { value: 'critical', label: 'Critique', count: 158 },
    { value: 'moderate', label: 'Modéré', count: 124 },
    { value: 'low', label: 'Faible', count: 65 }
  ];

  const categories = [
    { value: 'all', label: 'Toutes catégories', count: 347 },
    { value: 'water', label: 'Accès à l\'eau', count: 89 },
    { value: 'health', label: 'Santé', count: 76 },
    { value: 'education', label: 'Éducation', count: 54 },
    { value: 'energy', label: 'Énergie', count: 43 },
    { value: 'agriculture', label: 'Agriculture', count: 38 },
    { value: 'infrastructure', label: 'Infrastructures', count: 32 },
    { value: 'environment', label: 'Environnement', count: 15 }
  ];

  const regions = [
    { value: 'all', label: 'Toutes régions', count: 347 },
    { value: 'west', label: 'Afrique de l\'Ouest', count: 142 },
    { value: 'east', label: 'Afrique de l\'Est', count: 98 },
    { value: 'central', label: 'Afrique Centrale', count: 67 },
    { value: 'north', label: 'Afrique du Nord', count: 40 }
  ];

  const populationRanges = [
    { value: 'all', label: 'Toutes populations', count: 347 },
    { value: 'large', label: '+ de 100K', count: 87 },
    { value: 'medium', label: '10K - 100K', count: 156 },
    { value: 'small', label: '- de 10K', count: 104 }
  ];

  const handleFilterChange = (filterType, value) => {
    setActiveFilters(prev => ({
      ...prev,
      [filterType]: value
    }));
  };

  return (
    <section className="bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-2xl font-bold text-gray-900">
              Filtres Avancés
            </h3>
            <button className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
              Réinitialiser les filtres
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Niveau d'urgence */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                <i className="ri-alert-line text-red-500 mr-2"></i>
                Niveau d'Urgence
              </h4>
              <div className="space-y-2">
                {urgencyLevels.map(level => (
                  <label key={level.value} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="urgency"
                      value={level.value}
                      checked={activeFilters.urgency === level.value}
                      onChange={(e) => handleFilterChange('urgency', e.target.value)}
                      className="text-red-600"
                    />
                    <span className="flex-1">{level.label}</span>
                    <span className="text-sm text-gray-500">({level.count})</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Catégories */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                <i className="ri-bookmark-line text-blue-500 mr-2"></i>
                Catégories
              </h4>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {categories.map(category => (
                  <label key={category.value} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="category"
                      value={category.value}
                      checked={activeFilters.category === category.value}
                      onChange={(e) => handleFilterChange('category', e.target.value)}
                      className="text-blue-600"
                    />
                    <span className="flex-1 text-sm">{category.label}</span>
                    <span className="text-xs text-gray-500">({category.count})</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Régions */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                <i className="ri-map-line text-green-500 mr-2"></i>
                Régions
              </h4>
              <div className="space-y-2">
                {regions.map(region => (
                  <label key={region.value} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="region"
                      value={region.value}
                      checked={activeFilters.region === region.value}
                      onChange={(e) => handleFilterChange('region', e.target.value)}
                      className="text-green-600"
                    />
                    <span className="flex-1">{region.label}</span>
                    <span className="text-sm text-gray-500">({region.count})</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Population */}
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                <i className="ri-group-line text-purple-500 mr-2"></i>
                Population Affectée
              </h4>
              <div className="space-y-2">
                {populationRanges.map(range => (
                  <label key={range.value} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      name="population"
                      value={range.value}
                      checked={activeFilters.population === range.value}
                      onChange={(e) => handleFilterChange('population', e.target.value)}
                      className="text-purple-600"
                    />
                    <span className="flex-1">{range.label}</span>
                    <span className="text-sm text-gray-500">({range.count})</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Filtres appliqués */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Résultats:</span>
                <span className="font-semibold text-gray-900">147 problèmes trouvés</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Trier par:</span>
                <select className="border border-gray-300 rounded px-3 py-1 text-sm pr-8">
                  <option value="urgency">Niveau d'urgence</option>
                  <option value="date">Date récente</option>
                  <option value="population">Population affectée</option>
                  <option value="votes">Nombre de votes</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}