'use client';
import { useState } from 'react';

export default function ProblemsMap() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  
  const countries = [
    { name: "Sénégal", problems: 23, critical: 8, lat: "14.6928", lng: "-17.4467" },
    { name: "Mali", problems: 31, critical: 12, lat: "17.5707", lng: "-3.9962" },
    { name: "Burkina Faso", problems: 28, critical: 11, lat: "12.2383", lng: "-1.5616" },
    { name: "Côte d'Ivoire", problems: 19, critical: 6, lat: "7.539989", lng: "-5.54708" },
    { name: "Ghana", problems: 15, critical: 4, lat: "7.9465", lng: "-1.0232" },
    { name: "Nigeria", problems: 45, critical: 18, lat: "9.0765", lng: "7.3986" },
    { name: "Kenya", problems: 27, critical: 9, lat: "-0.0236", lng: "37.9062" },
    { name: "Éthiopie", problems: 38, critical: 15, lat: "9.145", lng: "40.4897" }
  ];

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Cartographie Dynamique
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Visualisation géolocalisée des défis par niveau d'urgence et impact
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-gray-100 rounded-xl h-96 relative overflow-hidden">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d15844814.55347196!2d-2.632456234374997!3d8.781952999999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sfr!2sfr!4v1640000000000!5m2!1sfr!2sfr"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="rounded-xl"
              />
              
              {/* Légende */}
              <div className="absolute top-4 left-4 bg-white rounded-lg p-4 shadow-lg">
                <h4 className="font-semibold mb-2">Niveau d'Urgence</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Critique</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span>Modéré</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span>Faible</span>
                  </div>
                </div>
              </div>

              {/* Statistiques globales */}
              <div className="absolute bottom-4 right-4 bg-white rounded-lg p-4 shadow-lg">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-900">347</div>
                  <div className="text-sm text-gray-600">Total défis</div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-xl font-bold text-gray-900 mb-4">
              Pays les Plus Affectés
            </h3>
            {countries.map((country, index) => (
              <div 
                key={index}
                className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors cursor-pointer"
                onClick={() => setSelectedCountry(country)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold text-gray-900">{country.name}</h4>
                  <div className="flex space-x-1">
                    {Array.from({ length: Math.min(5, Math.floor(country.critical / 3)) }).map((_, i) => (
                      <div key={i} className="w-2 h-2 bg-red-500 rounded-full"></div>
                    ))}
                  </div>
                </div>
                <div className="flex justify-between text-sm text-gray-600">
                  <span>{country.problems} problèmes</span>
                  <span className="text-red-600 font-medium">{country.critical} critiques</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {selectedCountry && (
          <div className="mt-8 bg-blue-50 border-l-4 border-blue-400 p-6 rounded-r-lg">
            <h4 className="font-bold text-blue-900 mb-2">
              Détails - {selectedCountry.name}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <div className="text-2xl font-bold text-blue-600">{selectedCountry.problems}</div>
                <div className="text-sm text-gray-600">Problèmes identifiés</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-red-600">{selectedCountry.critical}</div>
                <div className="text-sm text-gray-600">Situations critiques</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-600">{Math.floor(selectedCountry.problems * 0.3)}</div>
                <div className="text-sm text-gray-600">Solutions proposées</div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}