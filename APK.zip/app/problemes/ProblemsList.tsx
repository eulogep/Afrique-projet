'use client';
import { useState } from 'react';

export default function ProblemsList() {
  const [expandedProblem, setExpandedProblem] = useState(null);
  
  const problems = [
    {
      id: 1,
      title: "Accès à l'eau potable limité dans les zones rurales",
      location: "Région de Kaolack, Sénégal",
      urgency: "critical",
      urgencyLabel: "Critique",
      urgencyColor: "bg-red-100 text-red-700",
      population: 45000,
      category: "Eau et Assainissement",
      votes: 1247,
      testimonies: 34,
      description: "Les communautés rurales parcourent plus de 5km pour accéder à l'eau potable, avec des conséquences graves sur la santé et l'éducation des enfants.",
      image: "https://readdy.ai/api/search-image?query=African%20rural%20community%20struggling%20with%20water%20access%2C%20women%20carrying%20water%20containers%2C%20dry%20landscape%2C%20children%20waiting%20for%20clean%20water%2C%20documentary%20photography%20style%2C%20warm%20lighting&width=300&height=200&seq=water-access-senegal&orientation=landscape",
      sources: ["ONG Eau Vive", "Ministère de l'Hydraulique", "Témoignages locaux"],
      lastUpdate: "Il y a 2 heures",
      solutions: 3
    },
    {
      id: 2,
      title: "Manque d'équipements médicaux dans les centres de santé",
      location: "Région d'Ashanti, Ghana",
      urgency: "critical",
      urgencyLabel: "Critique",
      urgencyColor: "bg-red-100 text-red-700",
      population: 78000,
      category: "Santé",
      votes: 892,
      testimonies: 28,
      description: "Les centres de santé manquent d'équipements de base pour diagnostics et urgences, forçant les patients à parcourir de longues distances.",
      image: "https://readdy.ai/api/search-image?query=African%20health%20center%20lacking%20medical%20equipment%2C%20healthcare%20workers%20with%20limited%20resources%2C%20rural%20clinic%20interior%2C%20patients%20waiting%2C%20documentary%20photography%20style&width=300&height=200&seq=health-equipment-ghana&orientation=landscape",
      sources: ["Ghana Health Service", "Partners in Health", "Rapports terrain"],
      lastUpdate: "Il y a 4 heures",
      solutions: 2
    },
    {
      id: 3,
      title: "Infrastructure routière défaillante affectant le commerce",
      location: "Province du Sud-Kivu, RDC",
      urgency: "moderate",
      urgencyLabel: "Modéré",
      urgencyColor: "bg-orange-100 text-orange-700",
      population: 120000,
      category: "Infrastructures",
      votes: 634,
      testimonies: 19,
      description: "Les routes dégradées limitent l'accès aux marchés et augmentent les coûts de transport, pénalisant l'économie locale.",
      image: "https://readdy.ai/api/search-image?query=Poor%20road%20infrastructure%20in%20rural%20Africa%2C%20damaged%20roads%20affecting%20commerce%2C%20trucks%20struggling%20on%20bad%20roads%2C%20rural%20market%20access%20challenges%2C%20documentary%20photography&width=300&height=200&seq=road-infrastructure-drc&orientation=landscape",
      sources: ["Ministère des Transports", "Chambre de Commerce", "Associations agricoles"],
      lastUpdate: "Il y a 1 jour",
      solutions: 1
    },
    {
      id: 4,
      title: "Accès limité à l'éducation primaire pour les filles",
      location: "Région de Tillabéri, Niger",
      urgency: "moderate",
      urgencyLabel: "Modéré",
      urgencyColor: "bg-orange-100 text-orange-700",
      population: 32000,
      category: "Éducation",
      votes: 756,
      testimonies: 41,
      description: "Le taux de scolarisation des filles reste très faible à cause des mariages précoces et du manque d'infrastructures adaptées.",
      image: "https://readdy.ai/api/search-image?query=African%20girls%20educational%20challenges%2C%20empty%20school%20benches%2C%20girls%20helping%20with%20household%20work%20instead%20of%20attending%20school%2C%20rural%20education%20access%20issues%2C%20warm%20documentary%20style&width=300&height=200&seq=girls-education-niger&orientation=landscape",
      sources: ["UNICEF", "Ministère de l'Éducation", "Associations féminines"],
      lastUpdate: "Il y a 6 heures",
      solutions: 4
    },
    {
      id: 5,
      title: "Insécurité alimentaire due aux changements climatiques",
      location: "Région de Mopti, Mali",
      urgency: "critical",
      urgencyLabel: "Critique",
      urgencyColor: "bg-red-100 text-red-700",
      population: 156000,
      category: "Agriculture",
      votes: 1456,
      testimonies: 67,
      description: "La sécheresse récurrente et les inondations détruisent les récoltes, créant une insécurité alimentaire chronique.",
      image: "https://readdy.ai/api/search-image?query=Climate%20change%20impact%20on%20African%20agriculture%2C%20drought-affected%20farmland%2C%20farmers%20looking%20at%20damaged%20crops%2C%20food%20insecurity%20challenges%2C%20harsh%20natural%20lighting%2C%20documentary%20photography&width=300&height=200&seq=food-security-mali&orientation=landscape",
      sources: ["PAM", "FAO", "Coopératives agricoles"],
      lastUpdate: "Il y a 30 minutes",
      solutions: 2
    }
  ];

  const getUrgencyIcon = (urgency) => {
    switch(urgency) {
      case 'critical': return 'ri-error-warning-line';
      case 'moderate': return 'ri-alert-line';
      default: return 'ri-information-line';
    }
  };

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold text-gray-900">
            Problèmes Identifiés
          </h2>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600">147 résultats</span>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 font-medium whitespace-nowrap cursor-pointer">
              Exporter la liste
            </button>
          </div>
        </div>

        <div className="space-y-6">
          {problems.map((problem) => (
            <div key={problem.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all">
              <div className="flex flex-col lg:flex-row gap-6">
                <div className="lg:w-1/4">
                  <img 
                    src={problem.image}
                    alt={problem.title}
                    className="w-full h-48 object-cover object-top rounded-lg"
                  />
                </div>
                
                <div className="lg:w-3/4">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${problem.urgencyColor}`}>
                          <i className={`${getUrgencyIcon(problem.urgency)} mr-1`}></i>
                          {problem.urgencyLabel}
                        </span>
                        <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm">
                          {problem.category}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">
                        {problem.title}
                      </h3>
                      <div className="flex items-center text-gray-600 mb-3">
                        <i className="ri-map-pin-line mr-1"></i>
                        <span>{problem.location}</span>
                      </div>
                    </div>
                    <button 
                      onClick={() => setExpandedProblem(expandedProblem === problem.id ? null : problem.id)}
                      className="text-blue-600 hover:text-blue-700 cursor-pointer"
                    >
                      <i className={`ri-${expandedProblem === problem.id ? 'subtract' : 'add'}-line text-xl`}></i>
                    </button>
                  </div>

                  <p className="text-gray-600 mb-4 leading-relaxed">
                    {problem.description}
                  </p>

                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-orange-600">{problem.population.toLocaleString()}</div>
                      <div className="text-xs text-gray-500">Population</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-blue-600">{problem.votes}</div>
                      <div className="text-xs text-gray-500">Votes citoyens</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-green-600">{problem.testimonies}</div>
                      <div className="text-xs text-gray-500">Témoignages</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600">{problem.solutions}</div>
                      <div className="text-xs text-gray-500">Solutions</div>
                    </div>
                    <div className="text-center">
                      <div className="text-sm font-medium text-gray-600">{problem.lastUpdate}</div>
                      <div className="text-xs text-gray-500">Dernière MAJ</div>
                    </div>
                  </div>

                  {expandedProblem === problem.id && (
                    <div className="mt-4 pt-4 border-t border-gray-200">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3">Sources de données</h4>
                          <div className="space-y-2">
                            {problem.sources.map((source, index) => (
                              <div key={index} className="flex items-center space-x-2">
                                <i className="ri-check-line text-green-600"></i>
                                <span className="text-sm text-gray-600">{source}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3">Actions possibles</h4>
                          <div className="space-y-2">
                            <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm whitespace-nowrap cursor-pointer">
                              Voir les témoignages
                            </button>
                            <button className="w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm whitespace-nowrap cursor-pointer">
                              Proposer une solution
                            </button>
                            <button className="w-full bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 text-sm whitespace-nowrap cursor-pointer">
                              Voter pour ce problème
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 flex justify-center">
          <div className="flex items-center space-x-2">
            <button className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 cursor-pointer">
              Précédent
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 cursor-pointer">
              1
            </button>
            <button className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 cursor-pointer">
              2
            </button>
            <button className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 cursor-pointer">
              3
            </button>
            <button className="px-4 py-2 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 cursor-pointer">
              Suivant
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}