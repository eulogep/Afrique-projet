'use client';

export default function DataSources() {
  const sources = [
    {
      name: "ONG Locales",
      count: "127",
      type: "partenaires",
      icon: "ri-heart-line",
      color: "bg-pink-100 text-pink-600",
      description: "Organisations non-gouvernementales sur le terrain"
    },
    {
      name: "Open Data",
      count: "23",
      type: "bases de données",
      icon: "ri-database-line",
      color: "bg-blue-100 text-blue-600",
      description: "Données publiques institutionnelles"
    },
    {
      name: "Instituts Statistiques",
      count: "42",
      type: "organismes officiels",
      icon: "ri-bar-chart-line",
      color: "bg-green-100 text-green-600",
      description: "Bureaux nationaux de statistiques"
    },
    {
      name: "Témoignages Citoyens",
      count: "8,234",
      type: "contributions",
      icon: "ri-user-voice-line",
      color: "bg-orange-100 text-orange-600",
      description: "Rapports directs des communautés"
    }
  ];

  return (
    <section className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Sources de Données Enrichies
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Collecte multisources pour une analyse complète et fiable des défis africains
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {sources.map((source, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all">
              <div className={`w-12 h-12 rounded-lg ${source.color} flex items-center justify-center mb-4`}>
                <i className={`${source.icon} text-xl`}></i>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">
                {source.count}
              </div>
              <div className="text-sm text-gray-500 mb-2">
                {source.type}
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">
                {source.name}
              </h3>
              <p className="text-sm text-gray-600">
                {source.description}
              </p>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-white rounded-xl p-8 shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Mise à Jour en Temps Réel
              </h3>
              <p className="text-gray-600">
                Synchronisation continue des données pour une analyse toujours actuelle
              </p>
            </div>
            <div className="flex items-center space-x-2 text-green-600">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span className="font-medium">Actif</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">5 min</div>
              <div className="text-sm text-gray-600">Fréquence de mise à jour</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600 mb-2">99.7%</div>
              <div className="text-sm text-gray-600">Fiabilité des données</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-600 mb-2">2.4s</div>
              <div className="text-sm text-gray-600">Temps de réponse moyen</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}