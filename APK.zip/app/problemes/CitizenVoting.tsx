'use client';
import { useState } from 'react';

export default function CitizenVoting() {
  const [showVoteModal, setShowVoteModal] = useState(false);
  const [selectedProblem, setSelectedProblem] = useState(null);
  
  const votingProblems = [
    {
      id: 1,
      title: "Amélioration du système de collecte des déchets",
      location: "Abidjan, Côte d'Ivoire",
      description: "Mise en place d'un système de collecte plus efficace dans les quartiers populaires",
      votes: 1456,
      timeLeft: "2 jours",
      category: "Environnement",
      hasVoted: false
    },
    {
      id: 2,
      title: "Construction d'un centre de formation professionnelle",
      location: "Kigali, Rwanda",
      description: "Formation des jeunes aux métiers du numérique et de l'artisanat moderne",
      votes: 987,
      timeLeft: "5 jours",
      category: "Éducation",
      hasVoted: true
    },
    {
      id: 3,
      title: "Installation de panneaux solaires communautaires",
      location: "Ouagadougou, Burkina Faso",
      description: "Électrification solaire des écoles et centres de santé ruraux",
      votes: 743,
      timeLeft: "1 semaine",
      category: "Énergie",
      hasVoted: false
    }
  ];

  const handleVote = (problemId) => {
    setSelectedProblem(problemId);
    setShowVoteModal(true);
  };

  const submitVote = () => {
    setShowVoteModal(false);
    // Logic to submit vote
  };

  return (
    <section className="bg-gradient-to-r from-blue-600 to-purple-600 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12 text-white">
          <h2 className="text-4xl font-bold mb-4">
            Votes Citoyens
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Participez à la priorisation des problèmes en votant pour ceux qui nécessitent une attention urgente
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            {votingProblems.map((problem) => (
              <div key={problem.id} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-medium">
                        {problem.category}
                      </span>
                      <span className="text-sm text-gray-500">
                        <i className="ri-time-line mr-1"></i>
                        {problem.timeLeft} restants
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">
                      {problem.title}
                    </h3>
                    <p className="text-gray-600 mb-3">
                      {problem.description}
                    </p>
                    <div className="flex items-center text-gray-600 mb-4">
                      <i className="ri-map-pin-line mr-1"></i>
                      <span>{problem.location}</span>
                    </div>
                  </div>
                  
                  <div className="text-center ml-4">
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      {problem.votes}
                    </div>
                    <div className="text-sm text-gray-500">votes</div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="text-sm text-gray-600">
                      <i className="ri-user-line mr-1"></i>
                      Participation: {Math.floor(problem.votes / 10)} citoyens
                    </div>
                  </div>
                  
                  {problem.hasVoted ? (
                    <div className="flex items-center space-x-2 text-green-600">
                      <i className="ri-check-line"></i>
                      <span className="font-medium">Voté</span>
                    </div>
                  ) : (
                    <button 
                      onClick={() => handleVote(problem.id)}
                      className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 font-medium whitespace-nowrap cursor-pointer flex items-center space-x-2"
                    >
                      <i className="ri-thumb-up-line"></i>
                      <span>Voter</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-6">
            <div className="bg-white/10 rounded-xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">
                Statistiques des Votes
              </h3>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Total des votes</span>
                  <span className="font-bold">12,847</span>
                </div>
                <div className="flex justify-between">
                  <span>Citoyens participants</span>
                  <span className="font-bold">3,256</span>
                </div>
                <div className="flex justify-between">
                  <span>Votes cette semaine</span>
                  <span className="font-bold">2,143</span>
                </div>
                <div className="flex justify-between">
                  <span>Problèmes résolus</span>
                  <span className="font-bold">67</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-6 text-white">
              <h3 className="text-xl font-bold mb-4">
                Comment ça marche ?
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold">1</span>
                  </div>
                  <span>Consultez les problèmes soumis par les communautés</span>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold">2</span>
                  </div>
                  <span>Votez pour ceux qui vous semblent prioritaires</span>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                    <span className="text-xs font-bold">3</span>
                  </div>
                  <span>Les problèmes les plus votés deviennent prioritaires pour le financement</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {showVoteModal && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-white rounded-xl p-8 max-w-md w-full mx-4">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Confirmer votre vote
              </h3>
              <p className="text-gray-600 mb-6">
                Vous vous apprêtez à voter pour ce problème. Votre vote aidera à le prioriser pour une résolution rapide.
              </p>
              <div className="flex space-x-4">
                <button 
                  onClick={() => setShowVoteModal(false)}
                  className="flex-1 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-200 font-medium whitespace-nowrap cursor-pointer"
                >
                  Annuler
                </button>
                <button 
                  onClick={submitVote}
                  className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 font-medium whitespace-nowrap cursor-pointer"
                >
                  Confirmer
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}