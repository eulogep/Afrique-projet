'use client';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import ProblemsHero from './ProblemsHero';
import ProblemsMap from './ProblemsMap';
import ProblemsFilters from './ProblemsFilters';
import ProblemsList from './ProblemsList';
import CitizenVoting from './CitizenVoting';
import DataSources from './DataSources';

export default function ProblemsPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <ProblemsHero />
        <DataSources />
        <ProblemsMap />
        <ProblemsFilters />
        <ProblemsList />
        <CitizenVoting />
      </main>
      <Footer />
    </div>
  );
}