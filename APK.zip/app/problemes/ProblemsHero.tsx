'use client';

export default function ProblemsHero() {
  return (
    <section 
      className="relative py-20 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.7)), url('https://readdy.ai/api/search-image?query=African%20communities%20identifying%20local%20challenges%2C%20people%20with%20tablets%20and%20smartphones%20collecting%20data%2C%20NGO%20workers%20interviewing%20locals%20about%20pressing%20issues%2C%20collaborative%20problem%20identification%20process%2C%20documentation%20photography%20style%2C%20warm%20natural%20lighting&width=1920&height=800&seq=problems-hero&orientation=landscape')`
      }}
    >
      <div className="max-w-7xl mx-auto px-6 text-white">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
            Analyse Terrain
            <span className="text-red-400"> Enrichie</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200 leading-relaxed">
            Identification géolocalisée des défis critiques avec données ONG, open data, votes citoyens et témoignages communautaires pour une analyse complète.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold mb-1">347</div>
              <div className="text-sm">Défis identifiés</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold mb-1">158</div>
              <div className="text-sm">Critiques</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold mb-1">12,847</div>
              <div className="text-sm">Votes citoyens</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold mb-1">42</div>
              <div className="text-sm">Pays couverts</div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-red-600 text-white px-8 py-4 rounded-lg hover:bg-red-700 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center space-x-2">
              <i className="ri-map-pin-add-line"></i>
              <span>Signaler un Problème</span>
            </button>
            <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white hover:text-gray-900 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center space-x-2">
              <i className="ri-vote-line"></i>
              <span>Participer aux Votes</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}