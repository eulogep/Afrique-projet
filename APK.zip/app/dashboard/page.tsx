'use client';
import Header from '../../components/Header';
import Footer from '../../components/Footer';
import DashboardHero from './DashboardHero';
import PersonalitiesSection from './PersonalitiesSection';
import AnalyticsOverview from './AnalyticsOverview';
import ProjectsTracking from './ProjectsTracking';
import InvestmentPortfolio from './InvestmentPortfolio';
import ImpactMetrics from './ImpactMetrics';

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <DashboardHero />
        <PersonalitiesSection />
        <AnalyticsOverview />
        <ProjectsTracking />
        <InvestmentPortfolio />
        <ImpactMetrics />
      </main>
      <Footer />
    </div>
  );
}