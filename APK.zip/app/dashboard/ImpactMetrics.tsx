'use client';
import { useState } from 'react';

export default function ImpactMetrics() {
  const [selectedTimeframe, setSelectedTimeframe] = useState('year');
  
  const impactData = {
    year: {
      beneficiaries: 847000,
      projects: 189,
      regions: 42,
      jobs: 12400
    },
    month: {
      beneficiaries: 78000,
      projects: 23,
      regions: 8,
      jobs: 1200
    },
    week: {
      beneficiaries: 18000,
      projects: 6,
      regions: 3,
      jobs: 280
    }
  };

  const currentData = impactData[selectedTimeframe];

  const forecasts = [
    {
      period: "1 an",
      beneficiaries: "1.2M",
      investment: "€32M",
      projects: 245,
      regions: 48,
      icon: "ri-calendar-line",
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      period: "3 ans",
      beneficiaries: "3.8M",
      investment: "€89M",
      projects: 567,
      regions: 54,
      icon: "ri-calendar-2-line",
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      period: "5 ans",
      beneficiaries: "7.5M",
      investment: "€156M",
      projects: 1200,
      regions: 54,
      icon: "ri-calendar-check-line",
      color: "text-green-600",
      bgColor: "bg-green-50"
    }
  ];

  const sdgGoals = [
    {
      number: 1,
      name: "Pas de pauvreté",
      progress: 78,
      projects: 45,
      impact: "234K personnes sorties de l'extrême pauvreté"
    },
    {
      number: 2,
      name: "Faim zéro",
      progress: 65,
      projects: 32,
      impact: "156K personnes avec sécurité alimentaire"
    },
    {
      number: 3,
      name: "Bonne santé",
      progress: 82,
      projects: 28,
      impact: "89K consultations médicales supplémentaires"
    },
    {
      number: 4,
      name: "Éducation de qualité",
      progress: 71,
      projects: 38,
      impact: "67K enfants scolarisés"
    },
    {
      number: 6,
      name: "Eau propre",
      progress: 88,
      projects: 23,
      impact: "123K personnes avec accès à l'eau potable"
    },
    {
      number: 7,
      name: "Énergie propre",
      progress: 74,
      projects: 19,
      impact: "89K foyers électrifiés"
    }
  ];

  const timeframes = [
    { value: 'week', label: 'Cette semaine' },
    { value: 'month', label: 'Ce mois' },
    { value: 'year', label: 'Cette année' }
  ];

  return (
    <section className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Métriques d'Impact
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mesure précise de l'impact social, environnemental et économique avec projections à long terme
          </p>
        </div>

        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-lg p-1 flex space-x-1">
            {timeframes.map(timeframe => (
              <button
                key={timeframe.value}
                onClick={() => setSelectedTimeframe(timeframe.value)}
                className={`px-4 py-2 rounded-md font-medium whitespace-nowrap cursor-pointer ${
                  selectedTimeframe === timeframe.value
                    ? 'bg-green-600 text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {timeframe.label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-white rounded-xl p-6 text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-community-line text-orange-600 text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-orange-600 mb-2">
              {currentData.beneficiaries.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">
              Bénéficiaires directs
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-rocket-line text-blue-600 text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-blue-600 mb-2">
              {currentData.projects}
            </div>
            <div className="text-sm text-gray-600">
              Projets actifs
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-map-line text-green-600 text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-green-600 mb-2">
              {currentData.regions}
            </div>
            <div className="text-sm text-gray-600">
              Régions couvertes
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
              <i className="ri-briefcase-line text-purple-600 text-xl"></i>
            </div>
            <div className="text-3xl font-bold text-purple-600 mb-2">
              {currentData.jobs.toLocaleString()}
            </div>
            <div className="text-sm text-gray-600">
              Emplois créés
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          <div className="bg-white rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">
              Contribution aux ODD
            </h3>
            <div className="space-y-4">
              {sdgGoals.map((goal, index) => (
                <div key={index} className="border-l-4 border-green-500 pl-4">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {goal.number}
                      </div>
                      <span className="font-semibold text-gray-900">{goal.name}</span>
                    </div>
                    <span className="text-sm text-gray-600">{goal.projects} projets</span>
                  </div>
                  <div className="flex items-center space-x-3 mb-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all"
                        style={{ width: `${goal.progress}%` }}
                      ></div>
                    </div>
                    <span className="text-sm font-medium text-gray-700">{goal.progress}%</span>
                  </div>
                  <p className="text-sm text-gray-600">{goal.impact}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">
              Projections d'Impact
            </h3>
            <div className="space-y-6">
              {forecasts.map((forecast, index) => (
                <div key={index} className={`${forecast.bgColor} rounded-lg p-4`}>
                  <div className="flex items-center space-x-3 mb-3">
                    <div className={`w-10 h-10 bg-white rounded-lg flex items-center justify-center`}>
                      <i className={`${forecast.icon} ${forecast.color} text-lg`}></i>
                    </div>
                    <div>
                      <div className="font-bold text-gray-900">
                        Prévision {forecast.period}
                      </div>
                      <div className="text-sm text-gray-600">
                        Trajectoire actuelle
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className={`text-lg font-bold ${forecast.color}`}>
                        {forecast.beneficiaries}
                      </div>
                      <div className="text-xs text-gray-600">Bénéficiaires</div>
                    </div>
                    <div>
                      <div className={`text-lg font-bold ${forecast.color}`}>
                        {forecast.investment}
                      </div>
                      <div className="text-xs text-gray-600">Investissements</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-8 text-white text-center">
          <h3 className="text-3xl font-bold mb-4">
            Moteur IA de Recommandation
          </h3>
          <p className="text-xl text-purple-100 mb-6 max-w-3xl mx-auto">
            Notre intelligence artificielle analyse les urgences locales et les profils d'investisseurs pour recommander les projets prioritaires avec un matching personnalisé optimal.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="bg-white/10 rounded-lg p-4">
              <i className="ri-brain-line text-3xl mb-2"></i>
              <div className="font-bold mb-1">Analyse Prédictive</div>
              <div className="text-sm text-purple-200">Machine learning avancé</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <i className="ri-target-line text-3xl mb-2"></i>
              <div className="font-bold mb-1">Matching Optimal</div>
              <div className="text-sm text-purple-200">97% de compatibilité</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <i className="ri-flashlight-line text-3xl mb-2"></i>
              <div className="font-bold mb-1">Recommandations</div>
              <div className="text-sm text-purple-200">Temps réel</div>
            </div>
          </div>
          <button className="bg-white text-purple-600 px-8 py-3 rounded-lg hover:bg-gray-100 font-semibold whitespace-nowrap cursor-pointer">
            Activer l'IA
          </button>
        </div>
      </div>
    </section>
  );
}