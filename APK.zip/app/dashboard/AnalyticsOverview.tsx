
'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

export default function AnalyticsOverview() {
  const [activeTab, setActiveTab] = useState('overview');
  const [realTimeData, setRealTimeData] = useState({});
  const [loading, setLoading] = useState(false);
  
  const [metrics, setMetrics] = useState([
    {
      title: "Taux de Financement",
      value: "94.2%",
      change: "+2.3%",
      trend: "up",
      color: "text-green-600",
      bgColor: "bg-green-50",
      icon: "ri-funds-line"
    },
    {
      title: "ROI Moyen",
      value: "23.7%",
      change: "+1.8%",
      trend: "up",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      icon: "ri-line-chart-line"
    },
    {
      title: "Délai Moyen",
      value: "14.2 mois",
      change: "-2.1 mois",
      trend: "down",
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      icon: "ri-time-line"
    },
    {
      title: "Impact Social",
      value: "847K",
      change: "+156K",
      trend: "up",
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      icon: "ri-community-line"
    }
  ]);

  // Fetch real-time analytics from Supabase
  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      const { data: projects, error: projectsError } = await supabase
        .from('projects')
        .select('*');

      const { data: investments, error: investmentsError } = await supabase
        .from('investments')
        .select('*');

      if (!projectsError && !investmentsError) {
        // Calculate real metrics
        const avgROI = investments.reduce((sum, inv) => sum + parseFloat(inv.expected_roi), 0) / investments.length;
        const totalBeneficiaries = projects.reduce((sum, proj) => sum + parseInt(proj.beneficiaries), 0);
        
        // Update metrics with real data
        setMetrics(prev => prev.map(metric => {
          if (metric.title === "ROI Moyen") {
            return { ...metric, value: `${avgROI.toFixed(1)}%` };
          }
          if (metric.title === "Impact Social") {
            return { ...metric, value: `${Math.round(totalBeneficiaries/1000)}K` };
          }
          return metric;
        }));
      }
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
    
    // Set up real-time subscription
    const subscription = supabase
      .channel('analytics-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'projects' }, () => {
        fetchAnalytics();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'investments' }, () => {
        fetchAnalytics();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const recentActivities = [
    {
      type: "project",
      title: "Nouveau projet validé",
      description: "Installation solaire - Burkina Faso",
      time: "Il y a 2h",
      icon: "ri-sun-line",
      color: "text-yellow-600"
    },
    {
      type: "investment",
      title: "Financement approuvé",
      description: "€240K pour centre de formation",
      time: "Il y a 4h",
      icon: "ri-money-euro-circle-line",
      color: "text-green-600"
    },
    {
      type: "milestone",
      title: "Étape franchie",
      description: "1000e bénéficiaire atteint",
      time: "Il y a 6h",
      icon: "ri-trophy-line",
      color: "text-purple-600"
    },
    {
      type: "alert",
      title: "Attention requise",
      description: "Retard sur projet Mali",
      time: "Il y a 8h",
      icon: "ri-alert-line",
      color: "text-red-600"
    },
    {
      type: "ai",
      title: "Recommandation IA",
      description: "3 nouveaux projets suggérés",
      time: "Il y a 12h",
      icon: "ri-brain-line",
      color: "text-blue-600"
    }
  ];

  const tabs = [
    { id: 'overview', label: 'Vue d\'ensemble', icon: 'ri-dashboard-line' },
    { id: 'projects', label: 'Projets', icon: 'ri-folder-line' },
    { id: 'finance', label: 'Finances', icon: 'ri-bar-chart-line' },
    { id: 'impact', label: 'Impact', icon: 'ri-heart-pulse-line' },
    { id: 'ai', label: 'Intelligence IA', icon: 'ri-brain-line' }
  ];

  const advancedMetrics = {
    projects: {
      total: 189,
      funded: 156,
      success: 147,
      avgDuration: 14.2,
      categories: [
        { name: 'Énergie', count: 45, percentage: 24 },
        { name: 'Agriculture', count: 38, percentage: 20 },
        { name: 'Santé', count: 34, percentage: 18 },
        { name: 'Éducation', count: 32, percentage: 17 },
        { name: 'Infrastructure', count: 28, percentage: 15 },
        { name: 'Autres', count: 12, percentage: 6 }
      ]
    },
    finance: {
      totalInvested: 24800000,
      avgInvestment: 150000,
      totalReturns: 6200000,
      topInvestors: [
        { name: 'African Development Fund', amount: 8700000, roi: 26.4 },
        { name: 'Green Impact Capital', amount: 4200000, roi: 31.2 },
        { name: 'Sahel Innovation Bank', amount: 3800000, roi: 22.8 }
      ]
    },
    impact: {
      beneficiaries: 847000,
      jobsCreated: 12400,
      co2Saved: 156000,
      regionsImpacted: 54
    }
  };

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Analytics en Temps Réel
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Indicateurs clés de performance et métriques d'impact pour un pilotage optimal de l'écosystème
          </p>
          {loading && (
            <div className="mt-4 flex items-center justify-center gap-2 text-blue-600">
              <i className="ri-refresh-line animate-spin"></i>
              <span>Actualisation des données...</span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-8">
          {tabs.map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-lg font-medium whitespace-nowrap cursor-pointer flex items-center space-x-2 transition-all duration-300 ${
                activeTab === tab.id
                  ? 'bg-green-600 text-white shadow-lg transform scale-105'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <i className={`${tab.icon} text-sm`}></i>
              <span>{tab.label}</span>
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {metrics.map((metric, index) => (
                <div key={index} className={`${metric.bgColor} rounded-xl p-6 hover:shadow-lg transition-all duration-300`}>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 ${metric.bgColor} rounded-lg flex items-center justify-center`}>
                      <i className={`${metric.icon} ${metric.color} text-xl`}></i>
                    </div>
                    <div className={`flex items-center text-sm ${
                      metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      <i className={`ri-arrow-${metric.trend}-line mr-1`}></i>
                      <span>{metric.change}</span>
                    </div>
                  </div>
                  <div className={`text-2xl font-bold ${metric.color} mb-1`}>
                    {metric.value}
                  </div>
                  <div className="text-sm text-gray-600">
                    {metric.title}
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                  <i className="ri-map-line mr-2 text-green-600"></i>
                  Répartition par Région
                </h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Afrique de l'Ouest</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 h-2 bg-gray-200 rounded-full">
                        <div className="w-20 h-2 bg-green-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">62%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Afrique de l'Est</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 h-2 bg-gray-200 rounded-full">
                        <div className="w-16 h-2 bg-blue-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">28%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Afrique Centrale</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-32 h-2 bg-gray-200 rounded-full">
                        <div className="w-8 h-2 bg-purple-500 rounded-full"></div>
                      </div>
                      <span className="text-sm font-medium">10%</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                  <i className="ri-notification-line mr-2 text-blue-600"></i>
                  Activité Récente
                </h3>
                <div className="space-y-4 max-h-80 overflow-y-auto">
                  {recentActivities.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 bg-white rounded-lg hover:shadow-md transition-all">
                      <div className="w-8 h-8 bg-white border-2 border-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <i className={`${activity.icon} ${activity.color} text-sm`}></i>
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-900">
                          {activity.title}
                        </div>
                        <div className="text-sm text-gray-600">
                          {activity.description}
                        </div>
                        <div className="text-xs text-gray-500 mt-1" suppressHydrationWarning={true}>
                          {activity.time}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'projects' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <i className="ri-folder-line text-3xl text-blue-600 mb-3"></i>
                <div className="text-3xl font-bold text-blue-600">{advancedMetrics.projects.total}</div>
                <div className="text-gray-600">Projets Total</div>
              </div>
              <div className="bg-green-50 rounded-xl p-6 text-center">
                <i className="ri-check-double-line text-3xl text-green-600 mb-3"></i>
                <div className="text-3xl font-bold text-green-600">{advancedMetrics.projects.funded}</div>
                <div className="text-gray-600">Projets Financés</div>
              </div>
              <div className="bg-purple-50 rounded-xl p-6 text-center">
                <i className="ri-trophy-line text-3xl text-purple-600 mb-3"></i>
                <div className="text-3xl font-bold text-purple-600">{advancedMetrics.projects.success}</div>
                <div className="text-gray-600">Projets Réussis</div>
              </div>
              <div className="bg-orange-50 rounded-xl p-6 text-center">
                <i className="ri-time-line text-3xl text-orange-600 mb-3"></i>
                <div className="text-3xl font-bold text-orange-600">{advancedMetrics.projects.avgDuration}</div>
                <div className="text-gray-600">Mois Moyen</div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Répartition par Secteur</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {advancedMetrics.projects.categories.map((category, index) => (
                  <div key={index} className="bg-white rounded-lg p-4 hover:shadow-md transition-all">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-semibold text-gray-900">{category.name}</h4>
                      <span className="text-sm text-gray-600">{category.count} projets</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full"
                        style={{ width: `${category.percentage}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">{category.percentage}% du total</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'finance' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-green-50 rounded-xl p-6 text-center">
                <i className="ri-money-euro-circle-line text-3xl text-green-600 mb-3"></i>
                <div className="text-3xl font-bold text-green-600">
                  €{(advancedMetrics.finance.totalInvested/1000000).toFixed(1)}M
                </div>
                <div className="text-gray-600">Total Investi</div>
              </div>
              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <i className="ri-bar-chart-line text-3xl text-blue-600 mb-3"></i>
                <div className="text-3xl font-bold text-blue-600">
                  €{(advancedMetrics.finance.avgInvestment/1000).toFixed(0)}K
                </div>
                <div className="text-gray-600">Investissement Moyen</div>
              </div>
              <div className="bg-purple-50 rounded-xl p-6 text-center">
                <i className="ri-arrow-up-circle-line text-3xl text-purple-600 mb-3"></i>
                <div className="text-3xl font-bold text-purple-600">
                  €{(advancedMetrics.finance.totalReturns/1000000).toFixed(1)}M
                </div>
                <div className="text-gray-600">Retours Générés</div>
              </div>
              <div className="bg-orange-50 rounded-xl p-6 text-center">
                <i className="ri-percent-line text-3xl text-orange-600 mb-3"></i>
                <div className="text-3xl font-bold text-orange-600">25.0%</div>
                <div className="text-gray-600">ROI Moyen</div>
              </div>
            </div>

            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Top Investisseurs</h3>
              <div className="space-y-4">
                {advancedMetrics.finance.topInvestors.map((investor, index) => (
                  <div key={index} className="bg-white rounded-lg p-4 flex items-center justify-between hover:shadow-md transition-all">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold">
                        #{index + 1}
                      </div>
                      <div>
                        <div className="font-semibold text-gray-900">{investor.name}</div>
                        <div className="text-sm text-gray-600">Investissement actif</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">
                        €{(investor.amount/1000000).toFixed(1)}M
                      </div>
                      <div className="text-sm text-blue-600">ROI: {investor.roi}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'impact' && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-orange-50 rounded-xl p-6 text-center">
                <i className="ri-community-line text-3xl text-orange-600 mb-3"></i>
                <div className="text-3xl font-bold text-orange-600">
                  {advancedMetrics.impact.beneficiaries.toLocaleString()}
                </div>
                <div className="text-gray-600">Bénéficiaires</div>
              </div>
              <div className="bg-purple-50 rounded-xl p-6 text-center">
                <i className="ri-briefcase-line text-3xl text-purple-600 mb-3"></i>
                <div className="text-3xl font-bold text-purple-600">
                  {advancedMetrics.impact.jobsCreated.toLocaleString()}
                </div>
                <div className="text-gray-600">Emplois Créés</div>
              </div>
              <div className="bg-green-50 rounded-xl p-6 text-center">
                <i className="ri-leaf-line text-3xl text-green-600 mb-3"></i>
                <div className="text-3xl font-bold text-green-600">
                  {(advancedMetrics.impact.co2Saved/1000).toFixed(0)}K
                </div>
                <div className="text-gray-600">Tonnes CO² Évitées</div>
              </div>
              <div className="bg-blue-50 rounded-xl p-6 text-center">
                <i className="ri-global-line text-3xl text-blue-600 mb-3"></i>
                <div className="text-3xl font-bold text-blue-600">
                  {advancedMetrics.impact.regionsImpacted}
                </div>
                <div className="text-gray-600">Régions Impactées</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'ai' && (
          <div className="space-y-8">
            <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-brain-line mr-3 text-purple-600"></i>
                Intelligence Artificielle - Système Avancé
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="bg-white rounded-xl p-6 text-center">
                  <i className="ri-robot-line text-4xl text-blue-600 mb-4"></i>
                  <div className="text-2xl font-bold text-blue-600">97%</div>
                  <div className="text-gray-600">Précision Matching</div>
                </div>
                <div className="bg-white rounded-xl p-6 text-center">
                  <i className="ri-flashlight-line text-4xl text-purple-600 mb-4"></i>
                  <div className="text-2xl font-bold text-purple-600">234</div>
                  <div className="text-gray-600">Recommandations Active</div>
                </div>
                <div className="bg-white rounded-xl p-6 text-center">
                  <i className="ri-speed-line text-4xl text-green-600 mb-4"></i>
                  <div className="text-2xl font-bold text-green-600">0.3s</div>
                  <div className="text-gray-600">Temps de Réponse</div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6">
                <h4 className="font-bold text-lg text-gray-900 mb-4">Dernières Recommandations IA</h4>
                <div className="space-y-4">
                  <div className="border-l-4 border-blue-500 pl-4 py-2">
                    <div className="font-semibold text-gray-900">Projet Agriculture Intelligente - Mali</div>
                    <div className="text-sm text-gray-600">Score de compatibilité: 94% • ROI prévu: 28%</div>
                    <div className="text-xs text-blue-600">Recommandé pour profil investisseur impact</div>
                  </div>
                  <div className="border-l-4 border-green-500 pl-4 py-2">
                    <div className="font-semibold text-gray-900">Centre Formation Numérique - Ghana</div>
                    <div className="text-sm text-gray-600">Score de compatibilité: 91% • 2400 bénéficiaires</div>
                    <div className="text-xs text-green-600">Recommandé pour profil ONG éducation</div>
                  </div>
                  <div className="border-l-4 border-purple-500 pl-4 py-2">
                    <div className="font-semibold text-gray-900">Innovation Santé Mobile - Burkina</div>
                    <div className="text-sm text-gray-600">Score de compatibilité: 89% • Technologie IoT</div>
                    <div className="text-xs text-purple-600">Recommandé pour profil innovateur tech</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab !== 'overview' && activeTab !== 'projects' && activeTab !== 'finance' && activeTab !== 'impact' && activeTab !== 'ai' && (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-bar-chart-line text-3xl text-gray-400"></i>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Section en développement
            </h3>
            <p className="text-gray-600">
              Les analytics détaillés pour cette section seront bientôt disponibles.
            </p>
          </div>
        )}

        {/* Real-time status indicator */}
        <div className="mt-12 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-6 border border-green-200">
          <div className="flex items-center justify-center gap-4">
            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-gray-700 font-medium">
              Système Analytics Actif • Données temps réel • IA opérationnelle
            </span>
            <span className="text-gray-600 text-sm" suppressHydrationWarning={true}>
              Dernière synchronisation: {new Date().toLocaleTimeString()}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
