
'use client';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabase';

export default function DashboardHero() {
  const [stats, setStats] = useState({
    connectedActors: 4567,
    financialImpact: 24.8,
    activeProjects: 189,
    successRate: 97
  });
  const [loading, setLoading] = useState(false);

  // Fetch real-time stats from Supabase
  const fetchStats = async () => {
    setLoading(true);
    try {
      // Get projects count
      const { data: projects, error: projectsError } = await supabase
        .from('projects')
        .select('*', { count: 'exact' });

      // Get investments total
      const { data: investments, error: investmentsError } = await supabase
        .from('investments')
        .select('amount');

      if (!projectsError && !investmentsError) {
        const totalInvestments = investments?.reduce((sum, inv) => sum + parseFloat(inv.amount), 0) || 0;
        
        setStats(prev => ({
          ...prev,
          activeProjects: projects?.length || 189,
          financialImpact: totalInvestments / 1000000 || 24.8
        }));
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    
    // Set up real-time subscription
    const subscription = supabase
      .channel('dashboard-updates')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'projects' }, () => {
        fetchStats();
      })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'investments' }, () => {
        fetchStats();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  return (
    <section className="bg-gradient-to-br from-green-600 via-blue-600 to-purple-700 text-white py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold mb-6">
            Dashboard Solutions Afrique
          </h1>
          <p className="text-xl md:text-2xl text-green-100 max-w-4xl mx-auto leading-relaxed">
            Pilotage intelligent de l'écosystème de transformation africaine avec analytics temps réel, 
            recommandations IA et traçabilité blockchain complète
          </p>
          
          {loading && (
            <div className="mt-4 flex items-center justify-center gap-2 text-green-200">
              <i className="ri-refresh-line animate-spin"></i>
              <span>Mise à jour des données en temps réel...</span>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-team-line text-2xl"></i>
            </div>
            <div className="text-4xl font-bold mb-2" suppressHydrationWarning={true}>
              {stats.connectedActors.toLocaleString()}
            </div>
            <div className="text-green-100">
              Acteurs Connectés
            </div>
            <div className="text-sm text-green-200 mt-2">
              +347 ce mois
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-money-euro-circle-line text-2xl"></i>
            </div>
            <div className="text-4xl font-bold mb-2" suppressHydrationWarning={true}>
              €{stats.financialImpact.toFixed(1)}M
            </div>
            <div className="text-green-100">
              Impact Financier
            </div>
            <div className="text-sm text-green-200 mt-2">
              +€2.3M ce trimestre
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-rocket-line text-2xl"></i>
            </div>
            <div className="text-4xl font-bold mb-2" suppressHydrationWarning={true}>
              {stats.activeProjects}
            </div>
            <div className="text-green-100">
              Projets Actifs
            </div>
            <div className="text-sm text-green-200 mt-2">
              +23 ce mois
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 text-center hover:bg-white/20 transition-all duration-300">
            <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-trophy-line text-2xl"></i>
            </div>
            <div className="text-4xl font-bold mb-2" suppressHydrationWarning={true}>
              {stats.successRate}%
            </div>
            <div className="text-green-100">
              Taux de Réussite
            </div>
            <div className="text-sm text-green-200 mt-2">
              +2.1% vs objectif
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 bg-white/10 backdrop-blur-sm rounded-2xl p-8">
            <h3 className="text-2xl font-bold mb-6 flex items-center">
              <i className="ri-dashboard-line mr-3"></i>
              Vue d'Ensemble Temps Réel
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-white/10 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">Projets par Phase</h4>
                  <i className="ri-bar-chart-line text-green-200"></i>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-green-100">Étude</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-white/20 rounded-full">
                        <div className="w-12 h-2 bg-blue-400 rounded-full"></div>
                      </div>
                      <span className="text-sm">23</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-green-100">Financement</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-white/20 rounded-full">
                        <div className="w-16 h-2 bg-yellow-400 rounded-full"></div>
                      </div>
                      <span className="text-sm">45</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-green-100">Déploiement</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-white/20 rounded-full">
                        <div className="w-18 h-2 bg-green-400 rounded-full"></div>
                      </div>
                      <span className="text-sm">89</span>
                    </div>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-green-100">Clôture</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-white/20 rounded-full">
                        <div className="w-8 h-2 bg-purple-400 rounded-full"></div>
                      </div>
                      <span className="text-sm">32</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 rounded-xl p-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">Impact Géographique</h4>
                  <i className="ri-global-line text-green-200"></i>
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-green-100">Afrique de l'Ouest</span>
                    <span className="text-white font-semibold">62%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-100">Afrique de l'Est</span>
                    <span className="text-white font-semibold">28%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-green-100">Afrique Centrale</span>
                    <span className="text-white font-semibold">10%</span>
                  </div>
                  <div className="text-center mt-4 p-3 bg-white/10 rounded-lg">
                    <div className="text-lg font-bold">54 Pays</div>
                    <div className="text-sm text-green-200">Présence active</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-6">
              <h4 className="font-semibold mb-4 flex items-center">
                <i className="ri-line-chart-line mr-2"></i>
                Performance en Temps Réel
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-300">94.2%</div>
                  <div className="text-xs text-green-100">Taux financement</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-300">23.7%</div>
                  <div className="text-xs text-green-100">ROI moyen</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-300">14.2</div>
                  <div className="text-xs text-green-100">Mois délai</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-300">847K</div>
                  <div className="text-xs text-green-100">Bénéficiaires</div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8">
            <h3 className="text-xl font-bold mb-6 flex items-center">
              <i className="ri-notification-line mr-3"></i>
              Alertes & Notifications
            </h3>
            
            <div className="space-y-4 mb-6">
              <div className="bg-green-400/20 border border-green-400/30 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-2">
                  <i className="ri-check-double-line text-green-300"></i>
                  <span className="font-semibold text-green-100">Projet Financé</span>
                </div>
                <p className="text-sm text-green-200">
                  Centre formation Mali - €450K approuvés
                </p>
                <span className="text-xs text-green-300" suppressHydrationWarning={true}>
                  Il y a {Math.floor(Math.random() * 60)} minutes
                </span>
              </div>

              <div className="bg-blue-400/20 border border-blue-400/30 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-2">
                  <i className="ri-rocket-line text-blue-300"></i>
                  <span className="font-semibold text-blue-100">Nouveau Projet</span>
                </div>
                <p className="text-sm text-blue-200">
                  Irrigation Ghana - Phase étude validée
                </p>
                <span className="text-xs text-blue-300" suppressHydrationWarning={true}>
                  Il y a {Math.floor(Math.random() * 120) + 60} minutes
                </span>
              </div>

              <div className="bg-orange-400/20 border border-orange-400/30 rounded-xl p-4">
                <div className="flex items-center gap-3 mb-2">
                  <i className="ri-alert-line text-orange-300"></i>
                  <span className="font-semibold text-orange-100">Attention</span>
                </div>
                <p className="text-sm text-orange-200">
                  Retard livraison équipements Burkina
                </p>
                <span className="text-xs text-orange-300" suppressHydrationWarning={true}>
                  Il y a {Math.floor(Math.random() * 300) + 120} minutes
                </span>
              </div>
            </div>

            <div className="bg-white/10 rounded-xl p-4">
              <h4 className="font-semibold mb-3 flex items-center">
                <i className="ri-shield-check-line mr-2"></i>
                Statut Système
              </h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-green-100 text-sm">Base de données</span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-green-300 text-xs">Opérationnel</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-100 text-sm">IA Recommandations</span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-green-300 text-xs">Active</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-green-100 text-sm">Blockchain</span>
                  <div className="flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-green-300 text-xs">Synchronisé</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-full px-8 py-4">
            <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-100 font-medium">
              Connecté à Supabase • Synchronisation temps réel active
            </span>
            <span className="text-green-200 text-sm" suppressHydrationWarning={true}>
              Dernière mise à jour: {new Date().toLocaleTimeString()}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
