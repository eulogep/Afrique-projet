'use client';
import { useState } from 'react';

export default function PersonalitiesSection() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  const personalities = [
    {
      id: 1,
      name: "Aminata Touré",
      role: "Directrice Exécutive",
      organization: "Alliance pour le Développement Durable",
      category: "leadership",
      location: "Dakar, Sénégal",
      expertise: "Politiques publiques",
      projects: 23,
      impact: "€2.4M",
      image: "https://readdy.ai/api/search-image?query=Professional%20African%20woman%20executive%20leader%20in%20sustainable%20development%2C%20confident%20business%20portrait%2C%20modern%20office%20setting%2C%20professional%20attire%2C%20leadership%20presence%2C%20corporate%20photography%20style&width=300&height=300&seq=aminata-toure&orientation=squarish",
      description: "Experte en politiques de développement durable avec 15 ans d'expérience dans la transformation des communautés africaines.",
      achievements: ["Mise en œuvre de 23 projets d'impact", "Mobilisation de €2.4M de financements", "Formation de 1,200+ leaders communautaires"],
      contact: "aminata.toure@solutions-afrique.org"
    },
    {
      id: 2,
      name: "Dr. Kwame Asante",
      role: "Directeur Innovation",
      organization: "TechHub Africa",
      category: "innovation",
      location: "Accra, Ghana",
      expertise: "Technologies durables",
      projects: 18,
      impact: "€1.8M",
      image: "https://readdy.ai/api/search-image?query=African%20male%20technology%20innovation%20director%2C%20professional%20portrait%20with%20modern%20tech%20elements%2C%20confident%20scientist%20researcher%2C%20contemporary%20office%20environment%2C%20professional%20photography&width=300&height=300&seq=kwame-asante&orientation=squarish",
      description: "Pionnier des solutions technologiques pour le développement rural, spécialisé dans l'innovation accessible.",
      achievements: ["18 innovations technologiques déployées", "€1.8M levés pour R&D", "Partenariats avec 45 startups africaines"],
      contact: "kwame.asante@techhub-africa.org"
    },
    {
      id: 3,
      name: "Fatou Diallo",
      role: "Responsable Investissements",
      organization: "Africa Impact Fund",
      category: "investment",
      location: "Abidjan, Côte d'Ivoire",
      expertise: "Finance d'impact",
      projects: 31,
      impact: "€5.7M",
      image: "https://readdy.ai/api/search-image?query=Professional%20African%20woman%20finance%20investment%20expert%2C%20confident%20business%20portrait%20in%20modern%20financial%20office%2C%20professional%20attire%2C%20leadership%20presence%2C%20corporate%20photography%20style&width=300&height=300&seq=fatou-diallo&orientation=squarish",
      description: "Experte en finance d'impact avec un portfolio de 31 investissements dans des projets de développement durable.",
      achievements: ["Gestion d'un fonds de €5.7M", "31 investissements d'impact réussis", "Partenariats avec 67 entrepreneurs"],
      contact: "fatou.diallo@africa-impact.fund"
    },
    {
      id: 4,
      name: "Ibrahim Kone",
      role: "Coordinateur Terrain",
      organization: "Réseau ONG Sahel",
      category: "community",
      location: "Bamako, Mali",
      expertise: "Développement communautaire",
      projects: 45,
      impact: "78,000 bénéficiaires",
      image: "https://readdy.ai/api/search-image?query=African%20male%20community%20development%20coordinator%20working%20in%20rural%20settings%2C%20professional%20portrait%20with%20community%20background%2C%20field%20work%20expertise%2C%20documentary%20photography%20style&width=300&height=300&seq=ibrahim-kone&orientation=squarish",
      description: "Coordinateur de terrain avec 12 ans d'expérience dans l'accompagnement des communautés rurales.",
      achievements: ["45 projets communautaires coordonnés", "78,000 personnes impactées", "127 partenaires ONG mobilisés"],
      contact: "ibrahim.kone@reseau-ong-sahel.org"
    },
    {
      id: 5,
      name: "Dr. Aisha Mvungi",
      role: "Analyste Senior",
      organization: "African Data Institute",
      category: "research",
      location: "Nairobi, Kenya",
      expertise: "Analyse de données",
      projects: 67,
      impact: "347 études",
      image: "https://readdy.ai/api/search-image?query=African%20woman%20data%20scientist%20and%20research%20analyst%2C%20professional%20portrait%20in%20modern%20research%20facility%2C%20confident%20expert%20with%20data%20visualization%20background%2C%20professional%20photography&width=300&height=300&seq=aisha-mvungi&orientation=squarish",
      description: "Spécialiste en analyse de données pour le développement, avec expertise en intelligence artificielle appliquée.",
      achievements: ["347 études d'impact réalisées", "67 projets analysés", "25 algorithmes de recommandation développés"],
      contact: "aisha.mvungi@africa-data.institute"
    },
    {
      id: 6,
      name: "Samuel Ochieng",
      role: "Directeur Partenariats",
      organization: "East Africa Collaboration Hub",
      category: "partnership",
      location: "Kampala, Ouganda",
      expertise: "Développement de partenariats",
      projects: 29,
      impact: "156 partenaires",
      image: "https://readdy.ai/api/search-image?query=African%20male%20partnerships%20director%20in%20business%20meeting%20setting%2C%20professional%20portrait%20with%20collaboration%20theme%2C%20confident%20executive%2C%20modern%20office%20environment%2C%20corporate%20photography&width=300&height=300&seq=samuel-ochieng&orientation=squarish",
      description: "Expert en développement de partenariats stratégiques entre secteurs public, privé et associatif.",
      achievements: ["156 partenariats stratégiques établis", "29 projets collaboratifs lancés", "€3.2M mobilisés via partenariats"],
      contact: "samuel.ochieng@eac-hub.org"
    }
  ];

  const categories = [
    { value: 'all', label: 'Tous les profils', icon: 'ri-team-line' },
    { value: 'leadership', label: 'Leadership', icon: 'ri-user-star-line' },
    { value: 'innovation', label: 'Innovation', icon: 'ri-lightbulb-line' },
    { value: 'investment', label: 'Investissement', icon: 'ri-funds-line' },
    { value: 'community', label: 'Communauté', icon: 'ri-community-line' },
    { value: 'research', label: 'Recherche', icon: 'ri-search-eye-line' },
    { value: 'partnership', label: 'Partenariats', icon: 'ri-handshake-line' }
  ];

  const filteredPersonalities = selectedCategory === 'all' 
    ? personalities 
    : personalities.filter(p => p.category === selectedCategory);

  const [selectedPersonality, setSelectedPersonality] = useState(null);

  return (
    <section className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Personnalités de l'Écosystème
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez les acteurs clés qui transforment l'Afrique à travers des projets d'impact concrets
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-8">
          {categories.map(category => (
            <button
              key={category.value}
              onClick={() => setSelectedCategory(category.value)}
              className={`px-4 py-2 rounded-full font-medium whitespace-nowrap cursor-pointer flex items-center space-x-2 ${
                selectedCategory === category.value
                  ? 'bg-green-600 text-white'
                  : 'bg-white text-gray-600 hover:bg-gray-100'
              }`}
            >
              <i className={`${category.icon} text-sm`}></i>
              <span>{category.label}</span>
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPersonalities.map(personality => (
            <div key={personality.id} className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-all cursor-pointer"
                 onClick={() => setSelectedPersonality(personality)}>
              <div className="flex items-center space-x-4 mb-4">
                <img 
                  src={personality.image}
                  alt={personality.name}
                  className="w-16 h-16 rounded-full object-cover object-top"
                />
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900">
                    {personality.name}
                  </h3>
                  <p className="text-sm text-green-600 font-medium">
                    {personality.role}
                  </p>
                  <p className="text-xs text-gray-500">
                    {personality.organization}
                  </p>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center text-sm text-gray-600">
                  <i className="ri-map-pin-line mr-2"></i>
                  <span>{personality.location}</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <i className="ri-focus-line mr-2"></i>
                  <span>{personality.expertise}</span>
                </div>
              </div>

              <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                {personality.description}
              </p>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-600">{personality.projects}</div>
                  <div className="text-xs text-gray-500">Projets</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-600">{personality.impact}</div>
                  <div className="text-xs text-gray-500">Impact</div>
                </div>
              </div>

              <div className="flex space-x-2">
                <button className="flex-1 bg-green-600 text-white px-3 py-2 rounded-lg hover:bg-green-700 text-sm whitespace-nowrap cursor-pointer">
                  Contacter
                </button>
                <button className="flex-1 bg-gray-100 text-gray-700 px-3 py-2 rounded-lg hover:bg-gray-200 text-sm whitespace-nowrap cursor-pointer">
                  Profil détaillé
                </button>
              </div>
            </div>
          ))}
        </div>

        {selectedPersonality && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex items-center space-x-4">
                    <img 
                      src={selectedPersonality.image}
                      alt={selectedPersonality.name}
                      className="w-20 h-20 rounded-full object-cover object-top"
                    />
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">
                        {selectedPersonality.name}
                      </h3>
                      <p className="text-lg text-green-600 font-medium">
                        {selectedPersonality.role}
                      </p>
                      <p className="text-gray-600">
                        {selectedPersonality.organization}
                      </p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setSelectedPersonality(null)}
                    className="text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Description</h4>
                    <p className="text-gray-600">{selectedPersonality.description}</p>
                  </div>

                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Réalisations clés</h4>
                    <div className="space-y-2">
                      {selectedPersonality.achievements.map((achievement, index) => (
                        <div key={index} className="flex items-start space-x-2">
                          <i className="ri-check-line text-green-600 mt-0.5"></i>
                          <span className="text-gray-600">{achievement}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Localisation</h4>
                      <p className="text-gray-600">{selectedPersonality.location}</p>
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">Expertise</h4>
                      <p className="text-gray-600">{selectedPersonality.expertise}</p>
                    </div>
                  </div>

                  <div className="flex space-x-4 pt-4">
                    <button className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 font-medium whitespace-nowrap cursor-pointer">
                      Envoyer un message
                    </button>
                    <button className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-medium whitespace-nowrap cursor-pointer">
                      Voir les projets
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}