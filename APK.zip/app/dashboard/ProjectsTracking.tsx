'use client';
import { useState } from 'react';

export default function ProjectsTracking() {
  const [filterStatus, setFilterStatus] = useState('all');
  
  const projects = [
    {
      id: 1,
      title: "Installation de panneaux solaires communautaires",
      location: "Ouagadougou, Burkina Faso",
      status: "deployment",
      progress: 75,
      budget: "€340K",
      roi: "28%",
      beneficiaries: 2400,
      startDate: "Jan 2024",
      endDate: "Déc 2024",
      manager: "Dr. Kwame Asante",
      image: "https://readdy.ai/api/search-image?query=Solar%20panel%20installation%20in%20African%20rural%20community%2C%20technicians%20installing%20solar%20panels%20on%20community%20buildings%2C%20sustainable%20energy%20project%20in%20progress%2C%20documentary%20photography&width=400&height=250&seq=solar-project&orientation=landscape",
      milestones: [
        { name: "Étude de faisabilité", completed: true },
        { name: "Financement", completed: true },
        { name: "Installation", completed: false, current: true },
        { name: "Formation communautaire", completed: false }
      ]
    },
    {
      id: 2,
      title: "Centre de formation professionnelle",
      location: "Kigali, Rwanda",
      status: "financing",
      progress: 45,
      budget: "€520K",
      roi: "35%",
      beneficiaries: 1200,
      startDate: "Mar 2024",
      endDate: "Mar 2025",
      manager: "Fatou Diallo",
      image: "https://readdy.ai/api/search-image?query=Vocational%20training%20center%20construction%20in%20Rwanda%2C%20modern%20educational%20facility%20being%20built%2C%20African%20students%20learning%20practical%20skills%2C%20professional%20training%20environment&width=400&height=250&seq=training-center&orientation=landscape",
      milestones: [
        { name: "Conception", completed: true },
        { name: "Approbation", completed: true },
        { name: "Financement", completed: false, current: true },
        { name: "Construction", completed: false }
      ]
    },
    {
      id: 3,
      title: "Système d'irrigation intelligent",
      location: "Mopti, Mali",
      status: "study",
      progress: 25,
      budget: "€180K",
      roi: "22%",
      beneficiaries: 800,
      startDate: "Avr 2024",
      endDate: "Sep 2024",
      manager: "Ibrahim Kone",
      image: "https://readdy.ai/api/search-image?query=Smart%20irrigation%20system%20in%20Mali%20agriculture%2C%20farmers%20using%20modern%20irrigation%20technology%2C%20sustainable%20farming%20practices%2C%20African%20agricultural%20innovation&width=400&height=250&seq=irrigation-mali&orientation=landscape",
      milestones: [
        { name: "Analyse terrain", completed: false, current: true },
        { name: "Design technique", completed: false },
        { name: "Validation", completed: false },
        { name: "Implémentation", completed: false }
      ]
    },
    {
      id: 4,
      title: "Clinique mobile de santé maternelle",
      location: "Tamale, Ghana",
      status: "deployment",
      progress: 88,
      budget: "€95K",
      roi: "18%",
      beneficiaries: 3200,
      startDate: "Oct 2023",
      endDate: "Mai 2024",
      manager: "Dr. Aisha Mvungi",
      image: "https://readdy.ai/api/search-image?query=Mobile%20health%20clinic%20serving%20African%20rural%20communities%2C%20medical%20van%20providing%20maternal%20healthcare%20services%2C%20healthcare%20workers%20with%20pregnant%20women%2C%20compassionate%20medical%20care&width=400&height=250&seq=mobile-clinic&orientation=landscape",
      milestones: [
        { name: "Acquisition véhicule", completed: true },
        { name: "Formation équipe", completed: true },
        { name: "Déploiement", completed: true },
        { name: "Évaluation d'impact", completed: false, current: true }
      ]
    },
    {
      id: 5,
      title: "Programme d'alphabétisation numérique",
      location: "Bamenda, Cameroun",
      status: "closure",
      progress: 100,
      budget: "€125K",
      roi: "42%",
      beneficiaries: 1800,
      startDate: "Jun 2023",
      endDate: "Mar 2024",
      manager: "Samuel Ochieng",
      image: "https://readdy.ai/api/search-image?query=Digital%20literacy%20program%20in%20Cameroon%2C%20African%20adults%20learning%20computer%20skills%2C%20community%20education%20center%20with%20computers%2C%20successful%20educational%20project%20completion&width=400&height=250&seq=digital-literacy&orientation=landscape",
      milestones: [
        { name: "Curriculum", completed: true },
        { name: "Formation", completed: true },
        { name: "Certification", completed: true },
        { name: "Suivi post-formation", completed: true }
      ]
    }
  ];

  const statusConfig = {
    study: { label: "Étude", color: "bg-yellow-100 text-yellow-700", icon: "ri-search-eye-line" },
    financing: { label: "Financement", color: "bg-blue-100 text-blue-700", icon: "ri-funds-line" },
    deployment: { label: "Déploiement", color: "bg-purple-100 text-purple-700", icon: "ri-rocket-line" },
    closure: { label: "Clôture", color: "bg-green-100 text-green-700", icon: "ri-check-line" }
  };

  const filteredProjects = filterStatus === 'all' 
    ? projects 
    : projects.filter(p => p.status === filterStatus);

  const [selectedProject, setSelectedProject] = useState(null);

  return (
    <section className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Suivi des Projets en Temps Réel
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Monitoring avancé avec phases détaillées, budgets, ROI et bénéficiaires impactés
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-8">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-4 py-2 rounded-full font-medium whitespace-nowrap cursor-pointer ${
              filterStatus === 'all' ? 'bg-green-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
            }`}
          >
            Tous les projets ({projects.length})
          </button>
          {Object.entries(statusConfig).map(([status, config]) => {
            const count = projects.filter(p => p.status === status).length;
            return (
              <button
                key={status}
                onClick={() => setFilterStatus(status)}
                className={`px-4 py-2 rounded-full font-medium whitespace-nowrap cursor-pointer flex items-center space-x-2 ${
                  filterStatus === status ? 'bg-green-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-100'
                }`}
              >
                <i className={`${config.icon} text-sm`}></i>
                <span>{config.label} ({count})</span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {filteredProjects.map(project => {
            const status = statusConfig[project.status];
            return (
              <div key={project.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all cursor-pointer"
                   onClick={() => setSelectedProject(project)}>
                <div className="relative">
                  <img 
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover object-top"
                  />
                  <div className="absolute top-4 right-4">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${status.color}`}>
                      <i className={`${status.icon} mr-1`}></i>
                      {status.label}
                    </span>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">
                    {project.title}
                  </h3>
                  <div className="flex items-center text-gray-600 mb-3">
                    <i className="ri-map-pin-line mr-1"></i>
                    <span className="text-sm">{project.location}</span>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between text-sm text-gray-600 mb-1">
                      <span>Progression</span>
                      <span>{project.progress}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all"
                        style={{ width: `${project.progress}%` }}
                      ></div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-lg font-bold text-blue-600">{project.budget}</div>
                      <div className="text-xs text-gray-500">Budget</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600">{project.roi}</div>
                      <div className="text-xs text-gray-500">ROI attendu</div>
                    </div>
                  </div>

                  <div className="text-center mb-4">
                    <div className="text-lg font-bold text-orange-600">{project.beneficiaries.toLocaleString()}</div>
                    <div className="text-xs text-gray-500">Bénéficiaires</div>
                  </div>

                  <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                    <span>{project.startDate} - {project.endDate}</span>
                    <span className="font-medium">{project.manager}</span>
                  </div>

                  <button className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 font-medium whitespace-nowrap cursor-pointer">
                    Voir les détails
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {selectedProject && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-2">
                      {selectedProject.title}
                    </h3>
                    <p className="text-gray-600">{selectedProject.location}</p>
                  </div>
                  <button 
                    onClick={() => setSelectedProject(null)}
                    className="text-gray-400 hover:text-gray-600 cursor-pointer"
                  >
                    <i className="ri-close-line text-xl"></i>
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <div>
                    <img 
                      src={selectedProject.image}
                      alt={selectedProject.title}
                      className="w-full h-64 object-cover object-top rounded-lg mb-6"
                    />
                    
                    <div className="grid grid-cols-2 gap-4 mb-6">
                      <div className="bg-blue-50 p-4 rounded-lg text-center">
                        <div className="text-2xl font-bold text-blue-600">{selectedProject.budget}</div>
                        <div className="text-sm text-gray-600">Budget total</div>
                      </div>
                      <div className="bg-purple-50 p-4 rounded-lg text-center">
                        <div className="text-2xl font-bold text-purple-600">{selectedProject.roi}</div>
                        <div className="text-sm text-gray-600">ROI attendu</div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">Étapes du projet</h4>
                      <div className="space-y-3">
                        {selectedProject.milestones.map((milestone, index) => (
                          <div key={index} className="flex items-center space-x-3">
                            <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                              milestone.completed 
                                ? 'bg-green-500 text-white' 
                                : milestone.current 
                                  ? 'bg-blue-500 text-white' 
                                  : 'bg-gray-200 text-gray-400'
                            }`}>
                              {milestone.completed ? (
                                <i className="ri-check-line text-sm"></i>
                              ) : milestone.current ? (
                                <i className="ri-play-line text-sm"></i>
                              ) : (
                                <i className="ri-time-line text-sm"></i>
                              )}
                            </div>
                            <span className={`flex-1 ${
                              milestone.completed 
                                ? 'text-green-700' 
                                : milestone.current 
                                  ? 'text-blue-700 font-medium' 
                                  : 'text-gray-500'
                            }`}>
                              {milestone.name}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Gestionnaire</h4>
                        <p className="text-gray-600">{selectedProject.manager}</p>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-2">Bénéficiaires</h4>
                        <p className="text-gray-600">{selectedProject.beneficiaries.toLocaleString()} personnes</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4 mt-6 pt-6 border-t border-gray-200">
                  <button className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 font-medium whitespace-nowrap cursor-pointer">
                    Rapport détaillé
                  </button>
                  <button className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 font-medium whitespace-nowrap cursor-pointer">
                    Contacter gestionnaire
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}