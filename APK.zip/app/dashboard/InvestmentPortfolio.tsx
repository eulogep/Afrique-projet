'use client';

export default function InvestmentPortfolio() {
  const portfolioStats = [
    {
      title: "Montant Total Investi",
      value: "€24.8M",
      change: "+€2.3M ce mois",
      icon: "ri-funds-line",
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      title: "Retours Générés",
      value: "€6.2M",
      change: "+18% vs objectif",
      icon: "ri-arrow-up-circle-line",
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      title: "Projets Actifs",
      value: "189",
      change: "+23 ce trimestre",
      icon: "ri-rocket-line",
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      title: "Taux de Réussite",
      value: "94.2%",
      change: "+2.1% vs moyenne",
      icon: "ri-trophy-line",
      color: "text-orange-600",
      bgColor: "bg-orange-50"
    }
  ];

  const topInvestors = [
    {
      name: "African Development Fund",
      amount: "€8.7M",
      projects: 67,
      roi: "26.4%",
      type: "Institutionnel",
      flag: "🏦"
    },
    {
      name: "Green Impact Capital",
      amount: "€4.2M",
      projects: 34,
      roi: "31.2%",
      type: "Privé",
      flag: "🌱"
    },
    {
      name: "Sahel Innovation Bank",
      amount: "€3.8M",
      projects: 28,
      roi: "22.8%",
      type: "Bancaire",
      flag: "🏪"
    },
    {
      name: "Women Empowerment Fund",
      amount: "€2.9M",
      projects: 45,
      roi: "28.5%",
      type: "Thématique",
      flag: "👥"
    },
    {
      name: "Tech for Africa Ventures",
      amount: "€2.1M",
      projects: 19,
      roi: "35.7%",
      type: "Tech",
      flag: "💻"
    }
  ];

  const sectorsData = [
    { name: "Énergie", amount: "€7.2M", percentage: 29, color: "bg-yellow-500" },
    { name: "Agriculture", amount: "€5.8M", percentage: 23, color: "bg-green-500" },
    { name: "Santé", amount: "€4.6M", percentage: 19, color: "bg-red-500" },
    { name: "Éducation", amount: "€3.9M", percentage: 16, color: "bg-blue-500" },
    { name: "Infrastructure", amount: "€3.3M", percentage: 13, color: "bg-purple-500" }
  ];

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Portefeuille d'Investissements
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Suivi transparent des financements avec scoring, simulation ROI et traçabilité blockchain
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {portfolioStats.map((stat, index) => (
            <div key={index} className={`${stat.bgColor} rounded-xl p-6`}>
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 bg-white rounded-lg flex items-center justify-center`}>
                  <i className={`${stat.icon} ${stat.color} text-xl`}></i>
                </div>
                <div className="text-right">
                  <div className={`text-2xl font-bold ${stat.color}`}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-gray-600">
                    {stat.title}
                  </div>
                </div>
              </div>
              <div className="text-sm text-gray-600">
                {stat.change}
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-gray-50 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">
                Top Investisseurs
              </h3>
              <button className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                Voir tous
              </button>
            </div>
            
            <div className="space-y-4">
              {topInvestors.map((investor, index) => (
                <div key={index} className="bg-white rounded-lg p-4 hover:shadow-md transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{investor.flag}</div>
                      <div>
                        <div className="font-semibold text-gray-900">
                          {investor.name}
                        </div>
                        <div className="text-sm text-gray-600">
                          {investor.type}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-gray-900">
                        {investor.amount}
                      </div>
                      <div className="text-sm text-green-600 font-medium">
                        ROI: {investor.roi}
                      </div>
                    </div>
                  </div>
                  <div className="text-sm text-gray-600">
                    {investor.projects} projets financés
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-6">
              Répartition par Secteur
            </h3>
            
            <div className="space-y-4 mb-6">
              {sectorsData.map((sector, index) => (
                <div key={index}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-700 font-medium">{sector.name}</span>
                    <span className="text-gray-600">{sector.amount}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div 
                      className={`${sector.color} h-3 rounded-full transition-all`}
                      style={{ width: `${sector.percentage}%` }}
                    ></div>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {sector.percentage}% du portefeuille
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-white rounded-lg p-4">
              <div className="flex items-center space-x-2 mb-3">
                <i className="ri-shield-check-line text-green-600"></i>
                <span className="font-semibold text-gray-900">Traçabilité Blockchain</span>
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <div>• 100% des transactions enregistrées</div>
                <div>• Audit automatique en temps réel</div>
                <div>• Transparence totale des flux financiers</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 bg-gradient-to-r from-green-600 to-blue-600 rounded-xl p-8 text-white">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold mb-2">
              Simulateur de Retours sur Investissement
            </h3>
            <p className="text-green-100">
              Calculez votre impact potentiel avec notre outil de simulation avancé
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-3xl font-bold mb-2">€10K</div>
              <div className="text-sm text-green-200">Investissement minimum</div>
              <div className="text-lg font-semibold mt-2">ROI: 18-25%</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-3xl font-bold mb-2">€50K</div>
              <div className="text-sm text-green-200">Investissement optimal</div>
              <div className="text-lg font-semibold mt-2">ROI: 22-32%</div>
            </div>
            <div className="bg-white/10 rounded-lg p-4 text-center">
              <div className="text-3xl font-bold mb-2">€100K+</div>
              <div className="text-sm text-green-200">Impact majeur</div>
              <div className="text-lg font-semibold mt-2">ROI: 25-40%</div>
            </div>
          </div>
          
          <div className="text-center mt-6">
            <button className="bg-white text-green-600 px-8 py-3 rounded-lg hover:bg-gray-100 font-semibold whitespace-nowrap cursor-pointer">
              Lancer une simulation
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}