import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { action, data } = await req.json()

    switch(action) {
      case 'get_portfolio_analytics':
        // Get comprehensive portfolio analytics
        const { data: investments, error: investmentsError } = await supabaseClient
          .from('investments')
          .select(`
            *,
            projects (
              name,
              sector,
              phase,
              progress,
              roi_projected,
              country,
              beneficiaries,
              image_url
            )
          `)
          .order('created_at', { ascending: false })

        if (investmentsError) throw investmentsError

        // Calculate advanced analytics
        const totalInvested = investments.reduce((sum, inv) => sum + parseFloat(inv.amount), 0)
        const avgROI = investments.length > 0 ? 
          investments.reduce((sum, inv) => sum + parseFloat(inv.expected_roi), 0) / investments.length : 0
        
        // Sector distribution
        const sectorDistribution = {}
        investments.forEach(inv => {
          const sector = inv.projects?.sector || 'Other'
          sectorDistribution[sector] = (sectorDistribution[sector] || 0) + parseFloat(inv.amount)
        })

        // Country distribution
        const countryDistribution = {}
        investments.forEach(inv => {
          const country = inv.projects?.country || 'Unknown'
          countryDistribution[country] = (countryDistribution[country] || 0) + 1
        })

        // Performance metrics
        const performanceMetrics = {
          totalPortfolioValue: totalInvested,
          projectedReturns: totalInvested * (avgROI / 100),
          totalBeneficiaries: investments.reduce((sum, inv) => 
            sum + (inv.projects?.beneficiaries || 0), 0),
          activeProjects: investments.filter(inv => 
            ['study', 'funding', 'deployment'].includes(inv.projects?.phase)).length,
          completedProjects: investments.filter(inv => 
            inv.projects?.phase === 'closure').length
        }

        return new Response(
          JSON.stringify({ 
            investments,
            summary: {
              totalInvested,
              avgROI: avgROI.toFixed(1),
              projectCount: investments.length,
              sectorDistribution,
              countryDistribution,
              performanceMetrics
            }
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      case 'optimize_portfolio':
        // AI-driven portfolio optimization suggestions
        const { data: allProjects, error: projectsError } = await supabaseClient
          .from('projects')
          .select('*')
          .order('roi_projected', { ascending: false })

        if (projectsError) throw projectsError

        const { riskTolerance, investmentAmount, preferredSectors } = data

        // Simple optimization algorithm
        const optimizedPortfolio = allProjects
          .filter(project => {
            if (preferredSectors && preferredSectors.length > 0) {
              return preferredSectors.includes(project.sector)
            }
            return true
          })
          .slice(0, 10)
          .map(project => ({
            ...project,
            recommendedAllocation: Math.random() * 0.3 + 0.05, // 5-35% allocation
            riskScore: Math.random() * 100,
            expectedReturn: project.roi_projected * (1 + Math.random() * 0.2 - 0.1)
          }))

        return new Response(
          JSON.stringify({ 
            optimizedPortfolio,
            totalAllocation: optimizedPortfolio.reduce((sum, p) => sum + p.recommendedAllocation, 0),
            estimatedAnnualReturn: optimizedPortfolio.reduce((sum, p) => 
              sum + (p.expectedReturn * p.recommendedAllocation), 0)
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      case 'risk_assessment':
        // Portfolio risk assessment
        const { portfolio } = data
        
        const riskFactors = {
          sectorConcentration: 'Medium',
          geographicConcentration: 'Low',
          projectPhaseRisk: 'Medium',
          currencyRisk: 'High',
          politicalRisk: 'Medium',
          overallRisk: 'Medium-High'
        }

        const riskMitigation = [
          'Diversifier davantage par secteur géographique',
          'Équilibrer les phases de projets dans le portfolio',
          'Considérer des instruments de couverture de change',
          'Surveillance continue des risques politiques'
        ]

        return new Response(
          JSON.stringify({ 
            riskFactors,
            riskMitigation,
            riskScore: Math.floor(Math.random() * 40) + 40 // 40-80 risk score
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      case 'impact_measurement':
        // Measure social and environmental impact
        const { data: impactData, error: impactError } = await supabaseClient
          .from('investments')
          .select(`
            amount,
            projects (
              beneficiaries,
              jobs_created,
              co2_saved,
              sector
            )
          `)

        if (impactError) throw impactError

        const impactMetrics = {
          totalBeneficiaries: impactData.reduce((sum, inv) => 
            sum + (inv.projects?.beneficiaries || 0), 0),
          jobsCreated: impactData.reduce((sum, inv) => 
            sum + (inv.projects?.jobs_created || 0), 0),
          co2Saved: impactData.reduce((sum, inv) => 
            sum + (inv.projects?.co2_saved || 0), 0),
          investmentPerBeneficiary: impactData.reduce((sum, inv) => sum + parseFloat(inv.amount), 0) /
            impactData.reduce((sum, inv) => sum + (inv.projects?.beneficiaries || 1), 0)
        }

        const sdgAlignment = {
          'No Poverty': 85,
          'Zero Hunger': 72,
          'Good Health': 91,
          'Quality Education': 68,
          'Clean Water': 94,
          'Affordable Energy': 87
        }

        return new Response(
          JSON.stringify({ 
            impactMetrics,
            sdgAlignment,
            impactScore: Object.values(sdgAlignment).reduce((sum, score) => sum + score, 0) / 6
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      default:
        throw new Error('Invalid action')
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})