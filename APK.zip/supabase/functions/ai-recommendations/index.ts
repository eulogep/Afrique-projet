import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { userProfile, preferences } = await req.json()

    // AI logic for personalized recommendations
    const { data: projects, error } = await supabaseClient
      .from('projects')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) throw error

    // Simple AI scoring algorithm based on user profile
    const scoredProjects = projects.map(project => {
      let score = 50; // base score
      
      // Profile-based scoring
      switch(userProfile) {
        case 'investisseur':
          score += project.roi_projected * 1.5
          if (project.phase === 'funding') score += 20
          break
        case 'innovateur':
          score += project.sector === 'Technology' ? 30 : 10
          if (project.phase === 'study') score += 25
          break
        case 'collectivite':
          score += project.beneficiaries / 1000
          if (['Water', 'Education', 'Health'].includes(project.sector)) score += 25
          break
        case 'ong':
          score += project.beneficiaries / 500
          if (project.sector === 'Health' || project.sector === 'Education') score += 30
          break
      }

      // Add some randomization for diversity
      score += Math.random() * 10

      return { ...project, aiScore: Math.min(Math.round(score), 99) }
    })

    // Sort by AI score and return top recommendations
    const recommendations = scoredProjects
      .sort((a, b) => b.aiScore - a.aiScore)
      .slice(0, 6)

    return new Response(
      JSON.stringify({ recommendations }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      },
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})