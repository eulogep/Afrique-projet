import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { action, data } = await req.json()

    switch(action) {
      case 'create_investment':
        // Generate blockchain hash simulation
        const blockchainHash = `bc${Date.now().toString(36)}${Math.random().toString(36).substr(2, 9)}`
        
        const { data: investment, error: investmentError } = await supabaseClient
          .from('investments')
          .insert([{ ...data, blockchain_hash: blockchainHash }])
          .select()

        if (investmentError) throw investmentError

        return new Response(
          JSON.stringify({ investment: investment[0], blockchainHash }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      case 'get_portfolio':
        const { data: investments, error: portfolioError } = await supabaseClient
          .from('investments')
          .select(`
            *,
            projects (
              name,
              sector,
              phase,
              progress,
              roi_projected,
              image_url
            )
          `)
          .order('created_at', { ascending: false })

        if (portfolioError) throw portfolioError

        // Calculate portfolio performance
        const totalInvested = investments.reduce((sum, inv) => sum + parseFloat(inv.amount), 0)
        const avgROI = investments.reduce((sum, inv) => sum + parseFloat(inv.expected_roi), 0) / investments.length

        return new Response(
          JSON.stringify({ 
            investments, 
            summary: { 
              totalInvested, 
              avgROI: avgROI.toFixed(1),
              projectCount: investments.length 
            }
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      case 'update_project_progress':
        const { data: updatedProject, error: updateError } = await supabaseClient
          .from('projects')
          .update({ progress: data.progress, updated_at: new Date().toISOString() })
          .eq('id', data.projectId)
          .select()

        if (updateError) throw updateError

        return new Response(
          JSON.stringify({ project: updatedProject[0] }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )

      default:
        throw new Error('Invalid action')
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      },
    )
  }
})