
'use client';

export default function StatsSection() {
  const stats = [
    {
      number: "347",
      label: "Défis identifiés",
      sublabel: "avec analyse d'urgence",
      icon: "ri-survey-line",
      color: "text-red-600"
    },
    {
      number: "189",
      label: "Projets actifs",
      sublabel: "suivi temps réel",
      icon: "ri-rocket-line",
      color: "text-blue-600"
    },
    {
      number: "124",
      label: "Solutions déployées",
      sublabel: "impact mesuré",
      icon: "ri-check-double-line",
      color: "text-green-600"
    },
    {
      number: "€18.7M",
      label: "Investissements",
      sublabel: "traçabilité blockchain",
      icon: "ri-coin-line",
      color: "text-purple-600"
    },
    {
      number: "3.8M",
      label: "Bénéficiaires",
      sublabel: "transformation directe",
      icon: "ri-community-line",
      color: "text-orange-600"
    },
    {
      number: "42",
      label: "Pays couverts",
      sublabel: "cartographie dynamique",
      icon: "ri-global-line",
      color: "text-indigo-600"
    }
  ];

  return (
    <section className="bg-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Impact Transformationnel
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mesures en temps réel de notre impact sur la transformation durable de l'Afrique
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all hover:scale-105">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg bg-gray-50 flex items-center justify-center ${stat.color}`}>
                  <i className={`${stat.icon} text-2xl`}></i>
                </div>
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-2">
                {stat.number}
              </div>
              <div className="text-gray-900 font-semibold mb-1">
                {stat.label}
              </div>
              <div className="text-sm text-gray-500">
                {stat.sublabel}
              </div>
            </div>
          ))}
        </div>

        {/* Indicateurs clés ajoutés */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-green-50 rounded-lg p-6 text-center">
            <div className="text-2xl font-bold text-green-600 mb-2">94%</div>
            <div className="text-sm text-gray-600">Taux de financement</div>
          </div>
          <div className="bg-blue-50 rounded-lg p-6 text-center">
            <div className="text-2xl font-bold text-blue-600 mb-2">23%</div>
            <div className="text-sm text-gray-600">ROI moyen</div>
          </div>
          <div className="bg-purple-50 rounded-lg p-6 text-center">
            <div className="text-2xl font-bold text-purple-600 mb-2">8.3</div>
            <div className="text-sm text-gray-600">Mois délai moyen</div>
          </div>
          <div className="bg-orange-50 rounded-lg p-6 text-center">
            <div className="text-2xl font-bold text-orange-600 mb-2">4.7/5</div>
            <div className="text-sm text-gray-600">Satisfaction communautés</div>
          </div>
        </div>
      </div>
    </section>
  );
}
