
'use client';

export default function FeaturesSection() {
  const features = [
    {
      title: "Analyse Terrain Enrichie",
      description: "Identification géolocalisée avec données ONG, open data, votes citoyens et témoignages. Notation d'urgence et validation communautaire.",
      icon: "ri-survey-line",
      color: "bg-red-100 text-red-600",
      image: "https://readdy.ai/api/search-image?query=African%20community%20members%20using%20tablets%20and%20smartphones%20to%20report%20local%20issues%2C%20data%20collection%20in%20rural%20villages%2C%20NGO%20workers%20interviewing%20locals%2C%20collaborative%20problem%20identification%2C%20documentary%20photography%20style&width=400&height=300&seq=enriched-analysis&orientation=landscape",
      improvements: ["Données ONG et open data", "Votes citoyens", "Témoignages vidéos", "Notation d'urgence"]
    },
    {
      title: "Projets Transparents",
      description: "Business Model Canvas, analyse d'impact triple (social/environnemental/économique), interface collaborative et suivi temps réel.",
      icon: "ri-presentation-line",
      color: "bg-blue-100 text-blue-600",
      image: "https://readdy.ai/api/search-image?query=Transparent%20project%20presentation%20with%20business%20canvas%2C%20impact%20analysis%20charts%2C%20collaborative%20workspace%20with%20African%20entrepreneurs%2C%20real-time%20project%20monitoring%20dashboard%2C%20professional%20modern%20office%20setting&width=400&height=300&seq=transparent-projects&orientation=landscape",
      improvements: ["Business Model Canvas", "Analyse d'impact triple", "Interface collaborative", "Suivi temps réel"]
    },
    {
      title: "Investissement Intelligent",
      description: "Scoring automatique, portefeuille personnel, simulation de retours et traçabilité blockchain pour maximiser confiance et transparence.",
      icon: "ri-brain-line",
      color: "bg-green-100 text-green-600",
      image: "https://readdy.ai/api/search-image?query=Smart%20investment%20platform%20showing%20project%20scoring%2C%20personal%20portfolio%20dashboard%2C%20ROI%20simulation%20tools%2C%20blockchain%20transparency%20features%2C%20modern%20fintech%20interface%20with%20African%20development%20focus&width=400&height=300&seq=intelligent-investment&orientation=landscape",
      improvements: ["Scoring projets", "Portefeuille personnel", "Simulation ROI", "Traçabilité blockchain"]
    },
    {
      title: "Pilotage Stratégique",
      description: "Cartographie dynamique, indicateurs clés de performance, filtres avancés et prévisions d'impact pour un pilotage optimal.",
      icon: "ri-dashboard-3-line",
      color: "bg-purple-100 text-purple-600",
      image: "https://readdy.ai/api/search-image?query=Strategic%20management%20dashboard%20with%20dynamic%20African%20map%20showing%20active%20projects%2C%20KPI%20indicators%2C%20advanced%20filters%2C%20impact%20forecasting%20charts%2C%20modern%20analytics%20interface%20design&width=400&height=300&seq=strategic-management&orientation=landscape",
      improvements: ["Cartographie dynamique", "KPI avancés", "Filtres intelligents", "Prévisions d'impact"]
    }
  ];

  return (
    <section className="bg-gray-50 py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Fonctionnalités Avancées
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Des outils intelligents et collaboratifs pour transformer les défis en opportunités durables
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {features.map((feature, index) => (
            <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
              <div className="flex flex-col lg:flex-row gap-6">
                <div className="lg:w-2/3">
                  <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-4`}>
                    <i className={`${feature.icon} text-xl`}></i>
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-3">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 leading-relaxed mb-4">
                    {feature.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {feature.improvements.map((improvement, i) => (
                      <span key={i} className="px-3 py-1 bg-green-50 text-green-700 text-sm font-medium rounded-full">
                        {improvement}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="lg:w-1/3">
                  <img 
                    src={feature.image}
                    alt={feature.title}
                    className="w-full h-48 object-cover object-top rounded-lg"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Nouveau module IA */}
        <div className="mt-16 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 text-white">
          <div className="flex flex-col lg:flex-row items-center gap-8">
            <div className="lg:w-1/3">
              <img 
                src="https://readdy.ai/api/search-image?query=AI%20recommendation%20engine%20with%20African%20development%20focus%2C%20machine%20learning%20algorithms%20analyzing%20project%20data%2C%20intelligent%20matching%20of%20investors%20with%20opportunities%2C%20futuristic%20technology%20interface%2C%20warm%20professional%20lighting&width=400&height=300&seq=ai-recommendations&orientation=landscape"
                alt="Moteur IA"
                className="w-full h-48 object-cover object-top rounded-lg"
              />
            </div>
            <div className="lg:w-2/3">
              <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center mb-4">
                <i className="ri-robot-line text-xl"></i>
              </div>
              <h3 className="text-2xl font-bold mb-3">
                Moteur IA de Recommandation
              </h3>
              <p className="text-indigo-100 leading-relaxed mb-4">
                Intelligence artificielle avancée qui recommande les projets prioritaires selon les urgences locales et le profil de chaque investisseur.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-white/20 text-white text-sm font-medium rounded-full">
                  Matching intelligent
                </span>
                <span className="px-3 py-1 bg-white/20 text-white text-sm font-medium rounded-full">
                  Analyse prédictive
                </span>
                <span className="px-3 py-1 bg-white/20 text-white text-sm font-medium rounded-full">
                  Personnalisation
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
