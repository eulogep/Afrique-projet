'use client';
import { useState, useEffect } from 'react';

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

export default function PWAInstaller() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showInstallButton, setShowInstallButton] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [showInstallBanner, setShowInstallBanner] = useState(false);

  useEffect(() => {
    // Vérifier si l'app est déjà installée
    const checkIfInstalled = () => {
      const isInStandaloneMode = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppMode = (window.navigator as any).standalone === true;
      setIsInstalled(isInStandaloneMode || isInWebAppMode);
    };

    // Enregistrer le service worker
    const registerSW = async () => {
      if ('serviceWorker' in navigator) {
        try {
          await navigator.serviceWorker.register('/sw.js');
          console.log('Service Worker enregistré avec succès');
        } catch (error) {
          console.log('Erreur d\\'enregistrement du Service Worker:', error);
        }
      }
    };

    // Gérer l'événement beforeinstallprompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setShowInstallButton(true);
      
      // Afficher la bannière après 3 secondes si pas encore installé
      setTimeout(() => {
        if (!isInstalled) {
          setShowInstallBanner(true);
        }
      }, 3000);
    };

    // Gérer l'installation réussie
    const handleAppInstalled = () => {
      setShowInstallButton(false);
      setShowInstallBanner(false);
      setIsInstalled(true);
      setDeferredPrompt(null);
      
      // Notification de succès
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('Solutions Afrique installée !', {
          body: 'L\\'application est maintenant disponible sur votre écran d\\'accueil',
          icon: '/icons/icon-192x192.png'
        });
      }
    };

    checkIfInstalled();
    registerSW();

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [isInstalled]);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;

    try {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      
      if (outcome === 'accepted') {
        console.log('Utilisateur a accepté l\\'installation');
      } else {
        console.log('Utilisateur a refusé l\\'installation');
        setShowInstallBanner(false);
      }
      
      setDeferredPrompt(null);
      setShowInstallButton(false);
    } catch (error) {
      console.error('Erreur lors de l\\'installation:', error);
    }
  };

  const requestNotificationPermission = async () => {
    if ('Notification' in window && Notification.permission === 'default') {
      const permission = await Notification.requestPermission();
      if (permission === 'granted') {
        new Notification('Notifications activées !', {
          body: 'Vous recevrez des notifications pour les mises à jour importantes',
          icon: '/icons/icon-192x192.png'
        });
      }
    }
  };

  // Instructions pour iOS Safari
  const getIOSInstructions = () => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    
    return isIOS && isSafari;
  };

  if (isInstalled) {
    return (
      <div className="fixed bottom-4 right-4 bg-green-600 text-white px-4 py-3 rounded-xl shadow-lg flex items-center gap-3 z-50">
        <i className="ri-smartphone-line text-xl"></i>
        <div>
          <div className="font-semibold text-sm">Application installée !</div>
          <div className="text-xs opacity-90">Disponible sur votre écran d\\'accueil</div>
        </div>
      </div>
    );
  }

  return (
    <>
      {/* Bannière d'installation */}
      {showInstallBanner && (
        <div className="fixed top-0 left-0 right-0 bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 z-50 transform transition-transform duration-500">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              <i className="ri-download-line text-2xl"></i>
              <div>
                <div className="font-semibold">Installer Solutions Afrique</div>
                <div className="text-sm opacity-90">Accès rapide depuis votre écran d\\'accueil</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {showInstallButton && (
                <button
                  onClick={handleInstallClick}
                  className="bg-white text-green-600 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors whitespace-nowrap"
                >
                  Installer
                </button>
              )}
              <button
                onClick={() => setShowInstallBanner(false)}
                className="w-8 h-8 flex items-center justify-center hover:bg-white/20 rounded-lg transition-colors"
              >
                <i className="ri-close-line"></i>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bouton flottant d'installation */}
      {showInstallButton && !showInstallBanner && (
        <div className="fixed bottom-4 right-4 z-50">
          <button
            onClick={handleInstallClick}
            className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 group"
            title="Installer l\\'application"
          >
            <i className="ri-download-line text-xl group-hover:animate-bounce"></i>
          </button>
        </div>
      )}

      {/* Instructions pour iOS */}
      {getIOSInstructions() && !isInstalled && (
        <div className="fixed bottom-4 left-4 right-4 bg-blue-600 text-white p-4 rounded-xl shadow-lg z-50 max-w-sm mx-auto">
          <div className="flex items-center gap-3 mb-3">
            <i className="ri-information-line text-xl"></i>
            <div className="font-semibold">Installation sur iOS</div>
          </div>
          <div className="text-sm space-y-2">
            <div className="flex items-center gap-2">
              <i className="ri-share-line"></i>
              <span>1. Appuyez sur le bouton de partage</span>
            </div>
            <div className="flex items-center gap-2">
              <i className="ri-add-line"></i>
              <span>2. Sélectionnez \\"Sur l\\'écran d\\'accueil\\"</span>
            </div>
          </div>
          <button
            onClick={() => setShowInstallBanner(false)}
            className="absolute top-2 right-2 w-6 h-6 flex items-center justify-center hover:bg-white/20 rounded-full"
          >
            <i className="ri-close-line text-sm"></i>
          </button>
        </div>
      )}

      {/* Bouton pour activer les notifications */}
      {'Notification' in window && Notification.permission === 'default' && (
        <button
          onClick={requestNotificationPermission}
          className="fixed bottom-20 right-4 bg-orange-600 text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 z-40"
          title="Activer les notifications"
        >
          <i className="ri-notification-line text-lg"></i>
        </button>
      )}
    </>
  );
}