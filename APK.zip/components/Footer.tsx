
'use client';
import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-green-600 rounded-lg flex items-center justify-center">
                <i className="ri-seedling-line text-white text-lg"></i>
              </div>
              <h3 className="text-xl font-['Pacifico'] text-green-400">Solutions Afrique</h3>
            </div>
            <p className="text-gray-400 mb-4">
              Plateforme intelligente et collaborative dédiée à la transformation du continent africain par l'innovation durable.
            </p>
            <div className="flex space-x-3">
              <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center cursor-pointer hover:bg-green-600">
                <i className="ri-facebook-fill"></i>
              </div>
              <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center cursor-pointer hover:bg-green-600">
                <i className="ri-twitter-fill"></i>
              </div>
              <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center cursor-pointer hover:bg-green-600">
                <i className="ri-linkedin-fill"></i>
              </div>
              <div className="w-8 h-8 bg-gray-800 rounded-lg flex items-center justify-center cursor-pointer hover:bg-green-600">
                <i className="ri-youtube-fill"></i>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Plateforme</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/problemes" className="hover:text-white cursor-pointer">Analyse Terrain</Link></li>
              <li><Link href="/projets" className="hover:text-white cursor-pointer">Projets Transparents</Link></li>
              <li><Link href="/investissements" className="hover:text-white cursor-pointer">Investissement Intelligent</Link></li>
              <li><Link href="/dashboard" className="hover:text-white cursor-pointer">Pilotage Stratégique</Link></li>
              <li><Link href="/ia-recommendations" className="hover:text-white cursor-pointer">Moteur IA</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Ressources</h4>
            <ul className="space-y-2 text-gray-400">
              <li><Link href="/methodology" className="hover:text-white cursor-pointer">Méthodologie</Link></li>
              <li><Link href="/impact-reports" className="hover:text-white cursor-pointer">Rapports d'Impact</Link></li>
              <li><Link href="/blockchain" className="hover:text-white cursor-pointer">Traçabilité Blockchain</Link></li>
              <li><Link href="/community" className="hover:text-white cursor-pointer">Communauté</Link></li>
              <li><Link href="/api" className="hover:text-white cursor-pointer">API Développeurs</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-4">Contact</h4>
            <ul className="space-y-2 text-gray-400">
              <li className="flex items-center space-x-2">
                <i className="ri-mail-line"></i>
                <span>impact@solutions-afrique.com</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="ri-phone-line"></i>
                <span>+33 1 89 47 25 63</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="ri-map-pin-line"></i>
                <span>Paris • Dakar • Lagos</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="ri-time-line"></i>
                <span>Support 24/7</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 mb-4 md:mb-0">
              &copy; 2024 Solutions Afrique. Transformons l'Afrique ensemble.
            </p>
            <div className="flex space-x-6 text-sm text-gray-400">
              <Link href="/privacy" className="hover:text-white cursor-pointer">Confidentialité</Link>
              <Link href="/terms" className="hover:text-white cursor-pointer">Conditions</Link>
              <Link href="/security" className="hover:text-white cursor-pointer">Sécurité</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
