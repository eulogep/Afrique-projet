
'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showMobileInstall, setShowMobileInstall] = useState(false);

  useEffect(() => {
    // Détecter si on est sur mobile
    const isMobile = window.innerWidth <= 768;
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    
    if (isMobile && !isStandalone) {
      setShowMobileInstall(true);
    }
  }, []);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-600 to-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-xl">SA</span>
            </div>
            <span className="font-[\'Pacifico\'] text-2xl bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              Solutions Afrique
            </span>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/dashboard" className="text-gray-600 hover:text-green-600 font-medium transition-colors whitespace-nowrap">
              Dashboard
            </Link>
            <Link href="/projets" className="text-gray-600 hover:text-green-600 font-medium transition-colors whitespace-nowrap">
              Projets
            </Link>
            <Link href="/problemes" className="text-gray-600 hover:text-green-600 font-medium transition-colors whitespace-nowrap">
              Problèmes
            </Link>
            <Link href="/admin" className="text-gray-600 hover:text-green-600 font-medium transition-colors whitespace-nowrap">
              Admin
            </Link>
            <Link href="/documentation" className="text-gray-600 hover:text-green-600 font-medium transition-colors whitespace-nowrap">
              Documentation
            </Link>
            
            {showMobileInstall && (
              <div className="flex items-center gap-2 bg-green-50 px-3 py-2 rounded-lg">
                <i className="ri-smartphone-line text-green-600"></i>
                <span className="text-green-700 text-sm font-medium">App mobile disponible</span>
              </div>
            )}
          </nav>

          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center text-gray-600 hover:text-green-600 transition-colors"
          >
            <i className={`ri-${isMenuOpen ? \'close\' : \'menu\'}-line text-xl`}></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <nav className="flex flex-col space-y-3">
              <Link href="/dashboard" className="text-gray-600 hover:text-green-600 font-medium py-2 transition-colors">
                Dashboard
              </Link>
              <Link href="/projets" className="text-gray-600 hover:text-green-600 font-medium py-2 transition-colors">
                Projets
              </Link>
              <Link href="/problemes" className="text-gray-600 hover:text-green-600 font-medium py-2 transition-colors">
                Problèmes
              </Link>
              <Link href="/admin" className="text-gray-600 hover:text-green-600 font-medium py-2 transition-colors">
                Admin
              </Link>
              <Link href="/documentation" className="text-gray-600 hover:text-green-600 font-medium py-2 transition-colors">
                Documentation
              </Link>
              
              {showMobileInstall && (
                <div className="flex items-center gap-3 bg-gradient-to-r from-green-50 to-blue-50 p-3 rounded-lg mt-4">
                  <i className="ri-smartphone-line text-green-600 text-xl"></i>
                  <div>
                    <div className="font-semibold text-green-700">Application mobile</div>
                    <div className="text-sm text-green-600">Installez pour un accès rapide</div>
                  </div>
                </div>
              )}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
