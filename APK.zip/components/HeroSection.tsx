
'use client';
import Link from 'next/link';

export default function HeroSection() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.6)), url('https://readdy.ai/api/search-image?query=African%20communities%20working%20together%20on%20sustainable%20development%2C%20collaborative%20innovation%2C%20local%20innovators%20and%20international%20investors%20shaking%20hands%2C%20modern%20technology%20meeting%20traditional%20wisdom%2C%20inspiring%20transformation%20scene%2C%20golden%20hour%20lighting%2C%20professional%20photography&width=1920&height=1080&seq=hero-transformation&orientation=landscape')`
      }}
    >
      <div className="w-full max-w-7xl mx-auto px-6 text-white">
        <div className="max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Transformons l'Afrique
            <span className="text-green-400"> Ensemble</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200 leading-relaxed">
            Plateforme intelligente et collaborative dédiée à la transformation du continent. Nous identifions les défis critiques et les transformons en opportunités concrètes, connectant innovateurs, investisseurs et collectivités.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/problemes">
              <button className="bg-green-600 text-white px-8 py-4 rounded-lg hover:bg-green-700 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center space-x-2">
                <i className="ri-lightbulb-line"></i>
                <span>Identifier les Opportunités</span>
              </button>
            </Link>
            <Link href="/projets">
              <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white hover:text-gray-900 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center space-x-2">
                <i className="ri-rocket-line"></i>
                <span>Lancer un Projet</span>
              </button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
