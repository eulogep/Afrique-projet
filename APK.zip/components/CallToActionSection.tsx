
'use client';
import Link from 'next/link';

export default function CallToActionSection() {
  return (
    <section 
      className="relative py-20 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(34, 197, 94, 0.9), rgba(22, 163, 74, 0.9)), url('https://readdy.ai/api/search-image?query=African%20entrepreneurs%20and%20international%20investors%20collaborating%2C%20handshake%20over%20sustainable%20development%20projects%2C%20community%20members%20celebrating%20project%20success%2C%20children%20accessing%20clean%20water%20and%20education%2C%20transformation%20and%20hope%2C%20inspirational%20golden%20hour%20lighting&width=1920&height=600&seq=collaboration-transformation&orientation=landscape')`
      }}
    >
      <div className="max-w-7xl mx-auto px-6 text-center text-white">
        <h2 className="text-4xl md:text-5xl font-bold mb-6">
          Rejoignez la Transformation Africaine
        </h2>
        <p className="text-xl md:text-2xl mb-8 max-w-4xl mx-auto leading-relaxed">
          Connectez-vous à notre écosystème d'innovateurs, investisseurs et collectivités pour créer un impact durable et mesurable sur tout le continent.
        </p>
        
        {/* Nouvelles statistiques d'engagement */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10 max-w-4xl mx-auto">
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold mb-1">2,847</div>
            <div className="text-sm">Innovateurs actifs</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold mb-1">1,236</div>
            <div className="text-sm">Investisseurs engagés</div>
          </div>
          <div className="bg-white/10 rounded-lg p-4">
            <div className="text-2xl font-bold mb-1">456</div>
            <div className="text-sm">Collectivités partenaires</div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/projets">
            <button className="bg-white text-green-600 px-8 py-4 rounded-lg hover:bg-gray-100 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center justify-center space-x-2">
              <i className="ri-lightbulb-line"></i>
              <span>Proposer une Solution</span>
            </button>
          </Link>
          <Link href="/investissements">
            <button className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg hover:bg-white/10 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center justify-center space-x-2">
              <i className="ri-hand-coin-line"></i>
              <span>Investir dans l'Impact</span>
            </button>
          </Link>
          <Link href="/dashboard">
            <button className="bg-yellow-400 text-gray-900 px-8 py-4 rounded-lg hover:bg-yellow-300 font-semibold text-lg whitespace-nowrap cursor-pointer flex items-center justify-center space-x-2">
              <i className="ri-robot-line"></i>
              <span>Découvrir l'IA</span>
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
