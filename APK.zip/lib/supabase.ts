'use client';

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Project {
  id: number;
  name: string;
  description: string;
  sector: string;
  country: string;
  phase: 'study' | 'funding' | 'deployment' | 'closure';
  progress: number;
  budget_total: number;
  budget_spent: number;
  roi_projected: number;
  beneficiaries: number;
  jobs_created: number;
  co2_saved: number;
  manager_name: string;
  image_url: string;
  created_at: string;
  updated_at: string;
}

export interface Investment {
  id: number;
  project_id: number;
  investor_name: string;
  amount: number;
  investment_type: string;
  expected_roi: number;
  status: string;
  blockchain_hash: string;
  created_at: string;
  projects?: Project;
}

export interface UserProfile {
  id: number;
  user_type: 'investisseur' | 'innovateur' | 'collectivite' | 'ong';
  preferences: any;
  investment_history: any;
  created_at: string;
}